package com.wujiacun.wujia.util;

import com.wujiacun.wujia.entity.GhostVillagerEntity;
import com.wujiacun.wujia.entity.HimDragonEntity;
import com.wujiacun.wujia.entity.HimVillagerEntity;
import com.wujiacun.wujia.entity.WuVillagerBase;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Him 的自定义闪电轨：只出闪电外观，不点火、不摧毁方块。
 * 命中时造成高额穿甲伤，并强行僵直（缓慢 + 挖掘疲劳 + 短暂虚弱）。
 */
public final class HimLightning {
    private static final double HIT_RADIUS = 2.75;
    private static final float BASE_DAMAGE = 22.0f;

    private HimLightning() {}

    /**
     * @param level   服务端世界
     * @param at      落点
     * @param owner   施法者（Him），不会误伤自己与己方
     * @param focus   优先目标（通常是打 Him 的人），可空
     * @param damage  实际伤害；传 <=0 时用默认
     */
    public static void strike(ServerLevel level, Vec3 at, LivingEntity owner, LivingEntity focus, float damage) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(at.x, at.y, at.z);
            bolt.setVisualOnly(true); // 关键：不点火、不刷猪人、不走原版雷击逻辑
            if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
                bolt.setCause(sp);
            }
            level.addFreshEntity(bolt);
        }

        float dmg = damage > 0.0f ? damage : BASE_DAMAGE;
        AABB box = new AABB(at.x - HIT_RADIUS, at.y - 1.0, at.z - HIT_RADIUS,
                at.x + HIT_RADIUS, at.y + 3.0, at.z + HIT_RADIUS);

        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, box, e -> shouldHit(owner, e))) {
            float scale = (focus != null && victim.getUUID().equals(focus.getUUID())) ? 1.35f : 1.0f;
            victim.hurt(ModDamageTypes.wuStrike(level, owner), dmg * scale);
            // 僵直：高幅缓慢 + 挖掘疲劳 + 虚弱，短时间拉住对手
            victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 45, 5, false, true));
            victim.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 45, 4, false, true));
            victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 35, 1, false, true));
            victim.setDeltaMovement(victim.getDeltaMovement().multiply(0.15, 0.35, 0.15));
            victim.hurtMarked = true;
        }

        level.playSound(null, at.x, at.y, at.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.85f, 1.15f);
    }

    private static boolean shouldHit(LivingEntity owner, LivingEntity e) {
        return com.wujiacun.wujia.entity.combat.WuCombatRules.canHit(owner, e);
    }
}
