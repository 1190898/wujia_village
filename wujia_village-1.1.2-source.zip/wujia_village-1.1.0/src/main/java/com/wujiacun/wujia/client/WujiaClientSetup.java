package com.wujiacun.wujia.client;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.GhostVillagerEntity;
import com.wujiacun.wujia.client.model.WuHumanoidModel;
import com.wujiacun.wujia.registry.ModBlocks;
import com.wujiacun.wujia.registry.ModEntities;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ChickenRenderer;
import net.minecraft.client.renderer.entity.EnderDragonRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.WolfRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterDimensionSpecialEffectsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * 客户端渲染：吴家村的角色一律用玩家（史蒂夫）骨架，不再是原版村民模型。
 */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WujiaClientSetup {

    private static ResourceLocation tex(String path) {
        return new ResourceLocation(WujiaVillageMod.MODID, path);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WUJIA_PORTAL.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WU_CABBAGE_CROP.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WUJIA_AIR.get(), RenderType.translucent());
        });
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.DODGE_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/dodge_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.TELEPORT_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/teleport_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.CHIEF_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/chief_villager.png"), 1.15f));
        event.registerEntityRenderer(ModEntities.ANCESTOR_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/ancestor_villager.png"), 1.3f,
                        tex("textures/entity/ancestor_villager_eyes.png")));
        event.registerEntityRenderer(ModEntities.SWEEPER_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/sweeper_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.GUARD_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/guard_villager.png"), 1.05f));
        event.registerEntityRenderer(ModEntities.FISHER_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/fisher_villager.png"), 1.0f));

        // Him：经典史蒂夫 + 一双发光的白眼
        event.registerEntityRenderer(ModEntities.HIM_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/him_villager.png"), 1.0f,
                        tex("textures/entity/him_villager_eyes.png")));

        event.registerEntityRenderer(ModEntities.GHOST_VILLAGER.get(), GhostVillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.SKILL_EFFECT.get(), WuSkillEffectRenderer::new);
        event.registerEntityRenderer(ModEntities.WU_SWORD.get(), WuSwordRenderer::new);
        event.registerEntityRenderer(ModEntities.BROOM.get(), BroomRenderer::new);
        event.registerEntityRenderer(ModEntities.WU_CHICKEN.get(), ChickenRenderer::new);
        event.registerEntityRenderer(ModEntities.WU_DOG.get(), WolfRenderer::new);
        event.registerEntityRenderer(ModEntities.HIM_DRAGON.get(), EnderDragonRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BroomRenderer.LAYER, com.wujiacun.wujia.client.model.BroomModel::createBodyLayer);
        event.registerLayerDefinition(WuSkillEffectRenderer.PALM_LAYER, com.wujiacun.wujia.client.model.WuPalmModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onSkyEffects(RegisterDimensionSpecialEffectsEvent event) {
        event.register(new ResourceLocation(WujiaVillageMod.MODID, "wujia"), new WujiaSkyEffects());
    }

    /**
     * 以玩家为基准的人形渲染：史蒂夫骨架 + 各自皮肤，可选发光眼睛层。
     */
    public static class WuHumanoidRenderer<T extends Mob> extends MobRenderer<T, WuHumanoidModel<T>> {
        private final ResourceLocation texture;
        private final float scale;

        public WuHumanoidRenderer(EntityRendererProvider.Context ctx, ResourceLocation texture, float scale) {
            this(ctx, texture, scale, null);
        }

        public WuHumanoidRenderer(EntityRendererProvider.Context ctx, ResourceLocation texture, float scale,
                                  ResourceLocation glowEyes) {
            super(ctx, new WuHumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
            this.texture = texture;
            this.scale = scale;
            this.addLayer(new ItemInHandLayer<>(this, ctx.getItemInHandRenderer()));
            if (glowEyes != null) {
                this.addLayer(new EyesLayer<T, WuHumanoidModel<T>>(this) {
                    @Override
                    public RenderType renderType() {
                        return RenderType.eyes(glowEyes);
                    }
                });
            }
        }

        @Override
        public ResourceLocation getTextureLocation(T entity) {
            return texture;
        }

        @Override
        protected void scale(T entity, PoseStack pose, float partialTick) {
            pose.scale(scale, scale, scale);
        }
    }

    /** Role/pose snapshots, continuously faded at vertex submission; size never changes with age. */
    public static class GhostVillagerRenderer extends MobRenderer<GhostVillagerEntity, WuHumanoidModel<GhostVillagerEntity>> {
        private static final String[] SKINS = {"dodge", "teleport", "chief", "ancestor", "sweeper", "guard", "fisher", "him"};

        public GhostVillagerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new WuHumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.0f);
            this.shadowStrength = 0;
        }

        @Override
        public ResourceLocation getTextureLocation(GhostVillagerEntity entity) {
            int variant = Math.max(0, Math.min(SKINS.length - 1, entity.getSkinVariant()));
            return tex("textures/entity/" + SKINS[variant] + "_villager.png");
        }

        @Override
        public void render(GhostVillagerEntity entity, float yaw, float partialTick, PoseStack pose,
                           MultiBufferSource buffers, int light) {
            model.setRenderAlpha(0.64f * (1.0f - entity.fade(partialTick)));
            try {
                super.render(entity, yaw, partialTick, pose, buffers, light);
            } finally {
                model.setRenderAlpha(1.0f);
            }
        }

        @Override
        protected void scale(GhostVillagerEntity entity, PoseStack pose, float partialTick) {
            float size = entity.getGhostScale();
            pose.scale(size, size, size);
        }

        @Override
        protected boolean shouldShowName(GhostVillagerEntity entity) { return false; }

        @Override
        protected RenderType getRenderType(GhostVillagerEntity entity, boolean bodyVisible, boolean translucent, boolean glowing) {
            return RenderType.entityTranslucent(this.getTextureLocation(entity));
        }
    }
}
