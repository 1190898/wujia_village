package com.wujiacun.wujia.world;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * 方星裂开的那一下，在村子上空补一层尘土和低沉的爆声。
 * 真正的方块星球在客户端天空里画，这里只负责每个人都听得见、看得见的余波。
 */
public final class CubePlanetShow {
    private CubePlanetShow() {}

    public static void tick(ServerLevel level) {
        if (level.players().isEmpty()) return;
        if (CubePlanetSchedule.mod(level.getGameTime()) != CubePlanetSchedule.BREAK_AT) return;
        for (ServerPlayer player : level.players()) {
            double x = player.getX();
            double y = player.getY() + 24.0;
            double z = player.getZ();
            level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 6, 4.0, 2.0, 4.0, 0.0);
            level.sendParticles(ParticleTypes.LAVA, x, y, z, 24, 6.0, 2.5, 6.0, 0.0);
            level.sendParticles(ParticleTypes.ASH, x, y - 6.0, z, 36, 7.0, 5.0, 7.0, 0.02);
            level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                    SoundSource.AMBIENT, 0.35f, 0.55f);
            if (!player.getPersistentData().getBoolean("wujia_planet_told")) {
                player.getPersistentData().putBoolean("wujia_planet_told", true);
                player.sendSystemMessage(Component.translatable("message.wujia_village.planet.break"));
            }
        }
    }
}
