package com.wujiacun.wujia.item;

import com.wujiacun.wujia.registry.ModBlocks;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

/** 偷来的吴家白菜。对着耕地可以种回去，吃了会暂时变壮。 */
public class WuCabbageItem extends Item {
    public WuCabbageItem() {
        super(new Properties().food(new FoodProperties.Builder()
                .nutrition(6)
                .saturationMod(0.8f)
                .alwaysEat()
                .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1), 1.0f)
                .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 600, 1), 1.0f)
                .build()));
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.getBlockState(ctx.getClickedPos()).is(Blocks.FARMLAND)) return InteractionResult.PASS;
        var above = ctx.getClickedPos().above();
        if (!level.getBlockState(above).isAir()) return InteractionResult.PASS;
        if (!level.isClientSide()) {
            level.setBlock(above, ModBlocks.WU_CABBAGE_CROP.get().defaultBlockState(), 3);
            if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (entity instanceof ServerPlayer player) {
            player.displayClientMessage(Component.translatable("message.wujia_village.cabbage"), true);
        }
        return result;
    }
}
