package com.wujiacun.wujia.portal;

import com.wujiacun.wujia.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Optional;

/**
 * 吴家村传送门形状检测器：与下界传送门同构（4x5 最小框，21x21 最大框），
 * 但框架必须是云朵方块，内部填充为吴家村传送门方块。
 */
public class WujiaPortalShape {
    public final BlockPos bottomLeft; // 内部区域最小角
    public final int width;
    public final int height;
    public final Direction.Axis axis;

    private WujiaPortalShape(BlockPos bottomLeft, int width, int height, Direction.Axis axis) {
        this.bottomLeft = bottomLeft;
        this.width = width;
        this.height = height;
        this.axis = axis;
    }

    public static Optional<WujiaPortalShape> detect(BlockGetter level, BlockPos pos, Direction.Axis axis) {
        if (axis == Direction.Axis.Y || !isInterior(level, pos)) return Optional.empty();

        Direction neg = axis == Direction.Axis.X ? Direction.WEST : Direction.NORTH;
        Direction posDir = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;

        BlockPos minP = pos;
        for (int steps = 0; isInterior(level, minP.relative(neg)); steps++) {
            if (steps >= 20) return Optional.empty();
            minP = minP.relative(neg);
        }
        BlockPos maxP = pos;
        for (int steps = 0; isInterior(level, maxP.relative(posDir)); steps++) {
            if (steps >= 20) return Optional.empty();
            maxP = maxP.relative(posDir);
        }

        int width;
        if (axis == Direction.Axis.X) {
            width = maxP.getX() - minP.getX() + 1;
        } else {
            width = maxP.getZ() - minP.getZ() + 1;
        }
        if (width < 2 || width > 21) return Optional.empty();

        BlockPos bottom = pos;
        for (int steps = 0; isInterior(level, bottom.below()); steps++) {
            if (steps >= 20) return Optional.empty();
            bottom = bottom.below();
        }
        BlockPos top = pos;
        for (int steps = 0; isInterior(level, top.above()); steps++) {
            if (steps >= 20) return Optional.empty();
            top = top.above();
        }
        int height = top.getY() - bottom.getY() + 1;
        if (height < 3 || height > 21) return Optional.empty();

        // 内部区域基准角（最小轴坐标 + 最低 y）
        BlockPos base;
        if (axis == Direction.Axis.X) {
            base = new BlockPos(minP.getX(), bottom.getY(), pos.getZ());
        } else {
            base = new BlockPos(pos.getX(), bottom.getY(), minP.getZ());
        }

        // 校验整个矩形 + 框架
        for (int w = -1; w <= width; w++) {
            for (int h = -1; h <= height; h++) {
                BlockPos p = rel(base, axis, w, h);
                if (level.isOutsideBuildHeight(p)) return Optional.empty();
                BlockState s = level.getBlockState(p);
                if (w >= 0 && w < width && h >= 0 && h < height) {
                    if (!isInterior(level, p)) return Optional.empty();
                } else {
                    if (!s.is(ModBlocks.CLOUD_BLOCK.get())) return Optional.empty();
                }
            }
        }
        return Optional.of(new WujiaPortalShape(base, width, height, axis));
    }

    private static BlockPos rel(BlockPos base, Direction.Axis axis, int alongAxis, int dy) {
        if (axis == Direction.Axis.X) return base.offset(alongAxis, dy, 0);
        return base.offset(0, dy, alongAxis);
    }

    private static boolean isInterior(BlockGetter level, BlockPos p) {
        if (level.isOutsideBuildHeight(p)) return false;
        BlockState s = level.getBlockState(p);
        return s.isAir() || s.canBeReplaced() || s.is(ModBlocks.WUJIA_PORTAL.get());
    }

    public void fill(LevelAccessor level) {
        for (int w = 0; w < width; w++) {
            for (int h = 0; h < height; h++) {
                BlockPos p = rel(bottomLeft, axis, w, h);
                level.setBlock(p, ModBlocks.WUJIA_PORTAL.get().defaultBlockState()
                        .setValue(net.minecraft.world.level.block.state.properties.BlockStateProperties.HORIZONTAL_AXIS, axis), 18);
            }
        }
    }
}
