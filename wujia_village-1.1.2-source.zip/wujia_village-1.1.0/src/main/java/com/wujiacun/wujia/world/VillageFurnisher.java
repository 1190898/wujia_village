package com.wujiacun.wujia.world;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.world.WujiaVillageLayout.FurnitureBlock;
import com.wujiacun.wujia.world.WujiaVillageLayout.FurnitureGroup;
import com.wujiacun.wujia.world.WujiaVillageLayout.House;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Air-only additions. Never clears clutter, alters a container, or loads a chunk. */
public final class VillageFurnisher {
    private static final int SURFACE = WujiaVillageLayout.SURFACE;
    private static final int AUTO_BATCH = 2;
    private static final int MAX_SCAN = 32;

    private VillageFurnisher() {}

    public static final class Report {
        public int recognized, unloaded, unrecognized, alreadyProcessed, blocks, containers, collisions, modified;
        public final List<String> details = new ArrayList<>();
        public String summary() {
            return "recognized=" + recognized + ", unloaded=" + unloaded + ", unrecognized=" + unrecognized
                    + ", processed=" + alreadyProcessed + ", blocks=" + blocks + ", containers=" + containers
                    + ", collisions=" + collisions + ", modified=" + modified;
        }
    }

    // Small abstraction also lets the self-test exercise the identical conservative inspector without world edits.
    interface Access {
        boolean loaded(House house);
        BlockState state(BlockPos pos);
        boolean blockEntity(BlockPos pos);
        boolean sturdy(BlockPos pos, Direction face);
        boolean clear(BlockPos pos);
    }

    private record Inspection(boolean loaded, boolean recognized, boolean modified,
                              int containers, int collisions, List<FurnitureGroup> additions, String reason) {}

    public static void tick(ServerLevel level) {
        if (!level.dimension().equals(WujiaVillageMod.WUJIA_DIM) || level.getGameTime() % 100L != 0) return;
        Set<House> candidates = new LinkedHashSet<>();
        // Bound both descriptor collection and the number of complete houses inspected globally, not per player.
        for (ServerPlayer player : level.players()) {
            candidates.addAll(WujiaVillageLayout.housesNear(player.blockPosition(), 40));
            if (candidates.size() >= MAX_SCAN) break;
        }
        Report report = process(level, List.copyOf(candidates), true, AUTO_BATCH);
        if (report.recognized > 0) WujiaVillageMod.LOGGER.info("[furniture] {} {}", report.summary(), report.details);
    }

    public static Report around(ServerLevel level, BlockPos center, int radius, boolean repair) {
        if (!level.dimension().equals(WujiaVillageMod.WUJIA_DIM)) return new Report();
        return process(level, WujiaVillageLayout.housesNear(center, Math.max(1, Math.min(64, radius))), repair, MAX_SCAN);
    }

    private static Report process(ServerLevel level, List<House> houses, boolean repair, int budget) {
        Report report = new Report();
        VillageFurnitureData data = VillageFurnitureData.get(level);
        Access access = access(level);
        int inspected = 0, scanned = 0;
        for (House h : houses) {
            if (++scanned > MAX_SCAN) break;
            if (data.processed(h.id())) {
                report.alreadyProcessed++;
                report.details.add(h.id() + " " + data.outcome(h.id()));
                continue;
            }
            if (!access.loaded(h)) { report.unloaded++; continue; }
            if (inspected++ >= budget) break;
            Inspection result = inspect(access, h);
            if (!result.recognized()) {
                report.unrecognized++;
                report.details.add(h.id() + " " + result.reason());
                continue; // Incomplete/unrecognized buildings are not permanently marked.
            }
            report.recognized++;
            report.containers += result.containers();
            report.collisions += result.collisions();
            if (result.modified()) report.modified++;
            int added = 0;
            for (FurnitureGroup group : result.additions()) {
                if (!repair || placeGroup(level, group)) added += group.blocks().size();
                else report.collisions++;
            }
            report.blocks += added;
            String outcome = result.reason() + "; blocks=" + added;
            report.details.add(h.id() + " " + outcome);
            // A recognized loaded building gets exactly one conservative attempt, even if some groups conflict.
            if (repair) data.record(h.id(), outcome);
        }
        return report;
    }

    static Access access(ServerLevel level) {
        return new Access() {
            @Override public boolean loaded(House h) {
                // getChunkNow does not generate or force-load; require the apron as well for safe neighbour reads.
                for (int cx = Math.floorDiv(h.x0() - 1, 16); cx <= Math.floorDiv(h.x1() + 1, 16); cx++) {
                    for (int cz = Math.floorDiv(h.z0() - 1, 16); cz <= Math.floorDiv(h.z1() + 1, 16); cz++) {
                        if (level.getChunkSource().getChunkNow(cx, cz) == null) return false;
                    }
                }
                return true;
            }
            @Override public BlockState state(BlockPos p) { return level.getBlockState(p); }
            @Override public boolean blockEntity(BlockPos p) { return level.getBlockEntity(p) != null; }
            @Override public boolean sturdy(BlockPos p, Direction face) {
                return state(p).isFaceSturdy(level, p, face);
            }
            @Override public boolean clear(BlockPos p) {
                BlockState s = state(p);
                return s.getFluidState().isEmpty() && (s.getCollisionShape(level, p).isEmpty() || s.getBlock() instanceof CarpetBlock);
            }
        };
    }

    static boolean recognized(Access access, House h) { return inspect(access, h).recognized(); }
    static List<FurnitureGroup> planned(Access access, House h) { return inspect(access, h).additions(); }

    private static Inspection inspect(Access a, House h) {
        if (!a.loaded(h)) return new Inspection(false, false, false, 0, 0, List.of(), "unloaded");
        // The historic generator used the same floors and wall footprint. Ignore door open/powered state.
        for (int x = h.x0(); x <= h.x1(); x++) {
            for (int z = h.z0(); z <= h.z1(); z++) {
                BlockPos floor = new BlockPos(x, SURFACE, z);
                if (!a.state(floor).equals(WujiaVillageLayout.blockAt(x, SURFACE, z))) return rejected("floor modified");
                if (x != h.x0() && x != h.x1() && z != h.z0() && z != h.z1()) continue;
                for (int y = SURFACE + 1; y <= SURFACE + 3; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState want = WujiaVillageLayout.blockAt(x, y, z), actual = a.state(p);
                    boolean match = want.getBlock() instanceof DoorBlock
                            ? actual.is(want.getBlock()) && actual.getValue(DoorBlock.HALF) == want.getValue(DoorBlock.HALF)
                              && actual.getValue(DoorBlock.FACING) == want.getValue(DoorBlock.FACING)
                            : actual.equals(want);
                    if (!match) return rejected("shell/door modified or incomplete");
                }
            }
        }
        // Require a complete ceiling, but accept historic bottom slabs (the old lantern lacked support).
        for (int x = h.x0(); x <= h.x1(); x++) {
            for (int z = h.z0(); z <= h.z1(); z++) {
                BlockState ceiling = a.state(new BlockPos(x, SURFACE + 4, z));
                if (ceiling.isAir() || !ceiling.blocksMotion()) return rejected("ceiling incomplete");
            }
        }
        for (int x = h.doorX() - 1; x <= h.doorX() + 1; x++) {
            for (int z = h.z1() - 2; z <= h.z1() - 1; z++) {
                for (int y = SURFACE + 1; y <= SURFACE + 2; y++) {
                    if (!a.clear(new BlockPos(x, y, z))) return new Inspection(true, true, true, 0, 1,
                            List.of(), "doorway obstructed; whole house skipped");
                }
            }
        }
        int containers = 0, collisions = 0;
        List<FurnitureGroup> additions = new ArrayList<>();
        List<String> reasons = new ArrayList<>();
        for (FurnitureGroup group : WujiaVillageLayout.furniturePlan(h)) {
            // Even creating an empty container could merge/update an existing inventory. Never do so in migration.
            if (group.container()) { containers++; continue; }
            if (group.blocks().stream().allMatch(b -> a.state(b.pos()).equals(b.state()))) continue;
            String conflict = groupConflict(a, h, group);
            if (!conflict.isEmpty()) { collisions++; reasons.add(group.name() + ":" + conflict); }
            else additions.add(group);
        }
        return new Inspection(true, true, collisions > 0, containers, collisions, List.copyOf(additions),
                reasons.isEmpty() ? "safe; containers untouched" : String.join(", ", reasons) + "; containers untouched");
    }

    private static Inspection rejected(String reason) {
        return new Inspection(true, false, true, 0, 0, List.of(), reason);
    }

    private static String groupConflict(Access a, House h, FurnitureGroup group) {
        Set<BlockPos> positions = new HashSet<>();
        for (FurnitureBlock b : group.blocks()) positions.add(b.pos());
        for (FurnitureBlock b : group.blocks()) {
            BlockPos p = b.pos();
            if (!a.state(p).isAir() || a.blockEntity(p)) return "occupied/partial group";
            if (!h.contains(p.getX(), p.getZ()) || h.clearance(p.getX(), p.getZ())) return "door clearance";
            if (p.getY() == SURFACE + 1 && !a.sturdy(p.below(), Direction.UP)) return "unsupported floor";
            if (b.state().is(Blocks.LANTERN) && !a.sturdy(p.above(), Direction.DOWN)) return "unsupported lantern";
            if (b.state().is(Blocks.OAK_PRESSURE_PLATE) && !positions.contains(p.below())) return "unsupported table";
            if (b.state().getBlock() instanceof BedBlock) {
                if (!a.clear(p.above())) return "bed headroom blocked";
                if (b.state().getValue(BedBlock.PART) == net.minecraft.world.level.block.state.properties.BedPart.FOOT
                        && (!a.clear(p.east()) || !a.clear(p.east().above()))) return "bed approach blocked";
            }
            // Avoid updating any existing inventory immediately next to an addition.
            for (Direction d : Direction.values()) if (a.blockEntity(p.relative(d))) return "adjacent block entity";
        }
        return "";
    }

    /** Stages a COMPLETE air-only group without shape updates, then notifies after both bed halves exist. */
    static boolean placeGroup(ServerLevel level, FurnitureGroup group) {
        if (group.container()) return false;
        for (FurnitureBlock b : group.blocks()) {
            if (!level.hasChunkAt(b.pos()) || !level.getBlockState(b.pos()).isAir() || level.getBlockEntity(b.pos()) != null) return false;
            for (Direction d : Direction.values()) if (level.getBlockEntity(b.pos().relative(d)) instanceof Container) return false;
        }
        List<FurnitureBlock> staged = new ArrayList<>();
        for (FurnitureBlock b : group.blocks()) {
            if (!level.setBlock(b.pos(), b.state(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE)) {
                rollback(level, staged);
                return false;
            }
            staged.add(b);
        }
        for (FurnitureBlock b : staged) {
            if (!b.state().canSurvive(level, b.pos())) { rollback(level, staged); return false; }
            // Validate only OUR new block's resolved shape. Never propagate shape rewrites to old neighbours.
            BlockState resolved = b.state();
            for (Direction direction : Direction.values()) {
                BlockPos neighbour = b.pos().relative(direction);
                resolved = resolved.updateShape(direction, level.getBlockState(neighbour), level, b.pos(), neighbour);
            }
            if (!resolved.equals(b.state())) { rollback(level, staged); return false; }
        }
        for (FurnitureBlock b : staged) {
            // The complete group already exists before normal neighbour notifications (especially both bed halves).
            level.updateNeighborsAt(b.pos(), b.state().getBlock());
        }
        for (FurnitureBlock b : staged) {
            if (!level.getBlockState(b.pos()).equals(b.state())) { rollback(level, staged); return false; }
        }
        return true;
    }

    private static void rollback(ServerLevel level, List<FurnitureBlock> staged) {
        // Only our newly placed non-container blocks can be removed; never any pre-existing nonair state.
        for (FurnitureBlock b : staged) {
            if (level.getBlockState(b.pos()).equals(b.state())) {
                level.setBlock(b.pos(), Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            }
        }
    }
}
