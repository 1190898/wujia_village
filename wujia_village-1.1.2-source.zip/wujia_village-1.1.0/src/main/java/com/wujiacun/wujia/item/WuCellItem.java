package com.wujiacun.wujia.item;

import com.wujiacun.wujia.portal.WujiaPortalShape;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Optional;

/**
 * 吴家细胞：蕴含宇宙本源之力的激活物。
 * 对着云朵门框内部点一下，门就亮了。
 */
public class WuCellItem extends Item {
    public WuCellItem() {
        super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos clicked = ctx.getClickedPos();
        BlockPos target = clicked.relative(ctx.getClickedFace());

        if (level.isClientSide()) return InteractionResult.SUCCESS;

        BlockPos[] candidates = {target, clicked};
        for (BlockPos cand : candidates) {
            for (Direction.Axis axis : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
                Optional<WujiaPortalShape> shape = WujiaPortalShape.detect(level, cand, axis);
                if (shape.isPresent()) {
                    shape.get().fill(level);
                    BlockPos center = shape.get().bottomLeft;
                    level.playSound(null, center, SoundEvents.PORTAL_TRIGGER, SoundSource.BLOCKS, 1.0f, 1.0f);
                    level.playSound(null, center, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0f, 1.2f);
                    if (ctx.getPlayer() != null) {
                        ctx.getPlayer().displayClientMessage(
                                Component.literal("§b[吴家村]§f 门已点亮。村口石碑在门的另一边。"), true);
                    }
                    return InteractionResult.CONSUME;
                }
            }
        }

        if (ctx.getPlayer() != null) {
            ctx.getPlayer().displayClientMessage(
                    Component.literal("§b[吴家村]§c 这里构不成一座合格的门（云朵框 + 至少 2x3 内部空间）。"), true);
        }
        return InteractionResult.FAIL;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wu_cell.tooltip").withStyle(ChatFormatting.AQUA));
    }
}
