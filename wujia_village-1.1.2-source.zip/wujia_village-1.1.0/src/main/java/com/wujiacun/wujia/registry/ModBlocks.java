package com.wujiacun.wujia.registry;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.block.CloudBlock;
import com.wujiacun.wujia.block.WuCabbageCropBlock;
import com.wujiacun.wujia.block.WujiaAirBlock;
import com.wujiacun.wujia.block.WujiaPortalBlock;
import com.wujiacun.wujia.block.WujiaSteleBlock;
import com.wujiacun.wujia.block.WujiaStoneBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, WujiaVillageMod.MODID);

    /** 云朵方块：吴家村传送门框架，9 羊毛+羽毛合成 */
    public static final RegistryObject<Block> CLOUD_BLOCK =
            BLOCKS.register("cloud_block", CloudBlock::new);

    /** 吴家村传送门：淡蓝色，动画参考下界传送门 */
    public static final RegistryObject<Block> WUJIA_PORTAL =
            BLOCKS.register("wujia_portal", WujiaPortalBlock::new);

    /** 村口石碑 */
    public static final RegistryObject<Block> WUJIA_STELE =
            BLOCKS.register("wujia_stele", WujiaSteleBlock::new);

    /** 踢一下会弹人的石头 */
    public static final RegistryObject<Block> WUJIA_STONE =
            BLOCKS.register("wujia_stone", WujiaStoneBlock::new);

    /** 田里的吴家白菜 */
    public static final RegistryObject<Block> WU_CABBAGE_CROP =
            BLOCKS.register("wu_cabbage_crop", WuCabbageCropBlock::new);

    /** 吴家空气：站进去能短暂飞行，附带一堆正面效果 */
    public static final RegistryObject<Block> WUJIA_AIR =
            BLOCKS.register("wujia_air", WujiaAirBlock::new);

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
