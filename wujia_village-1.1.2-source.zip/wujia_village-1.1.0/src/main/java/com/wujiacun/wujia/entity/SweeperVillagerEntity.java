package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Broom sweep is a timed common-controller contact frame, not an independent AoE pulse. */
public class SweeperVillagerEntity extends WuVillagerBase {
    public SweeperVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.sweeper_villager");
    }
    @Override protected String greetKey() { return "message.wujia_village.greet.sweeper"; }
    @Override public void tick() {
        super.tick();
        if (level().isClientSide()) return;
        if (tickCount == 1 && (getMainHandItem().isEmpty() || getMainHandItem().is(net.minecraft.world.item.Items.STICK))) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.WU_BROOM.get()));
            setDropChance(EquipmentSlot.MAINHAND, 0);
        }
        if (level() instanceof ServerLevel sl && tickCount % 30 == 0) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.1, getZ(), 2, 0.3, 0.02, 0.3, 0.01);
        }
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (!getMainHandItem().isEmpty()) tag.put("WujiaBroom", getMainHandItem().save(new CompoundTag()));
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("WujiaBroom")) {
            ItemStack item = ItemStack.of(tag.getCompound("WujiaBroom"));
            if (!item.isEmpty()) { setItemSlot(EquipmentSlot.MAINHAND, item); setDropChance(EquipmentSlot.MAINHAND, 0); }
        }
    }
}
