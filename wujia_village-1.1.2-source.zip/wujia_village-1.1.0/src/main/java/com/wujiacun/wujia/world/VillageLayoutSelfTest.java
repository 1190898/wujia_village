package com.wujiacun.wujia.world;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.world.WujiaVillageLayout.FurnitureBlock;
import com.wujiacun.wujia.world.WujiaVillageLayout.FurnitureGroup;
import com.wujiacun.wujia.world.WujiaVillageLayout.House;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Invoked only by the main opt-in self-test. Does not load chunks or alter existing nonair blocks. */
public final class VillageLayoutSelfTest {
    private static final int S = WujiaVillageLayout.SURFACE;
    private VillageLayoutSelfTest() {}

    public static void run(ServerLevel level, List<String> failures) {
        List<House> houses = new ArrayList<>(WujiaVillageLayout.plazaHouses());
        Set<Integer> styles = new HashSet<>();
        boolean negative = false, crossChunk = false;
        for (int cx = -7; cx <= 7; cx++) {
            for (int cz = -7; cz <= 7; cz++) {
                House h = WujiaVillageLayout.plotHouse(cx, cz);
                if (h == null) continue;
                if (styles.add(h.kind()) || cx == -2 && cz == -2) houses.add(h);
                negative |= h.x0() < 0 && h.z0() < 0;
                crossChunk |= Math.floorDiv(h.x0(), 16) != Math.floorDiv(h.x1(), 16)
                        || Math.floorDiv(h.z0(), 16) != Math.floorDiv(h.z1(), 16);
            }
        }
        check(failures, "layout all five house styles", styles.size() == 5);
        check(failures, "layout negative and cross-chunk samples", negative && crossChunk);
        House west = WujiaVillageLayout.plazaHouses().get(0);
        check(failures, "layout exact west plaza bounds", west.x0() == -18 && west.z0() == -6 && west.x1() == -10 && west.z1() == 2);
        check(failures, "layout plaza/buffer excluded from plots", WujiaVillageLayout.plotHouse(-1, 0) == null
                && WujiaVillageLayout.houseAt(-7, -9) == null);
        for (House h : houses) checkHouse(h, failures);
        checkFarms(failures);
        checkMigration(west, failures);
        checkAtomicWorldGroups(level, failures);
    }

    private static void checkHouse(House h, List<String> failures) {
        String label = "layout house " + h.id();
        Map<BlockPos, BlockState> planned = new HashMap<>();
        boolean unique = true, generated = true, inside = true, supported = true, beds = true, chest = true;
        int bedCount = 0;
        for (FurnitureGroup group : WujiaVillageLayout.furniturePlan(h)) {
            for (FurnitureBlock b : group.blocks()) {
                unique &= planned.put(b.pos(), b.state()) == null;
                BlockPos p = b.pos();
                inside &= p.getX() > h.x0() && p.getX() < h.x1() && p.getZ() > h.z0() && p.getZ() < h.z1()
                        && !h.clearance(p.getX(), p.getZ());
                generated &= b.state().equals(at(p)) && b.state().equals(WujiaVillageLayout.furnitureAt(p.getX(), p.getY(), p.getZ()));
                if (p.getY() == S + 1) supported &= at(p.below()).blocksMotion();
                if (b.state().is(Blocks.OAK_PRESSURE_PLATE)) supported &= at(p.below()).is(Blocks.OAK_FENCE);
                if (b.state().is(Blocks.LANTERN)) supported &= at(p.above()).is(WujiaVillageLayout.blockAt(h.x0() + 1, S, h.z0() + 1).getBlock());
                if (b.state().getBlock() instanceof BedBlock) {
                    bedCount++;
                    Direction facing = b.state().getValue(BedBlock.FACING);
                    BedPart part = b.state().getValue(BedBlock.PART);
                    BlockState other = at(p.relative(part == BedPart.FOOT ? facing : facing.getOpposite()));
                    beds &= other.is(b.state().getBlock()) && other.getValue(BedBlock.FACING) == facing
                            && other.getValue(BedBlock.PART) != part && at(p.above()).isAir()
                            && (part != BedPart.FOOT || walkable(p.east()));
                }
                if (b.state().is(Blocks.CHEST)) {
                    ChestType type = b.state().getValue(BlockStateProperties.CHEST_TYPE);
                    if (group.blocks().size() == 1) chest &= type == ChestType.SINGLE;
                    else {
                        Direction facing = b.state().getValue(BlockStateProperties.HORIZONTAL_FACING);
                        Direction partner = type == ChestType.LEFT ? facing.getClockWise() : facing.getCounterClockWise();
                        BlockState other = at(p.relative(partner));
                        chest &= other.is(Blocks.CHEST) && other.getValue(BlockStateProperties.HORIZONTAL_FACING) == facing
                                && other.getValue(BlockStateProperties.CHEST_TYPE) != type;
                    }
                }
            }
        }
        check(failures, label + " unique furniture/no bed-table overlap", unique && inside);
        check(failures, label + " generation/descriptor parity", generated);
        check(failures, label + " support and bed pairs", supported && beds && bedCount == 2);
        check(failures, label + " explicit chest type/pair", chest);
        BlockState lower = at(h.door()), upper = at(h.door().above());
        check(failures, label + " complete door", lower.getBlock() instanceof DoorBlock && upper.is(lower.getBlock())
                && lower.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER
                && upper.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER);
        boolean clear = true;
        for (int x = h.doorX() - 1; x <= h.doorX() + 1; x++) {
            for (int z = h.z1() - 2; z < h.z1(); z++) clear &= walkable(new BlockPos(x, S + 1, z));
        }
        check(failures, label + " doorway and route to road", clear && routeToRoad(h));
        check(failures, label + " no outer-wall spur; eaves present",
                at(new BlockPos(h.x0(), S + 1, h.z0() - 1)).isAir()
                        && !at(new BlockPos(h.x0(), S + 4, h.z0() - 1)).isAir());
        if (h.kind() == 2) {
            BlockState rail = at(new BlockPos(h.x0() - 1, S + 5, h.z0() - 1));
            check(failures, label + " connected flat-roof rail", rail.is(Blocks.BRICK_WALL)
                    && rail.getValue(BlockStateProperties.EAST_WALL) != net.minecraft.world.level.block.state.properties.WallSide.NONE
                    && rail.getValue(BlockStateProperties.SOUTH_WALL) != net.minecraft.world.level.block.state.properties.WallSide.NONE);
        }
    }

    private static boolean routeToRoad(House h) {
        Set<BlockPos> visited = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(h.door().south());
        while (!queue.isEmpty() && visited.size() < 600) {
            BlockPos p = queue.removeFirst();
            if (!visited.add(p) || !walkable(p)) continue;
            if (h.plaza() ? Math.abs(p.getX()) <= 2 : WujiaVillageLayout.isRoad(p.getX(), p.getZ())) return true;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos n = p.relative(d);
                if (n.getX() >= Math.min(h.x0() - 3, h.plaza() ? -2 : h.x0() - 3)
                        && n.getX() <= Math.max(h.x1() + 3, h.plaza() ? 2 : h.x1() + 3)
                        && n.getZ() > h.z1() && n.getZ() <= h.z1() + WujiaVillageLayout.PLOT) queue.add(n);
            }
        }
        return false;
    }

    private static boolean walkable(BlockPos p) {
        BlockState feet = at(p);
        return at(p.below()).blocksMotion() && (feet.isAir() || feet.getBlock() instanceof net.minecraft.world.level.block.CarpetBlock)
                && at(p.above()).isAir();
    }

    private static void checkFarms(List<String> failures) {
        BlockPos sample = WujiaVillageLayout.sampleFarmPos();
        int ox = Math.floorDiv(sample.getX(), 48) * 48, oz = Math.floorDiv(sample.getZ(), 48) * 48;
        boolean covered = true, crops = true;
        int count = 0;
        for (int x = ox + 10; x <= ox + 30; x++) {
            for (int z = oz + 10; z <= oz + 30; z++) {
                if (!WujiaVillageLayout.blockAt(x, S, z).is(Blocks.FARMLAND)) continue;
                count++;
                covered &= waterNear(x, z);
                crops &= !WujiaVillageLayout.blockAt(x, S + 1, z).isAir();
            }
        }
        for (int x = -12; x <= -7; x++) for (int z = 8; z <= 12; z++) {
            if (WujiaVillageLayout.blockAt(x, S, z).is(Blocks.FARMLAND)) covered &= waterNear(x, z);
        }
        check(failures, "layout farm and plaza irrigation", count > 200 && covered && crops);
        boolean entrance = true;
        for (int z = oz + 5; z <= oz + 48; z++) entrance &= walkable(new BlockPos(ox + 20, S + 1, z));
        check(failures, "layout farm open entrances and road approach", entrance);
        BlockState corner = WujiaVillageLayout.blockAt(ox + 10, S + 1, oz + 10);
        check(failures, "layout explicitly connected farm fences", corner.getValue(BlockStateProperties.SOUTH)
                && corner.getValue(BlockStateProperties.EAST));
    }

    private static boolean waterNear(int x, int z) {
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            if (WujiaVillageLayout.blockAt(x + dx, S, z + dz).is(Blocks.WATER)) return true;
        }
        return false;
    }

    private static void checkMigration(House h, List<String> failures) {
        Fixture empty = new Fixture(h);
        check(failures, "migration recognizes complete empty legacy shell", VillageFurnisher.recognized(empty, h));
        List<FurnitureGroup> safe = VillageFurnisher.planned(empty, h);
        check(failures, "migration never plans containers", !safe.isEmpty() && safe.stream().noneMatch(FurnitureGroup::container));
        empty.loaded = false;
        check(failures, "migration incomplete cross-chunk building deferred", !VillageFurnisher.recognized(empty, h)
                && VillageFurnisher.planned(empty, h).isEmpty());
        empty.loaded = true;
        empty.overrides.put(new BlockPos(h.x0() + 1, S, h.z0() + 1), Blocks.AIR.defaultBlockState());
        check(failures, "migration modified/missing floor rejected", !VillageFurnisher.recognized(empty, h));
        Fixture partialBed = new Fixture(h);
        FurnitureGroup bed = WujiaVillageLayout.furniturePlan(h).stream().filter(g -> g.name().equals("bed")).findFirst().orElseThrow();
        partialBed.overrides.put(bed.blocks().get(0).pos(), bed.blocks().get(0).state());
        check(failures, "migration never completes/replaces a partial bed", VillageFurnisher.planned(partialBed, h).stream().noneMatch(g -> g.name().equals("bed")));
        Fixture clutter = new Fixture(h);
        BlockPos clutterPos = h.door().north();
        clutter.overrides.put(clutterPos, Blocks.CHEST.defaultBlockState());
        check(failures, "migration blocked doorway retained; whole house skipped", VillageFurnisher.recognized(clutter, h)
                && VillageFurnisher.planned(clutter, h).isEmpty() && clutter.state(clutterPos).is(Blocks.CHEST));
        Fixture oldTable = new Fixture(h);
        BlockPos oldTop = new BlockPos(h.x0() + 1, S + 2, h.z0() + 2);
        oldTable.overrides.put(oldTop, Blocks.OAK_PRESSURE_PLATE.defaultBlockState());
        check(failures, "migration old bed-table collision skipped without demolition",
                VillageFurnisher.planned(oldTable, h).stream().noneMatch(g -> g.name().equals("bed"))
                        && oldTable.state(oldTop).is(Blocks.OAK_PRESSURE_PLATE));
        Fixture oldRoof = new Fixture(h);
        oldRoof.overrides.put(new BlockPos(h.doorX(), S + 4, h.z0() + 2), Blocks.OAK_SLAB.defaultBlockState());
        check(failures, "migration historic unsupported lantern skipped", VillageFurnisher.recognized(oldRoof, h)
                && VillageFurnisher.planned(oldRoof, h).stream().noneMatch(g -> g.name().equals("light")));
        VillageFurnitureData original = new VillageFurnitureData();
        original.record(h.id(), "skipped collision; containers untouched");
        VillageFurnitureData reloaded = VillageFurnitureData.load(original.save(new CompoundTag()));
        reloaded.record(h.id(), "must not replace prior outcome");
        check(failures, "migration marker survives serialize/reload and remains once-only", reloaded.processed(h.id())
                && reloaded.outcome(h.id()).equals(original.outcome(h.id())) && !reloaded.processed("unrecognized"));
    }

    private static final class Fixture implements VillageFurnisher.Access {
        final House house;
        final Map<BlockPos, BlockState> overrides = new HashMap<>();
        boolean loaded = true;
        Fixture(House house) { this.house = house; }
        @Override public boolean loaded(House h) { return loaded; }
        @Override public BlockState state(BlockPos p) {
            if (overrides.containsKey(p)) return overrides.get(p);
            return WujiaVillageLayout.furnitureAt(p.getX(), p.getY(), p.getZ()) == null ? at(p) : Blocks.AIR.defaultBlockState();
        }
        @Override public boolean blockEntity(BlockPos p) { return state(p).hasBlockEntity(); }
        @Override public boolean sturdy(BlockPos p, Direction d) {
            BlockState s = state(p);
            return s.blocksMotion() && !s.is(Blocks.OAK_SLAB);
        }
        @Override public boolean clear(BlockPos p) {
            BlockState s = state(p);
            return s.isAir() || s.getBlock() instanceof net.minecraft.world.level.block.CarpetBlock;
        }
    }

    private static void checkAtomicWorldGroups(ServerLevel level, List<String> failures) {
        // Temporary fixture high above the spawn, only if already loaded and entirely empty.
        BlockPos base = new BlockPos(6, 220, 6);
        List<BlockPos> region = BlockPos.betweenClosedStream(base.offset(-1, -1, -2), base.offset(3, 2, 3)).map(BlockPos::immutable).toList();
        boolean free = region.stream().allMatch(p -> level.hasChunkAt(p) && level.getBlockState(p).isAir());
        check(failures, "migration atomic fixture is loaded/air-only", free);
        if (!free) return;
        List<BlockPos> own = new ArrayList<>();
        try {
            for (int x = 0; x <= 2; x++) for (int z = -1; z <= 2; z++) {
                BlockPos p = base.offset(x, -1, z);
                level.setBlock(p, Blocks.OAK_PLANKS.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                own.add(p);
            }
            BlockState foot = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.NORTH).setValue(BedBlock.PART, BedPart.FOOT);
            FurnitureGroup bed = new FurnitureGroup("bed", false, List.of(new FurnitureBlock(base, foot),
                    new FurnitureBlock(base.north(), foot.setValue(BedBlock.PART, BedPart.HEAD))));
            own.add(base); own.add(base.north());
            boolean placed = VillageFurnisher.placeGroup(level, bed);
            check(failures, "migration bed atomic placement survives real neighbour updates", placed
                    && level.getBlockState(base).equals(foot) && level.getBlockState(base.north()).equals(bed.blocks().get(1).state()));
            BlockPos table = base.offset(2, 0, 1);
            FurnitureGroup tableGroup = new FurnitureGroup("table", false, List.of(
                    new FurnitureBlock(table, Blocks.OAK_FENCE.defaultBlockState()),
                    new FurnitureBlock(table.above(), Blocks.OAK_PRESSURE_PLATE.defaultBlockState())));
            own.add(table); own.add(table.above());
            check(failures, "migration table support survives real neighbour updates", VillageFurnisher.placeGroup(level, tableGroup)
                    && level.getBlockState(table.above()).is(Blocks.OAK_PRESSURE_PLATE));
            BlockState before = level.getBlockState(base);
            check(failures, "migration repeated bed placement does not replace nonair", !VillageFurnisher.placeGroup(level, bed)
                    && level.getBlockState(base).equals(before));
            FurnitureGroup container = new FurnitureGroup("chest", true,
                    List.of(new FurnitureBlock(base.south(), Blocks.CHEST.defaultBlockState())));
            check(failures, "migration refuses container creation in real world", !VillageFurnisher.placeGroup(level, container)
                    && level.getBlockState(base.south()).isAir());
            BlockPos oldFence = base.offset(0, 0, 2), newCrafting = oldFence.east();
            BlockState oldState = Blocks.OAK_FENCE.defaultBlockState();
            level.setBlock(oldFence, oldState, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            own.add(oldFence); own.add(newCrafting);
            FurnitureGroup besideOldBlock = new FurnitureGroup("crafting", false,
                    List.of(new FurnitureBlock(newCrafting, Blocks.CRAFTING_TABLE.defaultBlockState())));
            check(failures, "migration preserves existing adjacent nonair shape exactly",
                    VillageFurnisher.placeGroup(level, besideOldBlock) && level.getBlockState(oldFence).equals(oldState)
                            && !level.getBlockState(oldFence).getValue(BlockStateProperties.EAST));
        } finally {
            for (int i = own.size() - 1; i >= 0; i--) {
                BlockPos p = own.get(i);
                if (level.getBlockEntity(p) instanceof net.minecraft.world.Container) continue;
                level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            }
        }
    }

    private static BlockState at(BlockPos p) { return WujiaVillageLayout.blockAt(p.getX(), p.getY(), p.getZ()); }
    private static void check(List<String> failures, String name, boolean ok) {
        WujiaVillageMod.LOGGER.info("[selftest] {} {}", ok ? "OK" : "FAIL", name);
        if (!ok) failures.add(name);
    }
}
