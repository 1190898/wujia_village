package com.wujiacun.wujia.entity.combat;

/** Network ordinals are shared with the client; do not reorder. */
public enum CombatAction {
    IDLE, MELEE_JAB, MELEE_SWEEP, MELEE_OVERHEAD, MELEE_THRUST,
    BLINK, SONIC, SWORDS, PALM, WATER, HIM_FLIGHT, DODGE, BLACK_HOLE;

    public static int contactTick(int duration) {
        return Math.round(duration * 0.45f);
    }
}
