package com.wujiacun.wujia.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** A flattened open hand: palm, wrist, four separated staggered fingers, and an angled thumb. */
public final class WuPalmModel {
    private final ModelPart root;
    public WuPalmModel(ModelPart root) { this.root = root; }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition hand = mesh.getRoot();
        hand.addOrReplaceChild("palm", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-6, 0, -1, 12, 2, 12), PartPose.ZERO);
        hand.addOrReplaceChild("wrist", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.7f, 0.2f, 11, 7.4f, 1.6f, 5), PartPose.ZERO);
        float[] lengths = {8, 11, 10, 7};
        for (int i = 0; i < 4; i++) {
            hand.addOrReplaceChild("finger_" + i, CubeListBuilder.create().texOffs(0, 0)
                    .addBox(-5.8f + i * 3.0f, 0.15f, -lengths[i], 2.55f, 1.7f, lengths[i]), PartPose.ZERO);
        }
        hand.addOrReplaceChild("thumb", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.5f, 0.1f, -6.0f, 3.2f, 1.8f, 7.5f),
                PartPose.offsetAndRotation(-5.2f, 0, 6.8f, 0, 0.72f, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    public void render(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        root.render(pose, vertices, light, overlay, red, green, blue, alpha);
    }
}
