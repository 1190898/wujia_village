package com.wujiacun.wujia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.HimDragonEntity;
import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.gui.screens.AccessibilityOnboardingScreen;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerStatusPinger;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.entity.PartEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.net.InetSocketAddress;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/** Opt-in, real-network in-world regression; never creates client-only test entities. */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, value = Dist.CLIENT)
public final class WuEggClientTest {
    private static final boolean ENABLED = Boolean.getBoolean("wujia.eggClient");
    private static final long TIMEOUT = TimeUnit.SECONDS.toNanos(120);
    private static final Set<ResourceLocation> TARGETS = targets();
    private static final Set<ResourceLocation> received = new HashSet<>();
    private static final Set<ResourceLocation> rendered = new HashSet<>();
    private static boolean connecting, joined, finished;
    private static long started;
    private static int readyTicks, port;
    private static ServerData server;
    private static ServerStatusPinger pinger;
    private static long pingStarted;
    private static volatile Throwable pingFailure;

    private WuEggClientTest() {}

    private static Set<ResourceLocation> targets() {
        Set<ResourceLocation> ids = new HashSet<>();
        for (String name : new String[]{"dodge_villager", "teleport_villager", "chief_villager",
                "ancestor_villager", "sweeper_villager", "guard_villager", "fisher_villager",
                "wu_chicken", "wu_dog", "him_villager", "him_dragon"}) {
            ids.add(new ResourceLocation(WujiaVillageMod.MODID, name));
        }
        return Set.copyOf(ids);
    }

    @SubscribeEvent
    public static void tick(TickEvent.RenderTickEvent event) {
        if (!ENABLED || finished || event.phase != TickEvent.Phase.END) return;
        Minecraft client = Minecraft.getInstance();
        if (started == 0) started = System.nanoTime();
        if (System.nanoTime() - started > TIMEOUT) {
            fail(client, new IllegalStateException("120-second timeout"));
            return;
        }
        try {
            if (!connecting) {
                if (client.getOverlay() != null || !(client.screen instanceof TitleScreen
                        || client.screen instanceof AccessibilityOnboardingScreen) || ++readyTicks < 20) return;
                if (server == null) {
                    port = Integer.parseInt(System.getProperty("wujia.eggPort", "25578"));
                    if (port < 1 || port > 65535) throw new IllegalArgumentException("Invalid loopback port");
                    if (client.getUser().getType() != User.Type.LEGACY) {
                        throw new IllegalStateException("Use the offline development account, not an authenticated account");
                    }
                    server = new ServerData("Local egg regression", "127.0.0.1:" + port, false);
                    server.setResourcePackStatus(ServerData.ServerPackStatus.DISABLED);
                    pinger = new ServerStatusPinger();
                    pingStarted = System.nanoTime();
                    WujiaVillageMod.LOGGER.info("[eggclient] pinging loopback {} for real Forge metadata", server.ip);
                    Thread ping = new Thread(() -> {
                        try { pinger.pingServer(server, () -> {}); }
                        catch (Throwable error) { pingFailure = error; }
                    }, "Egg client loopback status");
                    ping.setDaemon(true);
                    ping.start();
                }
                pinger.tick();
                if (pingFailure != null) throw new IllegalStateException("Loopback status ping failed", pingFailure);
                if (server.forgeData == null || server.ping < 0) {
                    if (System.nanoTime() - pingStarted > TimeUnit.SECONDS.toNanos(15)) {
                        throw new IllegalStateException("No completed loopback Forge status/pong within 15s; server may not be ticking");
                    }
                    return;
                }
                if (!"FML".equals(server.forgeData.type()) || !server.forgeData.isCompatible()) {
                    throw new IllegalStateException("Loopback server is not a compatible Forge server: " + server.forgeData);
                }
                pinger.removeAll();
                connecting = true;
                WujiaVillageMod.LOGGER.info("[eggclient] connecting to {} as offline {}; ping={}ms forge={}", server.ip,
                        client.getUser().getName(), server.ping, server.forgeData);
                ConnectScreen.startConnecting(new TitleScreen(), client,
                        new ServerAddress("127.0.0.1", port), server, false);
            } else if (client.screen instanceof DisconnectedScreen || (joined && client.getConnection() == null)) {
                throw new IllegalStateException("Server disconnected before all eleven types rendered");
            }
            if (!joined && ready(client)) {
                joined = true;
                WujiaVillageMod.LOGGER.info("[eggclient] joined loopback world {}", client.level.dimension().location());
            }
        } catch (Throwable error) {
            fail(client, error);
        }
    }

    private static boolean ready(Minecraft client) {
        if (!connecting || client.level == null || client.player == null || client.getConnection() == null
                || !client.getConnection().getConnection().isConnected()) return false;
        var remote = client.getConnection().getConnection().getRemoteAddress();
        if (!(remote instanceof InetSocketAddress address) || address.getAddress() == null
                || !address.getAddress().isLoopbackAddress() || address.getPort() != port) {
            throw new IllegalStateException("Refusing non-test connection: " + remote);
        }
        return true;
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent event) {
        if (!ENABLED || finished || event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft client = Minecraft.getInstance();
        try {
            if (!ready(client) || client.getOverlay() != null) return;
            EntityRenderDispatcher dispatcher = client.getEntityRenderDispatcher();
            MultiBufferSource.BufferSource buffers = client.renderBuffers().bufferSource();
            PoseStack pose = event.getPoseStack();
            Vec3 camera = event.getCamera().getPosition();
            float partial = event.getPartialTick();
            for (Entity entity : client.level.entitiesForRendering()) {
                ResourceLocation type = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
                if (type == null || !TARGETS.contains(type) || rendered.contains(type) || entity.isRemoved()) continue;
                // A received entity must be the actual object installed in the network client's level.
                if (client.level.getEntity(entity.getId()) != entity) {
                    throw new IllegalStateException("Untracked client entity " + type + " id=" + entity.getId());
                }
                received.add(type);
                if (type.equals(ModEntities.HIM_DRAGON.getId())) inspectDragon(entity, client);
                pose.pushPose();
                try {
                    // Match LevelRenderer's interpolation and camera-relative coordinates. Bypass only frustum culling.
                    dispatcher.render(entity,
                            Mth.lerp(partial, entity.xOld, entity.getX()) - camera.x,
                            Mth.lerp(partial, entity.yOld, entity.getY()) - camera.y,
                            Mth.lerp(partial, entity.zOld, entity.getZ()) - camera.z,
                            Mth.lerp(partial, entity.yRotO, entity.getYRot()), partial, pose, buffers,
                            dispatcher.getPackedLightCoords(entity, partial));
                    buffers.endBatch();
                } finally {
                    pose.popPose();
                }
                rendered.add(type); // Never award coverage for merely looking up a renderer.
                WujiaVillageMod.LOGGER.info("[eggclient] OK received/rendered {} entityId={} class={} renderer={} dimension={}",
                        type, entity.getId(), entity.getClass().getName(), dispatcher.getRenderer(entity).getClass().getName(),
                        client.level.dimension().location());
            }
            if (rendered.containsAll(TARGETS)) {
                finished = true;
                WujiaVillageMod.LOGGER.info("EGGCLIENT OK: all eleven packet entity types received and dispatcher-rendered {}", rendered);
                client.stop();
            }
        } catch (Throwable error) {
            fail(client, error);
        }
    }

    private static void inspectDragon(Entity entity, Minecraft client) {
        if (!(entity instanceof HimDragonEntity dragon) || entity.getType() != ModEntities.HIM_DRAGON.get()) {
            throw new IllegalStateException("Pet packet did not create the registered HimDragonEntity");
        }
        EnderDragonPart[] sub = dragon.getSubEntities();
        PartEntity<?>[] parts = dragon.getParts();
        if (sub == null || parts == null || sub.length != 8 || parts.length != sub.length) {
            throw new IllegalStateException("Pet multipart arrays are absent or malformed");
        }
        WujiaVillageMod.LOGGER.info("[eggclient] dragon id={} ref={} getSubEntities={} getParts={} sameArray={}",
                dragon.getId(), ref(dragon), ref(sub), ref(parts), sub == parts);
        Set<Integer> ids = new HashSet<>();
        ids.add(dragon.getId());
        for (int i = 0; i < sub.length; i++) {
            EnderDragonPart part = sub[i];
            if (part == null || parts[i] != part || part.getParent() != dragon || !ids.add(part.getId())) {
                throw new IllegalStateException("Pet multipart ID/reference mismatch at part " + i);
            }
            WujiaVillageMod.LOGGER.info("[eggclient] dragon part={} id={} ref={} parentId={} parentRef={} tracked={}",
                    part.name, part.getId(), ref(part), part.getParent().getId(), ref(part.getParent()),
                    client.level.getPartEntities().contains(part));
        }
    }

    private static String ref(Object object) {
        return Integer.toHexString(System.identityHashCode(object));
    }

    private static void fail(Minecraft client, Throwable error) {
        if (finished) return;
        finished = true;
        if (pinger != null) pinger.removeAll();
        Set<ResourceLocation> missing = new HashSet<>(TARGETS);
        missing.removeAll(rendered);
        WujiaVillageMod.LOGGER.error("EGGCLIENT FAIL: received=" + received + " rendered=" + rendered + " missing=" + missing, error);
        client.stop();
    }
}
