package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.entity.combat.WuCombatRules;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.util.ModDamageTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import java.util.UUID;

/** Finite nonphysical synced geometry. All damage is evaluated once on the server. */
public class WuSkillEffectEntity extends Entity {
    public static final int SONIC = 1, PALM = 2, WATER = 3, BLACK_HOLE = 4;
    public static final int PALM_DESCENT_TICK = 10, PALM_IMPACT_TICK = 24;
    public static final int BLACK_HOLE_COLLAPSE_TICK = 36;
    private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TINT = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> START = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> END_X = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Long> END_Y = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Long> END_Z = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Float> RADIUS = SynchedEntityData.defineId(WuSkillEffectEntity.class, EntityDataSerializers.FLOAT);
    private UUID ownerId;
    private float damage;
    private int age, impactCount;
    private boolean impacted;

    public WuSkillEffectEntity(EntityType<? extends WuSkillEffectEntity> type, Level level) {
        super(type, level); noPhysics = true; setNoGravity(true); setInvulnerable(true);
    }
    @Override protected void defineSynchedData() {
        entityData.define(KIND, SONIC); entityData.define(TINT, 0xFFFFFF); entityData.define(START, 0L);
        entityData.define(LIFE, 12); entityData.define(END_X, 0L); entityData.define(END_Y, 0L);
        entityData.define(END_Z, 0L); entityData.define(RADIUS, 0.38f);
    }
    public int getEffectKind() { return entityData.get(KIND); }
    public int getTint() { return entityData.get(TINT); }
    public float getEffectAge(float partialTick) { return Math.max(0, level().getGameTime() - entityData.get(START) + partialTick); }
    public int getLifetime() { return entityData.get(LIFE); }
    public Vec3 getOrigin() { return position(); }
    public Vec3 getDestination() { return new Vec3(Double.longBitsToDouble(entityData.get(END_X)),
            Double.longBitsToDouble(entityData.get(END_Y)), Double.longBitsToDouble(entityData.get(END_Z))); }
    public float getRadius() { return entityData.get(RADIUS); }
    public int getImpactCount() { return impactCount; }
    @Override public AABB getBoundingBoxForCulling() { return new AABB(getOrigin(), getDestination()).inflate(getRadius() + 1); }
    @Override public boolean shouldRenderAtSqrDistance(double distance) { return distance < 128 * 128; }

    private void configure(WuVillagerBase owner, int kind, Vec3 origin, Vec3 destination, int tint, float radius, int life, float amount) {
        ownerId = owner.getUUID(); damage = amount;
        setPos(origin); entityData.set(KIND, kind); entityData.set(TINT, tint); entityData.set(START, level().getGameTime());
        entityData.set(LIFE, life); entityData.set(RADIUS, radius);
        entityData.set(END_X, Double.doubleToLongBits(destination.x));
        entityData.set(END_Y, Double.doubleToLongBits(destination.y));
        entityData.set(END_Z, Double.doubleToLongBits(destination.z));
    }
    public static WuSkillEffectEntity castLine(ServerLevel level, WuVillagerBase owner, Vec3 from, Vec3 to, int kind, int tint, float damage) {
        if (kind != SONIC && kind != WATER || !WuCombatRules.loaded(level, new AABB(from, to).inflate(0.5))) return null;
        Vec3 end = WuCombatRules.clip(level, owner, from, to);
        WuSkillEffectEntity effect = ModEntities.SKILL_EFFECT.get().create(level);
        if (effect == null) return null;
        effect.configure(owner, kind, from, end, tint, kind == WATER ? 0.20f : 0.38f, kind == WATER ? 14 : 12, damage);
        level.addFreshEntity(effect);
        effect.hitLine(level, owner);
        return effect;
    }
    public static WuSkillEffectEntity spawnPalm(ServerLevel level, WuVillagerBase owner, Vec3 target, int tint, float damage) {
        Vec3 origin = new Vec3(target.x, Math.min(level.getMaxBuildHeight() - 2, target.y + 9), target.z);
        Vec3 intended = target.add(0, 0.06, 0);
        if (!WuCombatRules.loaded(level, new AABB(origin, intended).inflate(3.25))) return null;
        // A roof is the impact surface, never bypassed to reach somebody beneath it.
        Vec3 end = WuCombatRules.clip(level, owner, origin, intended);
        WuSkillEffectEntity effect = ModEntities.SKILL_EFFECT.get().create(level);
        if (effect == null) return null;
        effect.configure(owner, PALM, origin, end, tint, 3.1f, 32, damage);
        level.addFreshEntity(effect);
        return effect;
    }
    public static WuSkillEffectEntity spawnBlackHole(ServerLevel level, WuVillagerBase owner, Vec3 target, int tint, float damage) {
        Vec3 center = new Vec3(target.x, target.y + 1.6, target.z);
        if (!WuCombatRules.loaded(level, new AABB(center, center).inflate(10.0))) return null;
        WuSkillEffectEntity effect = ModEntities.SKILL_EFFECT.get().create(level);
        if (effect == null) return null;
        effect.configure(owner, BLACK_HOLE, center, center, tint, 8.5f, 50, damage);
        level.addFreshEntity(effect);
        return effect;
    }
    private void hitLine(ServerLevel level, WuVillagerBase owner) {
        if (impacted) return;
        impacted = true; impactCount++;
        Vec3 from = getOrigin(), end = getDestination();
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, new AABB(from, end).inflate(getRadius()),
                e -> WuCombatRules.canHit(owner, e))) {
            var contact = victim.getBoundingBox().inflate(getRadius()).clip(from, end);
            Vec3 point = contact.orElse(from);
            if (!victim.getBoundingBox().inflate(getRadius()).contains(from) && contact.isEmpty()) continue;
            if (!WuCombatRules.clearLine(level, owner, from, point)) continue;
            if (victim.hurt(ModDamageTypes.wuStrike(level, owner), damage) && getEffectKind() == WATER) {
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 35, 2));
                victim.knockback(0.65, owner.getX() - victim.getX(), owner.getZ() - victim.getZ());
                victim.hurtMarked = true;
            }
        }
    }
    private void impactPalm(ServerLevel level, WuVillagerBase owner) {
        if (impacted) return;
        impacted = true; impactCount++;
        Vec3 center = getDestination();
        if (!WuCombatRules.loaded(level, new AABB(getOrigin(), center).inflate(getRadius()))) return;
        Vec3 actual = WuCombatRules.clip(level, owner, getOrigin(), center);
        if (actual.distanceToSqr(center) > 0.1) return; // New roof placed during warning blocks it too.
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(center.x - getRadius(), center.y - 0.45, center.z - getRadius(),
                        center.x + getRadius(), center.y + 3.2, center.z + getRadius()),
                e -> WuCombatRules.canHit(owner, e))) {
            double dx = victim.getX() - center.x, dz = victim.getZ() - center.z;
            if (dx * dx + dz * dz > getRadius() * getRadius()) continue;
            if (!WuCombatRules.clearLine(level, owner, center.add(0, 0.12, 0), victim.getEyePosition())) continue;
            if (victim.hurt(ModDamageTypes.wuStrike(level, owner), damage)) {
                victim.knockback(0.7, center.x - victim.getX(), center.z - victim.getZ());
                victim.hurtMarked = true;
            }
        }
    }
    @Override public void tick() {
        super.tick();
        if (level() instanceof ServerLevel level) {
            Entity owner = ownerId == null ? null : level.getEntity(ownerId);
            if (!(owner instanceof WuVillagerBase wu) || !wu.isAlive()) { discard(); return; }
            age++;
            if (getEffectKind() == PALM && age >= PALM_IMPACT_TICK && !impacted) impactPalm(level, wu);
            if (getEffectKind() == BLACK_HOLE) tickBlackHole(level, wu);
            if (age >= getLifetime()) discard();
        }
    }
    private void tickBlackHole(ServerLevel level, WuVillagerBase owner) {
        Vec3 center = getOrigin();
        float radius = getRadius();
        if (age < BLACK_HOLE_COLLAPSE_TICK) {
            if (age == 1) {
                level.playSound(null, BlockPos.containing(center), net.minecraft.sounds.SoundEvents.BEACON_DEACTIVATE,
                        net.minecraft.sounds.SoundSource.HOSTILE, 1.8f, 0.5f);
            } else if (age == 18) {
                level.playSound(null, BlockPos.containing(center), net.minecraft.sounds.SoundEvents.WARDEN_SONIC_CHARGE,
                        net.minecraft.sounds.SoundSource.HOSTILE, 1.5f, 0.8f);
            }
            if (age % 2 == 0) {
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                        center.x, center.y, center.z, 14, 1.2, 1.2, 1.2, -0.7);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.REVERSE_PORTAL,
                        center.x, center.y, center.z, 8, 1.5, 1.5, 1.5, 0.05);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.SQUID_INK,
                        center.x, center.y, center.z, 4, 0.8, 0.8, 0.8, 0.02);
            }
            double pullRadius = radius * 1.4;
            AABB pullBox = new AABB(center.x - pullRadius, center.y - pullRadius, center.z - pullRadius,
                    center.x + pullRadius, center.y + pullRadius, center.z + pullRadius);
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, pullBox, e -> WuCombatRules.canHit(owner, e))) {
                Vec3 toCenter = center.subtract(victim.position().add(0, victim.getBbHeight() * 0.5, 0));
                double dist = toCenter.length();
                if (dist > 0.3) {
                    double strength = Math.max(0.12, (pullRadius - dist) / pullRadius * 0.42);
                    Vec3 pullVec = toCenter.normalize().scale(strength);
                    victim.setDeltaMovement(victim.getDeltaMovement().scale(0.55).add(pullVec.x, pullVec.y * 0.7 + 0.03, pullVec.z));
                    victim.hasImpulse = true;
                    victim.fallDistance = 0;
                    victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 15, 2, false, false));
                }
            }
        }
        if (age == BLACK_HOLE_COLLAPSE_TICK && !impacted) {
            impacted = true;
            impactCount++;
            level.playSound(null, BlockPos.containing(center), net.minecraft.sounds.SoundEvents.WARDEN_SONIC_BOOM,
                    net.minecraft.sounds.SoundSource.HOSTILE, 2.5f, 0.75f);
            level.playSound(null, BlockPos.containing(center), net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE,
                    net.minecraft.sounds.SoundSource.HOSTILE, 2.0f, 0.6f);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.SONIC_BOOM, center.x, center.y, center.z, 1, 0, 0, 0, 0);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.FLASH, center.x, center.y, center.z, 2, 0, 0, 0, 0);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.SCULK_SOUL, center.x, center.y, center.z, 30, 2.0, 1.5, 2.0, 0.15);
            AABB blastBox = new AABB(center.x - radius, center.y - radius * 0.8, center.z - radius,
                    center.x + radius, center.y + radius * 1.2, center.z + radius);
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, blastBox, e -> WuCombatRules.canHit(owner, e))) {
                double distSq = victim.distanceToSqr(center);
                if (distSq > radius * radius) continue;
                if (!WuCombatRules.clearLine(level, owner, center, victim.getEyePosition())) continue;
                if (victim.hurt(ModDamageTypes.wuStrike(level, owner), damage)) {
                    double kb = Math.max(1.5, 2.5 - Math.sqrt(distSq) * 0.15);
                    victim.knockback(kb, center.x - victim.getX(), center.z - victim.getZ());
                    victim.hurtMarked = true;
                }
            }
        }
    }
    @Override public boolean isPickable() { return false; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) { discard(); }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
