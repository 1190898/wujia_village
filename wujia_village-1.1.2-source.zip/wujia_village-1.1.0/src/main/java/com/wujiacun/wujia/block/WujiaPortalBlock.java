package com.wujiacun.wujia.block;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.portal.WujiaPortalShape;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import org.joml.Vector3f;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 吴家村传送门：淡蓝色，动画效果参考下界传送门。
 * 进门规矩：先上天。
 */
public class WujiaPortalBlock extends HalfTransparentBlock {
    public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;
    /** 淡蓝门粒子色，供自检与 animateTick 共用 */
    public static final Vector3f PORTAL_DUST_COLOR = new Vector3f(0.55f, 0.78f, 1.0f);

    private static final VoxelShape X_AABB = net.minecraft.world.level.block.Block.box(0.0, 0.0, 6.0, 16.0, 16.0, 10.0);
    private static final VoxelShape Z_AABB = net.minecraft.world.level.block.Block.box(6.0, 0.0, 0.0, 10.0, 16.0, 16.0);

    private static final String COOLDOWN_KEY = "wujiaPortalCooldown";

    public WujiaPortalBlock() {
        super(Properties.of()
                .noCollission()
                .strength(-1.0f)
                .noLootTable()
                .lightLevel(state -> 15)
                .sound(SoundType.GLASS)
                .pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK));
        this.registerDefaultState(this.stateDefinition.any().setValue(AXIS, Direction.Axis.X));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, net.minecraft.world.level.block.state.BlockState> builder) {
        builder.add(AXIS);
    }

    @Override
    public net.minecraft.world.phys.shapes.VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(AXIS) == Direction.Axis.X ? X_AABB : Z_AABB;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        // 淡蓝色门粒子 + 偶尔响一声门的环境音（参考下界传送门）
        if (random.nextInt(100) == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    SoundEvents.PORTAL_AMBIENT, SoundSource.BLOCKS,
                    0.4f, random.nextFloat() * 0.4f + 0.8f, false);
        }
        // 淡蓝色尘埃粒子，不再用下界紫/品红 REVERSE_PORTAL
        DustParticleOptions blue = new DustParticleOptions(PORTAL_DUST_COLOR, 1.15f);
        for (int i = 0; i < 5; i++) {
            double x = pos.getX() + random.nextDouble();
            double y = pos.getY() + random.nextDouble();
            double z = pos.getZ() + random.nextDouble();
            double vx = (random.nextDouble() - 0.5) * 0.35;
            double vy = random.nextDouble() * 0.15;
            double vz = (random.nextDouble() - 0.5) * 0.35;
            level.addParticle(blue, x, y, z, vx, vy, vz);
            if (i % 2 == 0) {
                level.addParticle(ParticleTypes.END_ROD, x, y, z, 0.0, 0.02, 0.0);
            }
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide()) return;
        if (entity.isPassenger() || entity.isVehicle()) return;
        if (entity instanceof ServerPlayer sp && sp.isSpectator()) return;
        if (!entity.canChangeDimensions()) return;

        CompoundTag data = entity.getPersistentData();
        long now = level.getGameTime();
        if (now - data.getLong(COOLDOWN_KEY) < 60) return;
        data.putLong(COOLDOWN_KEY, now);

        if (!level.dimension().equals(WujiaVillageMod.WUJIA_DIM)) {
            data.putInt(com.wujiacun.wujia.portal.WujiaTeleporter.RETURN_X, pos.getX());
            data.putInt(com.wujiacun.wujia.portal.WujiaTeleporter.RETURN_Y, pos.getY());
            data.putInt(com.wujiacun.wujia.portal.WujiaTeleporter.RETURN_Z, pos.getZ());
            data.putBoolean(com.wujiacun.wujia.portal.WujiaTeleporter.RETURN_SET, true);
        }

        ServerLevel dest;
        if (level.dimension().equals(WujiaVillageMod.WUJIA_DIM)) {
            dest = level.getServer().overworld();
        } else {
            dest = level.getServer().getLevel(WujiaVillageMod.WUJIA_DIM);
        }
        if (dest == null) return;

        level.playSound(null, pos, SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.6f, 1.2f);
        entity.changeDimension(dest, new com.wujiacun.wujia.portal.WujiaTeleporter());
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, net.minecraft.world.level.block.Block block, BlockPos fromPos, boolean moving) {
        if (level.isClientSide()) return;
        Direction.Axis axis = state.getValue(AXIS);
        boolean valid = WujiaPortalShape.detect(level, pos, axis).isPresent()
                || WujiaPortalShape.detect(level, pos, axis == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X).isPresent();
        if (!valid) {
            level.removeBlock(pos, false);
        }
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        return ItemStack.EMPTY;
    }
}
