package com.wujiacun.wujia.world;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.*;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.world.WujiaVillageLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;

/**
 * 吴家村世界的日常运营：
 * 1. 敌对生物一露头就被"吴家气场"同化成友好生物（含僵尸→村民、僵尸村民→村民）
 * 2. 玩家周围定期补充村民、铁傀儡、猫狗宠物与流浪商人
 * 3. 玩家在维度内常驻"吴家赐福"
 */
public class WujiaSpawnHandler {

    private static final VillagerProfession[] PROFESSIONS = {
            VillagerProfession.FARMER, VillagerProfession.LIBRARIAN, VillagerProfession.TOOLSMITH,
            VillagerProfession.ARMORER, VillagerProfession.CLERIC, VillagerProfession.BUTCHER,
            VillagerProfession.FISHERMAN, VillagerProfession.MASON, VillagerProfession.SHEPHERD,
            VillagerProfession.CARTOGRAPHER, VillagerProfession.LEATHERWORKER,
            VillagerProfession.FLETCHER, VillagerProfession.WEAPONSMITH
    };

    public static void tick(MinecraftServer server) {
        ServerLevel wujia = server.getLevel(WujiaVillageMod.WUJIA_DIM);
        if (wujia == null) return;
        long t = wujia.getGameTime();

        if (t % 200 == 0) {
            ensurePlaza(wujia);
            spawnAroundPlayers(wujia);
        }
        if (t % 40 == 0) {
            buffPlayers(wujia);
        }
        VillageFurnisher.tick(wujia);
    }

    /** 敌对生物同化：在维度内生成的一切 Enemy 都会变成吴家的友好生物 */
    @Nullable
    public static Mob convertEnemy(ServerLevel level, BlockPos pos, float yRot) {
        Mob replacement = rollFriendly(level, pos, null);
        if (replacement == null) return null;
        replacement.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yRot, 0.0f);
        replacement.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.CONVERSION, null, null);
        level.addFreshEntity(replacement);
        return replacement;
    }

    private static void spawnAroundPlayers(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            long friendly = level.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(48), WujiaSpawnHandler::isWujiaFriendly).size();
            if (friendly >= 12) continue;

            double angle = level.random.nextDouble() * Math.PI * 2;
            double dist = 12 + level.random.nextDouble() * 16;
            int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
            BlockPos feet = new BlockPos(x, WujiaVillageLayout.SURFACE + 1, z);
            if (!level.hasChunkAt(feet)) continue;
            if (!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()) continue;
            if (!level.getBlockState(feet.below()).blocksMotion()) continue;

            Mob mob = rollFriendly(level, feet, player);
            if (mob == null) continue;
            mob.moveTo(x + 0.5, feet.getY(), z + 0.5, level.random.nextFloat() * 360.0f, 0.0f);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(feet), MobSpawnType.NATURAL, null, null);
            level.addFreshEntity(mob);
        }
    }

    private static void ensurePlaza(ServerLevel level) {
        AABB plaza = new AABB(-48, 0, -48, 48, 128, 48);
        spawnCast(level, plaza, WuChickenEntity.class, WujiaVillageLayout.CHICKEN_POS, () -> ModEntities.WU_CHICKEN.get().create(level));
        spawnCast(level, plaza, WuDogEntity.class, WujiaVillageLayout.DOG_POS, () -> ModEntities.WU_DOG.get().create(level));
        spawnCast(level, plaza, ChiefVillagerEntity.class, WujiaVillageLayout.CHIEF_POS, () -> ModEntities.CHIEF_VILLAGER.get().create(level));
        spawnCast(level, plaza, AncestorVillagerEntity.class, WujiaVillageLayout.ANCESTOR_POS, () -> ModEntities.ANCESTOR_VILLAGER.get().create(level));
        spawnCast(level, plaza, SweeperVillagerEntity.class, WujiaVillageLayout.SWEEPER_POS, () -> ModEntities.SWEEPER_VILLAGER.get().create(level));
        spawnCast(level, plaza, DodgeVillagerEntity.class, WujiaVillageLayout.DODGE_POS, () -> ModEntities.DODGE_VILLAGER.get().create(level));
        spawnCast(level, plaza, TeleportVillagerEntity.class, WujiaVillageLayout.TELEPORT_POS, () -> ModEntities.TELEPORT_VILLAGER.get().create(level));
        spawnCast(level, plaza, GuardVillagerEntity.class, WujiaVillageLayout.GUARD_POS, () -> ModEntities.GUARD_VILLAGER.get().create(level));
        spawnCast(level, plaza, FisherVillagerEntity.class, WujiaVillageLayout.FISHER_POS, () -> ModEntities.FISHER_VILLAGER.get().create(level));
        spawnCast(level, plaza, HimVillagerEntity.class, WujiaVillageLayout.HIM_POS, () -> ModEntities.HIM_VILLAGER.get().create(level));
    }

    private static <T extends Mob> void spawnCast(ServerLevel level, AABB plaza, Class<T> type, BlockPos pos, java.util.function.Supplier<T> factory) {
        if (!level.getEntitiesOfClass(type, plaza).isEmpty()) return;
        T mob = factory.get();
        if (mob == null) return;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360.0f, 0.0f);
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        level.addFreshEntity(mob);
    }

    /** 随机挑选一位吴家村的友好住户 */
    @Nullable
    private static Mob rollFriendly(ServerLevel level, BlockPos pos, @Nullable ServerPlayer tameTo) {
        float r = level.random.nextFloat();
        if (r < 0.62f) {
            Villager v = new Villager(EntityType.VILLAGER, level);
            v.setVillagerData(v.getVillagerData()
                    .setProfession(PROFESSIONS[level.random.nextInt(PROFESSIONS.length)]));
            return v;
        } else if (r < 0.74f) {
            return new IronGolem(EntityType.IRON_GOLEM, level);
        } else if (r < 0.84f) {
            Cat cat = new Cat(EntityType.CAT, level);
            if (tameTo != null && level.random.nextBoolean()) cat.tame(tameTo);
            return cat;
        } else if (r < 0.92f) {
            Wolf wolf = new Wolf(EntityType.WOLF, level);
            if (tameTo != null && level.random.nextBoolean()) wolf.tame(tameTo);
            return wolf;
        } else if (r < 0.96f) {
            return new DodgeVillagerEntity(ModEntities.DODGE_VILLAGER.get(), level);
        } else {
            return new TeleportVillagerEntity(ModEntities.TELEPORT_VILLAGER.get(), level);
        }
    }

    public static boolean isWujiaFriendly(LivingEntity e) {
        return e instanceof WuVillagerBase
                || e instanceof Villager
                || e instanceof IronGolem
                || e instanceof TamableAnimal
                || e instanceof WanderingTrader;
    }

    /** 玩家在吴家村内的常驻赐福 */
    private static void buffPlayers(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 220, 1, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 220, 1, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 220, 1, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 220, 0, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 220, 0, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 220, 0, true, false));
        }
    }
}
