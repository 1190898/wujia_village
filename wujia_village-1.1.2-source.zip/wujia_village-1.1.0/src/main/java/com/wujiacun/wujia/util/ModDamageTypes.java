package com.wujiacun.wujia.util;

import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * 吴家之力伤害类型：无视护甲。
 * 数据包定义于 data/wujia_village/damage_type/wu_strike.json，
 * 并挂入 minecraft:tags/damage_type/bypasses_armor。
 */
public class ModDamageTypes {
    public static final ResourceKey<DamageType> WU_STRIKE =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(WujiaVillageMod.MODID, "wu_strike"));

    public static final ResourceKey<DamageType> WU_SWORD =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(WujiaVillageMod.MODID, "wu_sword"));

    public static DamageSource wuSword(Level level, net.minecraft.world.entity.Entity sword, LivingEntity attacker) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(WU_SWORD), sword, attacker);
    }

    public static DamageSource wuStrike(Level level, LivingEntity attacker) {
        var holder = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolder(WU_STRIKE);
        if (holder.isEmpty()) {
            // 兜底：原版魔伤本身就带 bypasses_armor
            return attacker.damageSources().magic();
        }
        return new DamageSource(holder.get(), attacker, attacker);
    }
}
