package com.wujiacun.wujia.event;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.block.WujiaPortalBlock;
import com.wujiacun.wujia.entity.HimDragonEntity;
import org.joml.Vector3f;
import com.wujiacun.wujia.registry.ModBlocks;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.registry.ModItems;
import com.wujiacun.wujia.world.CubePlanetSchedule;
import com.wujiacun.wujia.world.CubePlanetShow;
import com.wujiacun.wujia.world.WujiaVillageLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.FakePlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 启动时把村子、攻击、贴图和方星时间表跑一遍。只在 wujia.selftest 下退出进程。 */
public final class WujiaSelfTest {
    private WujiaSelfTest() {}

    public static void finish(MinecraftServer server) {
        List<String> failures = new ArrayList<>();
        try {
            run(server, failures);
        } catch (Throwable thrown) {
            failures.add("exception " + thrown.getClass().getSimpleName() + ": " + thrown.getMessage());
            thrown.printStackTrace();
        }
        int exitCode = failures.isEmpty() ? 0 : 1;
        if (failures.isEmpty()) {
            WujiaVillageMod.LOGGER.info("SELFTEST OK");
        } else {
            for (String failure : failures) {
                WujiaVillageMod.LOGGER.error("SELFTEST FAIL {}", failure);
            }
        }
        // System.exit on the server thread deadlocks with Minecraft's shutdown hook joining it.
        // Let that thread finish and save the isolated test world before reporting the process result.
        server.halt(false);
        Thread exit = new Thread(() -> {
            server.halt(true);
            System.out.flush();
            System.err.flush();
            System.exit(exitCode);
        }, "wujia-selftest-exit");
        exit.start();
    }

    private static void run(MinecraftServer server, List<String> failures) {
        check(failures, "planet intact", CubePlanetSchedule.phase(0) == CubePlanetSchedule.Phase.INTACT);
        check(failures, "planet crack", CubePlanetSchedule.phase(CubePlanetSchedule.CRACK_AT) == CubePlanetSchedule.Phase.CRACK);
        check(failures, "planet break", CubePlanetSchedule.phase(CubePlanetSchedule.BREAK_AT) == CubePlanetSchedule.Phase.BREAK);
        check(failures, "planet gone", CubePlanetSchedule.phase(CubePlanetSchedule.GONE_AT) == CubePlanetSchedule.Phase.GONE);
        check(failures, "planet loops", CubePlanetSchedule.phase(CubePlanetSchedule.CYCLE) == CubePlanetSchedule.Phase.INTACT);
        check(failures, "separation grows",
                CubePlanetSchedule.separation(CubePlanetSchedule.BREAK_AT + 80) > CubePlanetSchedule.separation(CubePlanetSchedule.CRACK_AT));
        check(failures, "alpha fades",
                CubePlanetSchedule.alpha(CubePlanetSchedule.GONE_AT - 1) < CubePlanetSchedule.alpha(CubePlanetSchedule.BREAK_AT));

        for (String path : new String[]{
                "textures/block/cloud_block.png",
                "textures/block/wujia_portal.png",
                "textures/block/wujia_stele_bottom.png",
                "textures/block/wujia_stele_top.png",
                "textures/block/wujia_stone.png",
                "textures/block/wu_cabbage.png",
                "textures/block/wujia_air.png",
                "textures/item/wu_sword.png",
                "textures/item/wu_helmet.png",
                "textures/item/wu_broom.png",
                "textures/entity/dodge_villager.png",
                "textures/entity/teleport_villager.png",
                "textures/entity/chief_villager.png",
                "textures/entity/ancestor_villager.png",
                "textures/entity/ancestor_villager_eyes.png",
                "textures/entity/sweeper_villager.png",
                "textures/entity/him_villager.png",
                "textures/entity/him_villager_eyes.png",
                "textures/entity/guard_villager.png",
                "textures/entity/fisher_villager.png",
                "textures/entity/broom.png",
                "textures/entity/ghost_villager_fade_0.png",
                "textures/entity/ghost_villager_fade_5.png",
                "textures/models/armor/wu_layer_1.png",
                "textures/environment/cube_planet.png"
        }) {
            String classpath = "/assets/" + WujiaVillageMod.MODID + "/" + path;
            check(failures, "resource " + path, WujiaVillageMod.class.getResource(classpath) != null);
        }

        checkNames(failures);
        checkSkinImages(failures);
        checkFurniture(failures, server);

        ServerLevel wujia = server.getLevel(WujiaVillageMod.WUJIA_DIM);
        check(failures, "dimension loaded", wujia != null);
        if (wujia == null) return;
        CubePlanetShow.tick(wujia);

        expectBlock(failures, wujia, WujiaVillageLayout.STELE_POS, ModBlocks.WUJIA_STELE.get());
        expectBlock(failures, wujia, WujiaVillageLayout.STELE_TOP, ModBlocks.WUJIA_STELE.get());
        BlockPos portal = new BlockPos(0, WujiaVillageLayout.SURFACE + 1, WujiaVillageLayout.PORTAL_Z);
        expectBlock(failures, wujia, portal, ModBlocks.WUJIA_PORTAL.get());
        BlockPos spawn = WujiaVillageLayout.PLAYER_SPAWN;
        check(failures, "spawn air", wujia.getBlockState(spawn).isAir());
        check(failures, "spawn floor", wujia.getBlockState(spawn.below()).blocksMotion());
        expectBlock(failures, wujia, WujiaVillageLayout.HIM_POS.below(), net.minecraft.world.level.block.Blocks.END_STONE_BRICKS);

        BlockPos house = WujiaVillageLayout.sampleHousePos();
        BlockState houseExpected = WujiaVillageLayout.blockAt(house.getX(), house.getY(), house.getZ());
        BlockState houseActual = wujia.getBlockState(house);
        check(failures, "house wall generated", !houseExpected.isAir() && houseActual.equals(houseExpected));

        BlockPos farm = WujiaVillageLayout.sampleFarmPos();
        check(failures, "farmland", wujia.getBlockState(farm).is(net.minecraft.world.level.block.Blocks.FARMLAND));
        check(failures, "no mountain", wujia.getBlockState(new BlockPos(300, 120, 300)).isAir());
        check(failures, "village surface", wujia.getBlockState(new BlockPos(300, WujiaVillageLayout.SURFACE, 300)).blocksMotion());

        ServerLevel overworld = server.overworld();
        HimDragonEntity dragon = ModEntities.HIM_DRAGON.get().create(overworld);
        Zombie zombie = ModEntities.HIM_DRAGON.get() == null ? null : new Zombie(net.minecraft.world.entity.EntityType.ZOMBIE, overworld);
        check(failures, "dragon not assimilated", dragon != null && !WujiaEvents.shouldAssimilate(dragon));
        check(failures, "zombie assimilated", zombie != null && WujiaEvents.shouldAssimilate(zombie));
        if (dragon != null) check(failures, "dragon health", Math.abs(dragon.getMaxHealth() - com.wujiacun.wujia.entity.HimDragonEntity.PET_MAX_HEALTH) < 0.1f || dragon.getMaxHealth() >= 800.0f - 0.1f);
        var himStats = ModEntities.HIM_VILLAGER.get().create(overworld);
        check(failures, "Him加强血量", himStats != null && himStats.getMaxHealth() >= 1024.0f - 0.1f);
        if (himStats != null) himStats.discard();

        attackCheck(failures, overworld);
        checkBroom(failures, overworld);
        checkHim(failures, overworld);
        checkDoorway(failures, wujia);
        checkFisher(failures, overworld);
        checkPortalBlue(failures);
        runSuite(failures, "portal", () -> com.wujiacun.wujia.portal.PortalShapeSelfTest.run(failures));
        runSuite(failures, "village", () -> com.wujiacun.wujia.world.VillageLayoutSelfTest.run(wujia, failures));
        runSuite(failures, "combat", () -> com.wujiacun.wujia.entity.combat.WuCombatSelfTest.run(overworld, failures));
    }


    /** Him：受击起飞、闪电轨视觉雷不点火、落地后恢复重力。 */
    private static void checkHim(List<String> failures, ServerLevel level) {
        var him = ModEntities.HIM_VILLAGER.get().create(level);
        check(failures, "Him能生成", him != null);
        if (him == null) return;
        check(failures, "Him本体血量", him.getMaxHealth() >= 1024.0f - 0.1f);
        BlockPos at = level.getSharedSpawnPos();
        him.moveTo(at.getX() + 4.5, at.getY() + 1.0, at.getZ() + 0.5, 0.0f, 0.0f);
        level.addFreshEntity(him);

        FakePlayer bully = new FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wujia_him_bully"));
        bully.setPos(him.getX() - 2.0, him.getY(), him.getZ());

        double beforeY = him.getY();
        him.hurt(level.damageSources().playerAttack(bully), 4.0f);
        check(failures, "Him受击后起飞", him.isFlyingAway() || him.isNoGravity() || him.getY() > beforeY + 0.15);

        // 用一只真实进世界的僵尸做闪电轨目标，避免 FakePlayer 进世界的坑
        Zombie victim = new Zombie(net.minecraft.world.entity.EntityType.ZOMBIE, level);
        victim.moveTo(him.getX(), him.getY(), him.getZ(), 0.0f, 0.0f);
        level.addFreshEntity(victim);

        net.minecraft.world.phys.Vec3 spot = victim.position();
        com.wujiacun.wujia.util.HimLightning.strike(level, spot, him, victim, 12.0f);
        boolean anyFire = false;
        BlockPos base = BlockPos.containing(spot);
        for (BlockPos p2 : BlockPos.betweenClosed(base.offset(-2, -1, -2), base.offset(2, 2, 2))) {
            if (level.getBlockState(p2).is(net.minecraft.world.level.block.Blocks.FIRE)
                    || level.getBlockState(p2).is(net.minecraft.world.level.block.Blocks.SOUL_FIRE)) {
                anyFire = true;
                break;
            }
        }
        check(failures, "Him闪电轨不着火", !anyFire);
        check(failures, "Him闪电轨能僵直目标",
                victim.hasEffect(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN)
                        || !victim.isAlive());

        for (int i = 0; i < 80; i++) him.tick();
        check(failures, "Him起飞结束后恢复重力", !him.isNoGravity() && !him.isFlyingAway());
        him.discard();
        victim.discard();
    }

    /** 飞帚：造得出来、骑得上去、只坐一个人、松手之后会自己飞走。 */
    private static void checkBroom(List<String> failures, ServerLevel level) {
        var broom = ModEntities.BROOM.get().create(level);
        check(failures, "飞帚能生成", broom != null);
        if (broom == null) return;

        BlockPos at = level.getSharedSpawnPos();
        broom.moveTo(at.getX() + 0.5, at.getY() + 1.0, at.getZ() + 0.5, 0.0f, 0.0f);
        level.addFreshEntity(broom);
        check(failures, "飞帚在世界上", level.getEntity(broom.getId()) == broom);
        check(failures, "飞帚有不碰墙的判定", !broom.canBeCollidedWith());
        check(failures, "飞帚座位偏移合理", broom.getPassengersRidingOffset() >= 0.7 && broom.getPassengersRidingOffset() <= 1.2);

        FakePlayer rider = new FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wujia_rider"));
        check(failures, "飞帚能载人", rider.startRiding(broom, true) && broom.getControllingPassenger() == rider);
        check(failures, "飞帚骑手有座位高度", broom.getPassengersRidingOffset() > 0.5);

        FakePlayer stowaway = new FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wujia_stowaway"));
        check(failures, "飞帚只坐一人", !stowaway.startRiding(broom) && broom.getPassengers().size() == 1);

        rider.stopRiding();
        check(failures, "飞帚能跳车", !rider.isPassenger() && broom.getPassengers().isEmpty());

        for (int i = 0; i < 100; i++) broom.tick();
        check(failures, "飞帚闲置会回收", broom.isRemoved());
    }

    /** 门口内侧 1～2 格不得有床/箱/工作站等家具（门墙本身不算）。 */
    private static void checkDoorway(List<String> failures, ServerLevel wujia) {
        int[][] cells = {{1, 1}, {1, 2}, {2, 1}};
        for (int[] cell : cells) {
            int kind = WujiaVillageLayout.style(cell[0], cell[1]);
            if (kind == WujiaVillageLayout.FARM) continue;
            int[] b = WujiaVillageLayout.houseBounds(cell[0], cell[1], kind);
            int doorX = (b[0] + b[1]) / 2;
            int doorZ = b[3];
            BlockState atDoor = wujia.getBlockState(new BlockPos(doorX, WujiaVillageLayout.SURFACE + 1, doorZ));
            check(failures, "房子有门 " + cell[0] + "," + cell[1],
                    atDoor.getBlock() instanceof net.minecraft.world.level.block.DoorBlock);
            int blocked = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = 1; dz <= 2; dz++) { // 只查门内侧，不含门墙
                    int x = doorX + dx;
                    int z = doorZ - dz;
                    if (x <= b[0] || x >= b[1] || z <= b[2] || z >= b[3]) continue;
                    // furnitureAt 应为 null；世界里也不该是家具
                    BlockState planned = WujiaVillageLayout.furnitureAt(x, WujiaVillageLayout.SURFACE + 1, z);
                    if (planned != null) { blocked++; continue; }
                    BlockState st = wujia.getBlockState(new BlockPos(x, WujiaVillageLayout.SURFACE + 1, z));
                    if (st.isAir()) continue;
                    if (st.getBlock() instanceof net.minecraft.world.level.block.CarpetBlock) continue;
                    if (st.getBlock() instanceof net.minecraft.world.level.block.BedBlock
                            || st.is(net.minecraft.world.level.block.Blocks.CHEST)
                            || st.is(net.minecraft.world.level.block.Blocks.CRAFTING_TABLE)
                            || st.is(net.minecraft.world.level.block.Blocks.FURNACE)
                            || st.is(net.minecraft.world.level.block.Blocks.SMOKER)
                            || st.is(net.minecraft.world.level.block.Blocks.BLAST_FURNACE)
                            || st.is(net.minecraft.world.level.block.Blocks.BARREL)
                            || st.is(net.minecraft.world.level.block.Blocks.OAK_FENCE)
                            || st.is(net.minecraft.world.level.block.Blocks.BOOKSHELF)
                            || st.is(net.minecraft.world.level.block.Blocks.LECTERN)
                            || st.is(net.minecraft.world.level.block.Blocks.ANVIL)) {
                        blocked++;
                    }
                }
            }
            check(failures, "门口通道无家具 " + cell[0] + "," + cell[1] + " (blocked=" + blocked + ")", blocked == 0);
        }
    }

    /** 钓鱼村民：实体、刷怪蛋、语言、贴图、可生成。 */
    private static void checkFisher(List<String> failures, ServerLevel level) {
        var fisher = ModEntities.FISHER_VILLAGER.get().create(level);
        check(failures, "钓鱼村民能生成", fisher != null);
        if (fisher != null) {
            check(failures, "钓鱼村民血量", fisher.getMaxHealth() >= 900.0f - 0.1f);
            BlockPos at = level.getSharedSpawnPos();
            fisher.moveTo(at.getX() + 6.5, at.getY() + 1.0, at.getZ() + 0.5, 0.0f, 0.0f);
            level.addFreshEntity(fisher);
            check(failures, "钓鱼村民在世界上", level.getEntity(fisher.getId()) == fisher);
            fisher.discard();
        }
        check(failures, "钓鱼村民刷怪蛋已注册", ModItems.FISHER_VILLAGER_EGG.get() != null);
        try {
            com.google.gson.JsonObject zh = loadLang("zh_cn");
            check(failures, "钓鱼村民中文名", has(zh, "entity.wujia_village.fisher_villager"));
            check(failures, "钓鱼村民问候语", has(zh, "message.wujia_village.greet.fisher"));
        } catch (Exception e) {
            failures.add("钓鱼村民语言 " + e);
        }
    }

    /** 传送门粒子必须是淡蓝色 Dust，不得依赖紫色 REVERSE_PORTAL 为主。 */
    private static void checkPortalBlue(List<String> failures) {
        Vector3f c = WujiaPortalBlock.PORTAL_DUST_COLOR;
        check(failures, "传送门粒子偏蓝", c.z() > c.x() && c.z() > c.y() * 0.9f && c.x() < 0.7f);
        check(failures, "传送门粒子非紫", !(c.x() > 0.6f && c.z() > 0.6f && c.y() < 0.35f));
    }

    /** 检查皮肤尺寸、眼睛透明底及术法资源；不将图像格式检查当作视觉验收。 */
    private static void checkSkinImages(List<String> failures) {
        for (String name : new String[]{"dodge_villager", "teleport_villager", "chief_villager",
                "ancestor_villager", "sweeper_villager", "guard_villager", "fisher_villager", "him_villager"}) {
            String path = "/assets/" + WujiaVillageMod.MODID + "/textures/entity/" + name + ".png";
            try (var input = WujiaVillageMod.class.getResourceAsStream(path)) {
                var image = input == null ? null : javax.imageio.ImageIO.read(input);
                check(failures, "64x64皮肤 " + name, image != null && image.getWidth() == 64 && image.getHeight() == 64);
            } catch (Exception e) {
                failures.add("皮肤读取 " + name + " " + e.getMessage());
            }
        }
        for (String name : new String[]{"ancestor_villager_eyes", "him_villager_eyes"}) {
            String path = "/assets/" + WujiaVillageMod.MODID + "/textures/entity/" + name + ".png";
            try (var input = WujiaVillageMod.class.getResourceAsStream(path)) {
                var image = input == null ? null : javax.imageio.ImageIO.read(input);
                int visible = 0;
                if (image != null) {
                    for (int y = 0; y < image.getHeight(); y++) {
                        for (int x = 0; x < image.getWidth(); x++) {
                            if ((image.getRGB(x, y) >>> 24) != 0) visible++;
                        }
                    }
                }
                check(failures, "发光眼睛透明底 " + name, image != null && visible > 0 && visible <= 32);
            } catch (Exception e) {
                failures.add("眼睛贴图读取 " + name + " " + e.getMessage());
            }
        }
        for (String name : new String[]{"skill_white", "skill_palm"}) {
            check(failures, "术法纹理 " + name, WujiaVillageMod.class.getResource(
                    "/assets/" + WujiaVillageMod.MODID + "/textures/entity/" + name + ".png") != null);
        }
    }

    /** 检查所有注册内容都有翻译：只要有一个 key 对不上，游戏里就会显示一串代码。 */
    private static void checkNames(List<String> failures) {
        try {
            com.google.gson.JsonObject zh = loadLang("zh_cn");
            com.google.gson.JsonObject en = loadLang("en_us");
            check(failures, "中英文语言键一致", zh.keySet().equals(en.keySet()));
            for (var type : net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES) {
                var key = net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(type);
                if (key == null || !key.getNamespace().equals(WujiaVillageMod.MODID)) continue;
                check(failures, "名字 " + key, has(zh, type.getDescriptionId()) && has(en, type.getDescriptionId()));
            }
            for (var block : net.minecraftforge.registries.ForgeRegistries.BLOCKS) {
                var key = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(block);
                if (key == null || !key.getNamespace().equals(WujiaVillageMod.MODID)) continue;
                check(failures, "方块名 " + key, has(zh, block.getDescriptionId()) && has(en, block.getDescriptionId()));
            }
            for (var item : net.minecraftforge.registries.ForgeRegistries.ITEMS) {
                var key = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item);
                if (key == null || !key.getNamespace().equals(WujiaVillageMod.MODID)) continue;
                check(failures, "物品名 " + key,
                        (has(zh, item.getDescriptionId()) || has(zh, item.getDescriptionId() + ".name"))
                                && (has(en, item.getDescriptionId()) || has(en, item.getDescriptionId() + ".name")));
            }
        } catch (Exception e) {
            failures.add("语言文件读取失败 " + e);
        }
    }

    private static boolean has(com.google.gson.JsonObject lang, String key) {
        return lang.has(key) && !lang.get(key).getAsString().isEmpty();
    }

    private static com.google.gson.JsonObject loadLang(String code) throws Exception {
        String path = "/assets/" + WujiaVillageMod.MODID + "/lang/" + code + ".json";
        try (var in = WujiaVillageMod.class.getResourceAsStream(path)) {
            if (in == null) throw new IllegalStateException("missing " + path);
            String text = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            return com.google.gson.JsonParser.parseString(text).getAsJsonObject();
        }
    }

    /** 房子里得有床、有箱子：世界生成和"老存档补家具"都要能落到地上。 */
    private static void checkFurniture(List<String> failures, MinecraftServer server) {
        ServerLevel wujia = server.getLevel(WujiaVillageMod.WUJIA_DIM);
        if (wujia == null) return;
        int[][] cells = {{1, 1}, {1, 2}, {2, 1}};
        for (int[] cell : cells) {
            int kind = WujiaVillageLayout.style(cell[0], cell[1]);
            if (kind == WujiaVillageLayout.FARM) continue;
            int[] b = WujiaVillageLayout.houseBounds(cell[0], cell[1], kind);
            int beds = 0;
            int chests = 0;
            for (int x = b[0]; x <= b[1]; x++) {
                for (int z = b[2]; z <= b[3]; z++) {
                    BlockState state = wujia.getBlockState(new BlockPos(x, WujiaVillageLayout.SURFACE + 1, z));
                    if (state.getBlock() instanceof net.minecraft.world.level.block.BedBlock) beds++;
                    if (state.is(net.minecraft.world.level.block.Blocks.CHEST)) chests++;
                }
            }
            check(failures, "房子里有床 " + cell[0] + "," + cell[1] + " (" + beds + ")", beds >= 2);
            check(failures, "房子里有箱子 " + cell[0] + "," + cell[1] + " (" + chests + ")", chests >= 1);
        }
        expectBlock(failures, wujia, WujiaVillageLayout.AIR_WELL, ModBlocks.WUJIA_AIR.get());
    }

    private static void attackCheck(List<String> failures, ServerLevel level) {        FakePlayer swordsman = new FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wujia_sword"));
        ItemStack sword = new ItemStack(ModItems.WU_SWORD.get());
        swordsman.setItemSlot(EquipmentSlot.MAINHAND, sword);
        swordsman.getAttributes().addTransientAttributeModifiers(sword.getAttributeModifiers(EquipmentSlot.MAINHAND));
        Zombie armored = armoredZombie(level);
        armored.hurt(level.damageSources().playerAttack(swordsman), 10.0f);
        float swordLeft = armored.getHealth();
        armored.discard();

        FakePlayer stick = new FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wujia_stick"));
        stick.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STICK));
        Zombie control = armoredZombie(level);
        control.hurt(level.damageSources().playerAttack(stick), 10.0f);
        float stickLeft = control.getHealth();
        control.discard();

        check(failures, "sword connects through armor (" + swordLeft + " vs stick " + stickLeft + ")",
                swordLeft < 5.0f && stickLeft > 10.0f);
    }

    private static Zombie armoredZombie(ServerLevel level) {
        Zombie zombie = new Zombie(net.minecraft.world.entity.EntityType.ZOMBIE, level);
        zombie.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        zombie.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        zombie.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        zombie.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        zombie.getAttribute(Attributes.ARMOR).setBaseValue(20.0);
        zombie.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(12.0);
        zombie.setHealth(zombie.getMaxHealth());
        return zombie;
    }

    private static void expectBlock(List<String> failures, ServerLevel level, BlockPos pos, net.minecraft.world.level.block.Block block) {
        check(failures, block.getDescriptionId() + " @ " + pos.toShortString(), level.getBlockState(pos).is(block));
    }

    private static void runSuite(List<String> failures, String name, Runnable suite) {
        try {
            suite.run();
        } catch (Throwable thrown) {
            failures.add(name + " exception " + thrown.getClass().getSimpleName() + ": " + thrown.getMessage());
            WujiaVillageMod.LOGGER.error("[selftest] FAIL {} suite", name, thrown);
        }
    }

    private static void check(List<String> failures, String name, boolean ok) {
        if (!ok) failures.add(name);
        WujiaVillageMod.LOGGER.info("[selftest] {} {}", ok ? "OK" : "FAIL", name);
    }
}
