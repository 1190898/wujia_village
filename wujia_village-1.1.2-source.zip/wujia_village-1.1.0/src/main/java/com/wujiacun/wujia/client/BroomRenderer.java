package com.wujiacun.wujia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.client.model.BroomModel;
import com.wujiacun.wujia.entity.BroomEntity;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** 飞帚渲染：杆指向飞行方向，扫帚毛拖在身后。 */
public class BroomRenderer extends EntityRenderer<BroomEntity> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(WujiaVillageMod.MODID, "broom"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(WujiaVillageMod.MODID, "textures/entity/broom.png");

    private final BroomModel model;

    public BroomRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new BroomModel(ctx.bakeLayer(LAYER));
        this.shadowRadius = 0.35f;
    }

    @Override
    public ResourceLocation getTextureLocation(BroomEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(BroomEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int packedLight) {
        pose.pushPose();
        float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
        float pitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
        // 模型默认朝 -Z 为杆尖、+Z 为毛；转成"毛在身后、尖朝前"
        pose.mulPose(Axis.YP.rotationDegrees(180.0f - yaw));
        pose.mulPose(Axis.XP.rotationDegrees(pitch));
        pose.translate(0.0, 0.82, 0.0);
        pose.scale(-1.0f, -1.0f, 1.0f);

        float age = entity.tickCount + partialTick;
        this.model.setupAnim(entity, 0.0f, 0.0f, age, 0.0f, 0.0f);

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        this.model.renderToBuffer(pose, vc, packedLight, OverlayTexture.NO_OVERLAY, 1.0f, 1.0f, 1.0f, 1.0f);
        pose.popPose();
        super.render(entity, entityYaw, partialTick, pose, buffer, packedLight);
    }
}
