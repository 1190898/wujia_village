package com.wujiacun.wujia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.client.model.WuPalmModel;
import com.wujiacun.wujia.entity.WuSkillEffectEntity;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Renders server-synced spell endpoints and age, never retargeting on the client. */
public final class WuSkillEffectRenderer extends EntityRenderer<WuSkillEffectEntity> {
    public static final ModelLayerLocation PALM_LAYER = new ModelLayerLocation(
            new ResourceLocation(WujiaVillageMod.MODID, "skill_palm"), "main");
    private static final ResourceLocation PALM_TEXTURE = new ResourceLocation(WujiaVillageMod.MODID, "textures/entity/skill_palm.png");
    private static final int PALM_DESCENT_TICK = 10;
    private static final int PALM_IMPACT_TICK = 24;
    private final WuPalmModel palm;

    public WuSkillEffectRenderer(EntityRendererProvider.Context context) {
        super(context);
        palm = new WuPalmModel(context.bakeLayer(PALM_LAYER));
        shadowRadius = 0;
    }

    @Override
    public ResourceLocation getTextureLocation(WuSkillEffectEntity entity) { return WuEffectGeometry.WHITE; }

    @Override
    public boolean shouldRender(WuSkillEffectEntity entity, Frustum frustum, double x, double y, double z) {
        // The tiny non-colliding anchor is not the visual bounds of a beam or descending palm.
        double padding = entity.getEffectKind() == WuSkillEffectEntity.PALM
                ? Math.max(2.0, entity.getRadius() * 1.7)
                : entity.getEffectKind() == WuSkillEffectEntity.BLACK_HOLE
                ? Math.max(4.0, entity.getRadius() * 2.0) : 1.5;
        return frustum.isVisible(new AABB(entity.getOrigin(), entity.getDestination()).inflate(padding));
    }

    @Override
    public void render(WuSkillEffectEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        float age = entity.getEffectAge(partialTick);
        float life = Math.max(1, entity.getLifetime());
        float alpha = Mth.clamp(Math.min(age + 1, life - age) / 3.0f, 0, 1);
        Vec3 offset = new Vec3(Mth.lerp(partialTick, entity.xo, entity.getX()),
                Mth.lerp(partialTick, entity.yo, entity.getY()), Mth.lerp(partialTick, entity.zo, entity.getZ()));
        Vec3 origin = entity.getOrigin().subtract(offset);
        Vec3 destination = entity.getDestination().subtract(offset);
        int tint = entity.getTint();
        if (entity.getEffectKind() == WuSkillEffectEntity.PALM) {
            renderPalm(entity, age, origin, destination, tint, pose, buffers);
        } else if (entity.getEffectKind() == WuSkillEffectEntity.BLACK_HOLE) {
            renderBlackHole(entity, age, origin, destination, tint, pose, buffers);
        } else {
            renderStream(entity.getEffectKind(), age, alpha, origin, destination,
                    Math.max(0.08, entity.getRadius()), tint, pose, buffers);
        }
        super.render(entity, yaw, partialTick, pose, buffers, light);
    }

    private void renderStream(int kind, float age, float alpha, Vec3 origin, Vec3 destination,
                              double radius, int tint, PoseStack pose, MultiBufferSource buffers) {
        Vec3 delta = destination.subtract(origin);
        if (delta.lengthSqr() < 0.001) return;
        Vec3 axis = delta.normalize();
        VertexConsumer out = WuEffectGeometry.buffer(buffers);
        int bright = WuEffectGeometry.brighten(tint, 0.65f);
        // Persistent connected stream makes the exact server aim line readable between the wavefronts.
        WuEffectGeometry.tube(pose, out, origin, destination, radius * 0.35, radius * 0.5, tint, alpha * 0.35f);
        WuEffectGeometry.tube(pose, out, origin, destination, radius * 0.1, radius * 0.13, bright, alpha * 0.75f);
        int count = kind == WuSkillEffectEntity.SONIC ? 8 : 6;
        for (int i = 0; i < count; i++) {
            double t = ((i + age * 0.25) / count) % 1.0;
            double waveRadius = kind == WuSkillEffectEntity.SONIC ? radius * (0.65 + t * 2.2) : radius * (0.7 + t);
            Vec3 center = origin.add(delta.scale(t));
            WuEffectGeometry.ring(pose, out, center, axis, waveRadius, 0.045, tint, alpha * 0.8f);
            if (kind == WuSkillEffectEntity.SONIC) {
                WuEffectGeometry.ring(pose, out, center, axis, waveRadius * 0.7, 0.024, bright, alpha * 0.6f);
            }
        }
        if (kind == WuSkillEffectEntity.WATER) {
            Vec3 u = WuEffectGeometry.perpendicular(axis), v = axis.cross(u);
            for (int strand = 0; strand < 3; strand++) {
                Vec3 previous = origin;
                for (int i = 1; i <= 28; i++) {
                    double t = i / 28.0, angle = t * 15 - age * 0.32 + strand * Math.PI * 2 / 3;
                    Vec3 point = origin.add(delta.scale(t)).add(u.scale(Math.cos(angle) * radius))
                            .add(v.scale(Math.sin(angle) * radius));
                    WuEffectGeometry.tube(pose, out, previous, point, 0.035, 0.035, bright, alpha * 0.55f);
                    previous = point;
                }
            }
        }
    }

    private void renderPalm(WuSkillEffectEntity entity, float age, Vec3 origin, Vec3 destination,
                            int tint, PoseStack pose, MultiBufferSource buffers) {
        float radius = Math.max(0.5f, entity.getRadius());
        float fade = age < PALM_IMPACT_TICK ? 1 : Mth.clamp((entity.getLifetime() - age) / 8, 0, 1);
        VertexConsumer out = WuEffectGeometry.buffer(buffers);
        Vec3 ground = destination.add(0, 0.035, 0);
        // Warning visible from the very first frame, independent of the hand's reveal/descent.
        WuEffectGeometry.ring(pose, out, ground, new Vec3(0, 1, 0), radius, 0.075,
                tint, fade * (0.6f + Mth.sin(age * 0.5f) * 0.15f));
        WuEffectGeometry.ring(pose, out, ground, new Vec3(0, 1, 0), radius * 0.82, 0.025,
                WuEffectGeometry.brighten(tint, 0.65f), fade * 0.65f);
        if (age >= PALM_IMPACT_TICK) {
            float burst = Mth.clamp((age - PALM_IMPACT_TICK) / 8, 0, 1);
            for (int i = 0; i < 3; i++) {
                WuEffectGeometry.ring(pose, out, ground.add(0, i * 0.18, 0), new Vec3(0, 1, 0),
                        radius * (1 + burst * 0.65) - i * 0.2, 0.09, tint, fade * 0.75f);
            }
        }
        float descent = Mth.clamp((age - PALM_DESCENT_TICK) / (PALM_IMPACT_TICK - PALM_DESCENT_TICK), 0, 1);
        Vec3 position = origin.lerp(destination, descent * descent);
        pose.pushPose();
        pose.translate(position.x, position.y + 0.07, position.z);
        Vec3 aim = destination.subtract(origin);
        pose.mulPose(Axis.YP.rotation((float) Math.atan2(aim.x, aim.z)));
        // Hand dimensions 24 x 27 pixels; centered footprint agrees with the warning radius.
        float scale = radius * 1.15f;
        pose.scale(scale, scale, scale);
        pose.translate(0, 0, -0.125);
        float reveal = Mth.clamp((age + 1) / 5, 0, 1) * fade;
        palm.render(pose, buffers.getBuffer(RenderType.entityTranslucent(PALM_TEXTURE)),
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                ((tint >> 16) & 255) / 255.0f, ((tint >> 8) & 255) / 255.0f,
                (tint & 255) / 255.0f, reveal * 0.63f);
        pose.popPose();
    }

    private void renderBlackHole(WuSkillEffectEntity entity, float age, Vec3 origin, Vec3 destination,
                                 int tint, PoseStack pose, MultiBufferSource buffers) {
        float radius = Math.max(1.0f, entity.getRadius());
        float collapseTick = WuSkillEffectEntity.BLACK_HOLE_COLLAPSE_TICK;
        VertexConsumer out = WuEffectGeometry.buffer(buffers);
        Vec3 center = origin;

        pose.pushPose();
        pose.translate(center.x, center.y, center.z);

        if (age < collapseTick) {
            float spin = age * 16.0f;
            pose.mulPose(Axis.XP.rotationDegrees(35.0f));
            pose.mulPose(Axis.YP.rotationDegrees(spin));

            int cosmicPurple = 0x8A2BE2;
            int cosmicGold = 0xFFD700;
            int darkVoid = 0x1A052E;
            float pulse = 0.85f + Mth.sin(age * 0.4f) * 0.15f;

            // Outer accretion disk
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), radius * 0.45 * pulse, 0.12, cosmicPurple, 0.85f);
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), radius * 0.35, 0.08, cosmicGold, 0.9f);
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), radius * 0.22, 0.06, 0xFFFFFF, 0.95f);
            // Black hole event horizon (dark dense core)
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), radius * 0.12, 0.08, darkVoid, 1.0f);

            // Perpendicular photon rings
            pose.mulPose(Axis.ZP.rotationDegrees(90.0f));
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), radius * 0.26 * pulse, 0.05, cosmicPurple, 0.65f);

            // Relativistic jet beams piercing both poles
            WuEffectGeometry.tube(pose, out, new Vec3(0, -radius * 0.8, 0), new Vec3(0, radius * 0.8, 0),
                    0.06, 0.06, 0xFFFFFF, 0.75f);
        } else {
            float burst = (age - collapseTick) / Math.max(1, entity.getLifetime() - collapseTick);
            float blastAlpha = Mth.clamp(1.0f - burst, 0, 1);
            float blastRadius = radius * (0.3f + burst * 1.5f);

            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), blastRadius, 0.18, 0xFFFFFF, blastAlpha * 0.9f);
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(0, 1, 0), blastRadius * 0.75, 0.12, tint, blastAlpha * 0.8f);
            WuEffectGeometry.ring(pose, out, Vec3.ZERO, new Vec3(1, 0, 0), blastRadius * 0.9, 0.1, 0x8A2BE2, blastAlpha * 0.7f);
        }

        pose.popPose();
    }
}
