package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.entity.combat.CombatAction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** Role-skinned frozen pose, faded against a synced authoritative birth time. */
public class GhostVillagerEntity extends Mob {
    public static final int LIFETIME = 20;
    private int simulationAge;
    private static final EntityDataAccessor<Long> BIRTH = SynchedEntityData.defineId(GhostVillagerEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> SKIN = SynchedEntityData.defineId(GhostVillagerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(GhostVillagerEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> ACTION = SynchedEntityData.defineId(GhostVillagerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> ACTION_AGE = SynchedEntityData.defineId(GhostVillagerEntity.class, EntityDataSerializers.FLOAT);
    public GhostVillagerEntity(EntityType<? extends Mob> type, Level level) {
        super(type, level);
        setNoAi(true); setInvulnerable(true); setNoGravity(true); noPhysics = true; setSilent(true);
    }
    @Override protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(BIRTH, 0L); entityData.define(SKIN, 0); entityData.define(SCALE, 1f);
        entityData.define(ACTION, CombatAction.BLINK.ordinal()); entityData.define(ACTION_AGE, 6f);
    }
    public void capture(WuVillagerBase owner) {
        moveTo(owner.getX(), owner.getY(), owner.getZ(), owner.getYRot(), owner.getXRot());
        setYHeadRot(owner.getYHeadRot()); setYBodyRot(owner.yBodyRot);
        entityData.set(BIRTH, level().getGameTime()); entityData.set(SKIN, owner.getSkinVariant());
        entityData.set(SCALE, owner instanceof ChiefVillagerEntity ? 1.15f : owner instanceof AncestorVillagerEntity ? 1.25f : 1f);
        entityData.set(ACTION, owner.getCombatAction().ordinal());
        entityData.set(ACTION_AGE, (float) owner.getCombatController().getServerActionAge());
    }
    public int getSkinVariant() { return entityData.get(SKIN); }
    public float getGhostScale() { return entityData.get(SCALE); }
    public CombatAction getGhostAction() { return CombatAction.values()[entityData.get(ACTION)]; }
    public float getGhostActionAge() { return entityData.get(ACTION_AGE); }
    public float fade(float partialTick) { return Math.max(0, Math.min(1, (level().getGameTime() - entityData.get(BIRTH) + partialTick) / LIFETIME)); }
    @Override public void tick() {
        super.tick();
        // Entity.tickCount is incremented by ServerLevel's outer tick, not by direct tick() calls.
        if (!level().isClientSide() && ++simulationAge >= LIFETIME) discard();
    }
    @Override public boolean isPushable() { return false; }
    @Override protected void pushEntities() {}
    @Override public boolean removeWhenFarAway(double dist) { return false; }
    @Override public boolean shouldRenderAtSqrDistance(double dist) { return dist < 128 * 128; }
    @Override public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); discard(); }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
