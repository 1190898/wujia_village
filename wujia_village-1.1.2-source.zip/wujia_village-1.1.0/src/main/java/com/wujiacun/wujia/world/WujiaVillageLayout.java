package com.wujiacun.wujia.world;

import com.wujiacun.wujia.block.WujiaSteleBlock;
import com.wujiacun.wujia.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.WallSide;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * 吴家村的地面：一块块连着的村子，不是另一张主世界地图。
 * 地面高度固定，房子、田、路、村口石碑和回程门都由坐标直接算出来。
 *
 * <p>房子有 5 种样式（橡木/云杉/红砖/白桦/石屋），大小不同、屋顶不同，
 * 屋里都有床、箱子、工作台、炉子这些家当。</p>
 */
public final class WujiaVillageLayout {
    public static final int SURFACE = 64;
    public static final int MAX_BUILD_Y = SURFACE + 9;
    public static final int PLOT = 48;
    public static final int PORTAL_Z = 11;
    public static final int FARM = 3;

    public static final BlockPos PLAYER_SPAWN = new BlockPos(0, SURFACE + 1, 1);
    public static final BlockPos STELE_POS = new BlockPos(0, SURFACE + 1, -8);
    public static final BlockPos STELE_TOP = new BlockPos(0, SURFACE + 2, -8);
    public static final BlockPos CHIEF_POS = new BlockPos(-14, SURFACE + 1, 4);
    public static final BlockPos ANCESTOR_POS = new BlockPos(13, SURFACE + 3, 6);
    public static final BlockPos SWEEPER_POS = new BlockPos(0, SURFACE + 1, -5);
    public static final BlockPos DODGE_POS = new BlockPos(4, SURFACE + 1, 3);
    public static final BlockPos TELEPORT_POS = new BlockPos(-4, SURFACE + 1, 3);
    public static final BlockPos CHICKEN_POS = new BlockPos(6, SURFACE + 1, 14);
    public static final BlockPos DOG_POS = new BlockPos(-6, SURFACE + 1, 14);
    public static final BlockPos HIM_POS = new BlockPos(20, SURFACE + 1, 10);
    public static final BlockPos GUARD_POS = new BlockPos(-9, SURFACE + 1, 12);
    public static final BlockPos FISHER_POS = new BlockPos(-16, SURFACE + 1, 16);

    /** 井边的吴家空气：站进去就能飞一会儿 */
    public static final BlockPos AIR_WELL = new BlockPos(6, SURFACE + 1, 8);

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();
    private static final BlockState STONE = Blocks.STONE.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS_BLOCK.defaultBlockState();
    private static final BlockState PATH = Blocks.DIRT_PATH.defaultBlockState();
    private static final BlockState BRICKS = Blocks.STONE_BRICKS.defaultBlockState();
    private static final BlockState ANDESITE = Blocks.POLISHED_ANDESITE.defaultBlockState();
    private static final BlockState WATER = Blocks.WATER.defaultBlockState();
    private static final BlockState COBBLE = Blocks.COBBLESTONE.defaultBlockState();
    private static final BlockState GLASS = Blocks.GLASS.defaultBlockState();
    private static final BlockState FARMLAND = Blocks.FARMLAND.defaultBlockState().setValue(FarmBlock.MOISTURE, 7);

    /** Wall bounds, not roof bounds. All consumers use this same descriptor. */
    public record House(int x0, int z0, int x1, int z1, int kind, boolean plaza) {
        public int doorX() { return (x0 + x1) / 2; }
        public int width() { return x1 - x0 + 1; }
        public int depth() { return z1 - z0 + 1; }
        public BlockPos door() { return new BlockPos(doorX(), SURFACE + 1, z1); }
        public String id() { return x0 + "," + z0 + "," + kind; }
        public boolean contains(int x, int z) { return x >= x0 && x <= x1 && z >= z0 && z <= z1; }
        public boolean clearance(int x, int z) {
            return Math.abs(x - doorX()) <= 1 && z >= z1 - 2 && z <= z1;
        }
        public boolean approach(int x, int z) {
            if (plaza) return z == z1 + 1 && x >= Math.min(doorX(), 2) && x <= Math.max(doorX(), -2);
            int roadZ = Math.floorDiv(z0, PLOT) * PLOT + PLOT;
            return Math.abs(x - doorX()) <= 1 && z > z1 && z <= roadZ;
        }
    }

    public record FurnitureBlock(BlockPos pos, BlockState state) {}
    /** Multi-block furniture is checked/placed as a unit during migration. */
    public record FurnitureGroup(String name, boolean container, List<FurnitureBlock> blocks) {}

    private record RoomShape(int width, int depth, int kind, int doorOffset) {}
    private static final Map<RoomShape, Map<BlockPos, BlockState>> ROOM_FURNITURE = new ConcurrentHashMap<>();

    private static final List<House> PLAZA_HOUSES = List.of(
            new House(-18, -6, -10, 2, 0, true), new House(8, -6, 18, 4, 4, true));

    private WujiaVillageLayout() {}

    public static List<House> plazaHouses() { return PLAZA_HOUSES; }

    public static House plotHouse(int cellX, int cellZ) {
        if (cellX >= -1 && cellX <= 0 && cellZ >= -1 && cellZ <= 0) return null;
        int kind = style(cellX, cellZ);
        if (kind == FARM) return null;
        int[] b = houseBounds(cellX, cellZ, kind);
        return new House(b[0], b[2], b[1], b[3], kind, false);
    }

    public static House houseAt(int x, int z) {
        for (House h : PLAZA_HOUSES) if (h.contains(x, z)) return h;
        if (inPlaza(x, z)) return null;
        House h = plotHouse(Math.floorDiv(x, PLOT), Math.floorDiv(z, PLOT));
        return h != null && h.contains(x, z) ? h : null;
    }

    /** Finite descriptor query; does not access or load any chunks. */
    public static List<House> housesNear(BlockPos center, int radius) {
        List<House> result = new ArrayList<>();
        for (House h : PLAZA_HOUSES) if (near(h, center, radius)) result.add(h);
        for (int cx = Math.floorDiv(center.getX() - radius, PLOT); cx <= Math.floorDiv(center.getX() + radius, PLOT); cx++) {
            for (int cz = Math.floorDiv(center.getZ() - radius, PLOT); cz <= Math.floorDiv(center.getZ() + radius, PLOT); cz++) {
                House h = plotHouse(cx, cz);
                if (h != null && near(h, center, radius)) result.add(h);
            }
        }
        return List.copyOf(result);
    }

    private static boolean near(House h, BlockPos center, int radius) {
        return h.x1 >= center.getX() - radius && h.x0 <= center.getX() + radius
                && h.z1 >= center.getZ() - radius && h.z0 <= center.getZ() + radius;
    }

    public static BlockState blockAt(int x, int y, int z) {
        if (y < 0 || y > 255) return AIR;
        if (y == 0) return BEDROCK;
        if (y > SURFACE && reserved(x, z)) return AIR;
        BlockState built = builtAt(x, y, z);
        if (built != null) return built;
        if (y < SURFACE - 3) return STONE;
        if (y < SURFACE) return DIRT;
        if (y == SURFACE) return groundCover(x, z);
        return AIR;
    }

    public static boolean inPlaza(int x, int z) {
        return x >= -24 && x <= 24 && z >= -18 && z <= 22;
    }

    public static boolean isRoad(int x, int z) {
        if (inPlaza(x, z)) return false;
        int lx = Math.floorMod(x, PLOT);
        int lz = Math.floorMod(z, PLOT);
        return lx < 5 || lz < 5;
    }

    /** 每个地块的样式：0 橡木 1 云杉 2 红砖 3 田 4 白桦 5 石屋 */
    public static int style(int cellX, int cellZ) {
        return hash(cellX, cellZ) % 6;
    }

    public static int houseWidth(int kind) {
        return kind == 1 || kind == 5 ? 8 : 7;
    }

    public static int houseDepth(int kind) {
        return kind == 1 || kind == 5 || kind == 2 ? 7 : 6;
    }

    /** 返回 {x0, x1, z0, z1}，房子外墙的范围 */
    public static int[] houseBounds(int cellX, int cellZ, int kind) {
        int originX = cellX * PLOT;
        int originZ = cellZ * PLOT;
        int w = houseWidth(kind);
        int d = houseDepth(kind);
        int x0 = originX + 9;
        int z0 = originZ + 11;
        return new int[]{x0, x0 + w - 1, z0, z0 + d - 1};
    }

    /** 一处肯定是房墙的坐标，给启动自检用。 */
    public static BlockPos sampleHousePos() {
        for (int cx = 1; cx <= 8; cx++) {
            for (int cz = 1; cz <= 8; cz++) {
                int kind = style(cx, cz);
                if (kind == FARM) continue;
                int[] b = houseBounds(cx, cz, kind);
                return new BlockPos(b[0], SURFACE + 1, b[2] + 1);
            }
        }
        return BlockPos.ZERO;
    }

    public static BlockPos sampleFarmPos() {
        for (int cx = 1; cx <= 8; cx++) {
            for (int cz = 1; cz <= 8; cz++) {
                if (style(cx, cz) != FARM) continue;
                return new BlockPos(cx * PLOT + 16, SURFACE, cz * PLOT + 16);
            }
        }
        return BlockPos.ZERO;
    }

    public static int hash(int x, int z) {
        int h = x * 73428767 ^ z * 912931;
        h = (h ^ (h >>> 16)) * 0x45d9f3b;
        h ^= h >>> 16;
        return h & 0x7fffffff;
    }

    private static boolean reserved(int x, int z) {
        return spot(x, z, PLAYER_SPAWN) || spot(x, z, CHIEF_POS) || spot(x, z, ANCESTOR_POS)
                || spot(x, z, SWEEPER_POS) || spot(x, z, DODGE_POS) || spot(x, z, TELEPORT_POS)
                || spot(x, z, CHICKEN_POS) || spot(x, z, DOG_POS) || spot(x, z, HIM_POS)
                || spot(x, z, GUARD_POS) || spot(x, z, FISHER_POS);
    }

    private static boolean spot(int x, int z, BlockPos pos) {
        return x == pos.getX() && z == pos.getZ();
    }

    private static BlockState groundCover(int x, int z) {
        if (inPlaza(x, z)) return plazaGround(x, z);
        if (isRoad(x, z)) return PATH;
        return GRASS;
    }

    private static BlockState plazaGround(int x, int z) {
        if (Math.abs(x) <= 2 && z >= -14 && z <= 18) return BRICKS;
        int lx = Math.floorMod(x, PLOT);
        int lz = Math.floorMod(z, PLOT);
        if (lx < 5 || lz < 5) return BRICKS;
        return GRASS;
    }

    private static BlockState builtAt(int x, int y, int z) {
        if (inPlaza(x, z)) return plazaBuilt(x, y, z);
        int cellX = Math.floorDiv(x, PLOT);
        int cellZ = Math.floorDiv(z, PLOT);
        if (cellX >= -1 && cellX <= 0 && cellZ >= -1 && cellZ <= 0) {
            return bufferBuilt(x, y, z);
        }
        return plotBuilt(x, y, z, cellX, cellZ);
    }

    private static BlockState bufferBuilt(int x, int y, int z) {
        return lamp(x, y, z);
    }

    private static BlockState plazaBuilt(int x, int y, int z) {
        BlockState stele = stele(x, y, z);
        if (stele != null) return stele;
        BlockState portal = portal(x, y, z);
        if (portal != null) return portal;
        for (House h : PLAZA_HOUSES) {
            BlockState home = house(x, y, z, h);
            if (home != null) return home;
            if (h.approach(x, z)) {
                if (y == SURFACE) return BRICKS;
                if (y == SURFACE + 1 || y == SURFACE + 2) return AIR;
            }
        }
        BlockState well = well(x, y, z, 6, 8);
        if (well != null) return well;
        BlockState air = wujiaAir(x, y, z);
        if (air != null) return air;
        BlockState patch = cabbagePatch(x, y, z);
        if (patch != null) return patch;
        BlockState treeA = tree(x, y, z, -16, -14);
        if (treeA != null) return treeA;
        BlockState treeB = tree(x, y, z, 16, -14);
        if (treeB != null) return treeB;
        if ((x == -4 || x == 4) && z == -2 && y == SURFACE + 1) {
            return ModBlocks.WUJIA_STONE.get().defaultBlockState();
        }
        BlockState lamp = lamp(x, y, z);
        if (lamp != null) return lamp;
        if (y == SURFACE && Math.abs(x - HIM_POS.getX()) <= 1 && Math.abs(z - HIM_POS.getZ()) <= 1) {
            return Blocks.END_STONE_BRICKS.defaultBlockState();
        }
        if (x == HIM_POS.getX() + 2 && z == HIM_POS.getZ() && y == SURFACE + 1) {
            return Blocks.CRYING_OBSIDIAN.defaultBlockState();
        }
        if (y == SURFACE + 1 && ((x == 10 && z == 16) || (x == -10 && z == 16) || (x == -20 && z == 10))) {
            return Blocks.DANDELION.defaultBlockState();
        }
        if (y == SURFACE && x >= -2 && x <= 2 && z >= -10 && z <= -6) return ANDESITE;
        return null;
    }

    /** 井口上方飘着的吴家空气。 */
    private static BlockState wujiaAir(int x, int y, int z) {
        int dx = Math.abs(x - AIR_WELL.getX());
        int dz = Math.abs(z - AIR_WELL.getZ());
        if (dx > 1 || dz > 1) return null;
        if (y < SURFACE + 1 || y > SURFACE + 3) return null;
        if (dx == 1 && dz == 1) return null;
        return ModBlocks.WUJIA_AIR.get().defaultBlockState();
    }

    private static BlockState plotBuilt(int x, int y, int z, int cellX, int cellZ) {
        int kind = style(cellX, cellZ);
        int originX = cellX * PLOT;
        int originZ = cellZ * PLOT;
        if (kind == FARM) {
            BlockState farm = farm(x, y, z, originX, originZ);
            if (farm != null) return farm;
            return lamp(x, y, z);
        }
        int[] bounds = houseBounds(cellX, cellZ, kind);
        House descriptor = new House(bounds[0], bounds[2], bounds[1], bounds[3], kind, false);
        BlockState home = house(x, y, z, descriptor);
        if (home != null) return home;
        if (descriptor.approach(x, z)) {
            if (y == SURFACE) return PATH;
            if (y == SURFACE + 1 || y == SURFACE + 2) return AIR;
        }

        // 院子里的零碎：柴堆、水井、树、草垛
        if (hash(cellX, cellZ) % 11 == 0) {
            BlockState well = well(x, y, z, originX + 34, originZ + 34);
            if (well != null) return well;
        } else if (hash(cellX, cellZ) % 7 == 0) {
            BlockState tree = tree(x, y, z, originX + 32, originZ + 28);
            if (tree != null) return tree;
        }
        BlockState yard = yard(x, y, z, bounds[0], bounds[2], bounds[1], bounds[3], kind);
        if (yard != null) return yard;
        return lamp(x, y, z);
    }

    /** 房子外面那一圈：栅栏、花、柴堆、草垛。 */
    private static BlockState yard(int x, int y, int z, int x0, int z0, int x1, int z1, int kind) {
        if (y != SURFACE + 1) return null;
        // 门口的花
        if (x == (x0 + x1) / 2 - 1 && z == z1 + 1) return flower(kind);
        if (x == (x0 + x1) / 2 + 1 && z == z1 + 1) return Blocks.GRASS.defaultBlockState();
        // 柴堆
        if (x == x0 - 1 && z >= z1 - 1 && z <= z1 && y == SURFACE + 1) {
            return Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
        }
        if (x == x0 - 1 && z == z1 - 2 && y == SURFACE + 2) {
            return Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
        }
        // 草垛
        if (x == x1 + 1 && z == z1 && y == SURFACE + 1) return Blocks.HAY_BLOCK.defaultBlockState();
        return null;
    }

    private static BlockState flower(int kind) {
        return switch (kind) {
            case 1 -> Blocks.POPPY.defaultBlockState();
            case 2 -> Blocks.RED_TULIP.defaultBlockState();
            case 4 -> Blocks.OXEYE_DAISY.defaultBlockState();
            case 5 -> Blocks.CORNFLOWER.defaultBlockState();
            default -> Blocks.DANDELION.defaultBlockState();
        };
    }

    private static BlockState stele(int x, int y, int z) {
        if (x != 0 || z != -8) return null;
        if (y == SURFACE + 1) {
            return ModBlocks.WUJIA_STELE.get().defaultBlockState().setValue(WujiaSteleBlock.HALF, DoubleBlockHalf.LOWER);
        }
        if (y == SURFACE + 2) {
            return ModBlocks.WUJIA_STELE.get().defaultBlockState().setValue(WujiaSteleBlock.HALF, DoubleBlockHalf.UPPER);
        }
        return null;
    }

    private static BlockState portal(int x, int y, int z) {
        if (z != PORTAL_Z || x < -1 || x > 2 || y < SURFACE || y > SURFACE + 4) return null;
        boolean frame = x == -1 || x == 2 || y == SURFACE || y == SURFACE + 4;
        if (frame) return ModBlocks.CLOUD_BLOCK.get().defaultBlockState();
        return ModBlocks.WUJIA_PORTAL.get().defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_AXIS, Direction.Axis.X);
    }

    // ------------------------------------------------------------------
    // 房子
    // ------------------------------------------------------------------

    private static BlockState house(int x, int y, int z, House descriptor) {
        int x0 = descriptor.x0(), z0 = descriptor.z0(), x1 = descriptor.x1(), z1 = descriptor.z1();
        int kind = descriptor.kind();
        // 屋檐外扩一圈
        if (x < x0 - 1 || x > x1 + 1 || z < z0 - 1 || z > z1 + 1) return null;

        boolean outerRing = x == x0 - 1 || x == x1 + 1 || z == z0 - 1 || z == z1 + 1;
        boolean borderX = x == x0 || x == x1;
        boolean borderZ = z == z0 || z == z1;
        boolean border = !outerRing && (borderX || borderZ);
        boolean corner = borderX && borderZ;
        int doorX = descriptor.doorX();
        boolean doorCol = x == doorX && z == z1;
        int wallHeight = 3;

        if (y == SURFACE) {
            if (outerRing) return Blocks.COBBLESTONE.defaultBlockState();
            return floorBlock(kind);
        }

        // 墙
        if (y >= SURFACE + 1 && y <= SURFACE + wallHeight && border) {
            if (doorCol && (y == SURFACE + 1 || y == SURFACE + 2)) {
                DoubleBlockHalf half = y == SURFACE + 1 ? DoubleBlockHalf.LOWER : DoubleBlockHalf.UPPER;
                return doorBlock(kind).defaultBlockState()
                        .setValue(DoorBlock.FACING, Direction.SOUTH)
                        .setValue(DoorBlock.HALF, half)
                        .setValue(DoorBlock.HINGE, DoorHingeSide.LEFT)
                        .setValue(DoorBlock.OPEN, false)
                        .setValue(DoorBlock.POWERED, false);
            }
            if (y == SURFACE + 2 && !corner && !doorCol) {
                // 窗户：正面和两侧都有
                boolean windowSide = borderX ? Math.floorMod(z, 3) == 0 : Math.floorMod(x, 3) == 0;
                if (windowSide) return GLASS;
            }
            return wallBlock(kind, corner, y);
        }

        // Evaluate the roof before excluding the apron: eaves/flat-roof rails extend one block.
        if (y > SURFACE + wallHeight) {
            return roofAt(x, y, z, x0, z0, x1, z1, kind);
        }
        if (outerRing) return null;

        // 屋内
        if (y >= SURFACE + 1 && y <= SURFACE + wallHeight) {
            BlockState furniture = furniture(descriptor, x, y, z);
            if (furniture != null) return furniture;
            return AIR;
        }
        return null;
    }

    /** 屋顶：越靠中间越高，形成坡顶；边缘用楼梯朝向屋脊。 */
    private static BlockState roofAt(int x, int y, int z, int x0, int z0, int x1, int z1, int kind) {
        int levels = switch (kind) {
            case 1, 4 -> 2;
            case 5 -> 3;
            default -> 1;
        };
        int midX2 = x0 + x1;
        int midZ2 = z0 + z1;
        int dx2 = Math.abs(x * 2 - midX2);
        int dz2 = Math.abs(z * 2 - midZ2);
        int spanX = (x1 - x0) + 2;
        int spanZ = (z1 - z0) + 2;

        // Solid ceiling beam supplies a real downward support face for the hanging lantern.
        if (x == (x0 + x1) / 2 && z == z0 + 2 && y == SURFACE + 4) return floorBlock(kind);

        // 烟囱
        if (kind != 2 && x == x0 + 1 && z == z0 + 1 && y >= SURFACE + 4 && y < SURFACE + 5 + levels) {
            return Blocks.BRICK_WALL.defaultBlockState();
        }

        for (int level = 0; level < levels; level++) {
            if (y != SURFACE + 4 + level) continue;
            int shrink = level * 2;
            if (dx2 <= spanX - shrink && dz2 <= spanZ - shrink) {
                return roofBlock(kind, level == levels - 1, z * 2 < midZ2, x * 2 < midX2, dx2, dz2, spanX, spanZ);
            }
        }

        // 平顶的护栏
        if (kind == 2 && y == SURFACE + 5
                && (x == x0 - 1 || x == x1 + 1 || z == z0 - 1 || z == z1 + 1)) {
            return railing(x, z, x0 - 1, z0 - 1, x1 + 1, z1 + 1);
        }
        return null;
    }

    private static BlockState railing(int x, int z, int x0, int z0, int x1, int z1) {
        return Blocks.BRICK_WALL.defaultBlockState()
                .setValue(BlockStateProperties.UP, true)
                .setValue(BlockStateProperties.NORTH_WALL, z > z0 && (x == x0 || x == x1) ? WallSide.LOW : WallSide.NONE)
                .setValue(BlockStateProperties.SOUTH_WALL, z < z1 && (x == x0 || x == x1) ? WallSide.LOW : WallSide.NONE)
                .setValue(BlockStateProperties.WEST_WALL, x > x0 && (z == z0 || z == z1) ? WallSide.LOW : WallSide.NONE)
                .setValue(BlockStateProperties.EAST_WALL, x < x1 && (z == z0 || z == z1) ? WallSide.LOW : WallSide.NONE);
    }

    // ------------------------------------------------------------------
    // 家具（房屋里面，y = SURFACE + 1 起）
    // ------------------------------------------------------------------

    /**
     * 屋子里的家具摆位。同时给世界生成和"老存档补家具"用。
     * 全部由坐标算出来，不依赖方块实体。
     */
    public static BlockState furnitureAt(int x, int y, int z) {
        House h = houseAt(x, z);
        return h == null ? null : furniture(h, x, y, z);
    }

    private static BlockState furniture(House h, int x, int y, int z) {
        if (y < SURFACE + 1 || y > SURFACE + 3 || !h.contains(x, z) || h.clearance(x, z)) return null;
        RoomShape shape = new RoomShape(h.width(), h.depth(), h.kind(), h.doorX() - h.x0());
        Map<BlockPos, BlockState> local = ROOM_FURNITURE.computeIfAbsent(shape, key -> {
            Map<BlockPos, BlockState> states = new java.util.HashMap<>();
            for (FurnitureGroup group : furniturePlan(h)) {
                for (FurnitureBlock block : group.blocks()) {
                    states.put(block.pos().offset(-h.x0(), 0, -h.z0()), block.state());
                }
            }
            return Map.copyOf(states);
        });
        return local.get(new BlockPos(x - h.x0(), y, z - h.z0()));
    }

    /**
     * Original coordinate design, informed by vanilla plains small/medium house and library records:
     * paired wall-side beds, fence/pressure-plate tables, and sparse wall-side workstations.
     * No vanilla templates or assets are copied into the mod.
     */
    public static List<FurnitureGroup> furniturePlan(House h) {
        List<FurnitureGroup> plan = new ArrayList<>();
        int x = h.x0(), z = h.z0(), kind = h.kind();
        plan.add(new FurnitureGroup("bed", false, List.of(
                furnishing(x + 1, 1, z + 2, bed(kind, BedPart.FOOT, Direction.NORTH)),
                furnishing(x + 1, 1, z + 1, bed(kind, BedPart.HEAD, Direction.NORTH)))));

        // Compact rooms use one chest; larger rooms use an explicit, correctly oriented pair.
        boolean paired = h.width() >= 9 && h.depth() >= 9;
        BlockState chest = Blocks.CHEST.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.WEST)
                .setValue(BlockStateProperties.CHEST_TYPE, paired ? ChestType.RIGHT : ChestType.SINGLE);
        List<FurnitureBlock> chests = new ArrayList<>();
        chests.add(furnishing(h.x1() - 1, 1, z + 1, chest));
        if (paired) chests.add(furnishing(h.x1() - 1, 1, z + 2,
                chest.setValue(BlockStateProperties.CHEST_TYPE, ChestType.LEFT)));
        plan.add(new FurnitureGroup("chest", true, List.copyOf(chests)));
        add(plan, "crafting", false, furnishing(h.x1() - 1, 1, z + (paired ? 3 : 2), Blocks.CRAFTING_TABLE.defaultBlockState()));
        BlockState workstation = switch (kind) {
            case 1 -> Blocks.SMOKER.defaultBlockState();
            case 2 -> Blocks.BLAST_FURNACE.defaultBlockState();
            default -> Blocks.FURNACE.defaultBlockState();
        };
        add(plan, "hearth", true, furnishing(h.x1() - 1, 1, z + (paired ? 4 : 3),
                workstation.setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.WEST)));

        // Tables begin beyond BOTH bed halves; a shallow house only has room for one post.
        int tableZ = z + 3;
        boolean wideTable = h.width() >= 8 && h.depth() >= 7;
        BlockState post = Blocks.OAK_FENCE.defaultBlockState().setValue(BlockStateProperties.WEST, true)
                .setValue(BlockStateProperties.EAST, wideTable);
        List<FurnitureBlock> table = new ArrayList<>();
        table.add(furnishing(x + 1, 1, tableZ, post));
        table.add(furnishing(x + 1, 2, tableZ, Blocks.OAK_PRESSURE_PLATE.defaultBlockState()));
        if (wideTable) {
            table.add(furnishing(x + 2, 1, tableZ, Blocks.OAK_FENCE.defaultBlockState().setValue(BlockStateProperties.WEST, true)));
            table.add(furnishing(x + 2, 2, tableZ, Blocks.OAK_PRESSURE_PLATE.defaultBlockState()));
        }
        plan.add(new FurnitureGroup("table", false, List.copyOf(table)));
        if (kind == 4) {
            add(plan, "books", false, furnishing(x + 2, 1, z + 1, Blocks.BOOKSHELF.defaultBlockState()));
            add(plan, "lectern", true, furnishing(x + 3, 1, z + 1,
                    Blocks.LECTERN.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH)));
        }
        int midZ = z + 2;
        add(plan, "rug", false, furnishing(h.doorX(), 1, midZ, carpet(kind)));
        // The ceiling beam in roofAt supplies a full downward support face.
        add(plan, "light", false, furnishing(h.doorX(), 3, midZ,
                Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true)));
        return List.copyOf(plan);
    }

    private static FurnitureBlock furnishing(int x, int dy, int z, BlockState state) {
        return new FurnitureBlock(new BlockPos(x, SURFACE + dy, z), state);
    }

    private static void add(List<FurnitureGroup> plan, String name, boolean container, FurnitureBlock block) {
        plan.add(new FurnitureGroup(name, container, List.of(block)));
    }

    private static BlockState bed(int kind, BedPart part, Direction facing) {
        Block bed = switch (kind) {
            case 1, 5 -> Blocks.BLUE_BED;
            case 4 -> Blocks.GREEN_BED;
            default -> Blocks.RED_BED;
        };
        return bed.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, facing)
                .setValue(BlockStateProperties.BED_PART, part)
                .setValue(BlockStateProperties.OCCUPIED, false);
    }

    private static BlockState carpet(int kind) {
        return switch (kind) {
            case 1 -> Blocks.BLUE_CARPET.defaultBlockState();
            case 2 -> Blocks.WHITE_CARPET.defaultBlockState();
            case 4 -> Blocks.LIME_CARPET.defaultBlockState();
            case 5 -> Blocks.GRAY_CARPET.defaultBlockState();
            default -> Blocks.ORANGE_CARPET.defaultBlockState();
        };
    }

    private static BlockState floorBlock(int kind) {
        return switch (kind) {
            case 1 -> Blocks.SPRUCE_PLANKS.defaultBlockState();
            case 2 -> Blocks.BRICKS.defaultBlockState();
            case 4 -> Blocks.BIRCH_PLANKS.defaultBlockState();
            case 5 -> Blocks.POLISHED_DEEPSLATE.defaultBlockState();
            default -> Blocks.OAK_PLANKS.defaultBlockState();
        };
    }

    private static BlockState wallBlock(int kind, boolean corner, int y) {
        return switch (kind) {
            case 1 -> corner
                    ? Blocks.SPRUCE_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y)
                    : Blocks.SPRUCE_PLANKS.defaultBlockState();
            case 2 -> y == SURFACE + 1 ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.BRICKS.defaultBlockState();
            case 4 -> corner
                    ? Blocks.BIRCH_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y)
                    : Blocks.BIRCH_PLANKS.defaultBlockState();
            case 5 -> corner
                    ? Blocks.DEEPSLATE_TILES.defaultBlockState()
                    : Blocks.STONE_BRICKS.defaultBlockState();
            default -> corner
                    ? Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y)
                    : Blocks.OAK_PLANKS.defaultBlockState();
        };
    }

    private static BlockState roofBlock(int kind, boolean ridge, boolean southSide, boolean westSide,
                                        int dx2, int dz2, int spanX, int spanZ) {
        Direction facing = dz2 >= dx2
                ? (southSide ? Direction.NORTH : Direction.SOUTH)
                : (westSide ? Direction.EAST : Direction.WEST);
        return switch (kind) {
            case 1 -> ridge
                    ? Blocks.SPRUCE_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM)
                    : Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING, facing);
            case 2 -> Blocks.BRICK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);
            case 4 -> ridge
                    ? Blocks.BIRCH_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP)
                    : Blocks.BIRCH_STAIRS.defaultBlockState().setValue(StairBlock.FACING, facing);
            case 5 -> ridge
                    ? Blocks.STONE_BRICK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM)
                    : Blocks.STONE_BRICK_STAIRS.defaultBlockState()
                    .setValue(StairBlock.FACING, facing)
                    .setValue(BlockStateProperties.HALF, Half.BOTTOM);
            default -> Blocks.OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM);
        };
    }

    private static Block doorBlock(int kind) {
        return switch (kind) {
            case 1 -> Blocks.SPRUCE_DOOR;
            case 4 -> Blocks.BIRCH_DOOR;
            default -> Blocks.OAK_DOOR;
        };
    }

    // ------------------------------------------------------------------
    // 田、井、树、路灯
    // ------------------------------------------------------------------

    private static BlockState farm(int x, int y, int z, int originX, int originZ) {
        int lx = x - originX;
        int lz = z - originZ;
        if (lx == 20 && (lz >= 5 && lz < 10 || lz > 30 && lz < PLOT)) {
            if (y == SURFACE) return PATH;
            if (y == SURFACE + 1 || y == SURFACE + 2) return AIR;
        }
        if (lx < 10 || lx > 30 || lz < 10 || lz > 30) return null;
        boolean edge = lx == 10 || lx == 30 || lz == 10 || lz == 30;
        // Two channels cover every crop within four horizontal blocks (including the corners).
        boolean water = (lx == 15 || lx == 25) && lz > 10 && lz < 30;
        boolean entrance = lx == 20 && lz >= 10 && lz <= 30;
        if (entrance) {
            if (y == SURFACE) return PATH;
            if (y == SURFACE + 1 || y == SURFACE + 2) return AIR;
        }
        if (edge) {
            if (y == SURFACE) return DIRT;
            if (y == SURFACE + 1) return farmFence(lx, lz);
            return null;
        }
        if (water) {
            if (y == SURFACE || y == SURFACE - 1) return WATER;
            return null;
        }
        if (y == SURFACE) return FARMLAND;
        if (y == SURFACE + 1) {
            if (Math.floorMod(lx * 3 + lz, 11) == 0) return ModBlocks.WU_CABBAGE_CROP.get().defaultBlockState();
            int pick = Math.floorMod(lx + lz * 5, 3);
            if (pick == 0) return Blocks.WHEAT.defaultBlockState().setValue(BlockStateProperties.AGE_7, 7);
            if (pick == 1) return Blocks.CARROTS.defaultBlockState().setValue(BlockStateProperties.AGE_7, 7);
            return Blocks.POTATOES.defaultBlockState().setValue(BlockStateProperties.AGE_7, 7);
        }
        return null;
    }

    private static BlockState farmFence(int x, int z) {
        return Blocks.OAK_FENCE.defaultBlockState()
                .setValue(BlockStateProperties.NORTH, (x == 10 || x == 30) && z > 10)
                .setValue(BlockStateProperties.SOUTH, (x == 10 || x == 30) && z < 30)
                .setValue(BlockStateProperties.WEST, (z == 10 || z == 30) && x > 10 && x != 21)
                .setValue(BlockStateProperties.EAST, (z == 10 || z == 30) && x < 30 && x != 19);
    }

    private static BlockState cabbagePatch(int x, int y, int z) {
        if (x < -12 || x > -7 || z < 8 || z > 12) return null;
        if (x == -10 && z == 10) {
            if (y == SURFACE) return WATER;
            if (y == SURFACE + 1) return AIR;
        }
        if (y == SURFACE) return FARMLAND;
        if (y == SURFACE + 1) return ModBlocks.WU_CABBAGE_CROP.get().defaultBlockState();
        return null;
    }

    private static BlockState well(int x, int y, int z, int cx, int cz) {
        if (x == cx && z == cz && y >= SURFACE - 2 && y <= SURFACE) return WATER;
        int dx = Math.abs(x - cx);
        int dz = Math.abs(z - cz);
        if (dx + dz == 1 && y == SURFACE + 1) return COBBLE;
        if (dx == 1 && dz == 1 && y == SURFACE) return COBBLE;
        return null;
    }

    private static BlockState tree(int x, int y, int z, int tx, int tz) {
        int dx = Math.abs(x - tx);
        int dz = Math.abs(z - tz);
        if (dx == 0 && dz == 0 && y >= SURFACE + 1 && y <= SURFACE + 4) {
            return Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y);
        }
        if (dx <= 2 && dz <= 2 && dx + dz > 0 && y >= SURFACE + 3 && y <= SURFACE + 6) {
            return Blocks.OAK_LEAVES.defaultBlockState()
                    .setValue(LeavesBlock.PERSISTENT, true)
                    .setValue(LeavesBlock.DISTANCE, 1);
        }
        if (dx <= 1 && dz <= 1 && y == SURFACE + 5) {
            return Blocks.OAK_LEAVES.defaultBlockState()
                    .setValue(LeavesBlock.PERSISTENT, true)
                    .setValue(LeavesBlock.DISTANCE, 1);
        }
        return null;
    }

    private static BlockState lamp(int x, int y, int z) {
        if (reserved(x, z)) return null;
        boolean post = (Math.floorMod(x, PLOT) == 2 && Math.floorMod(z, 16) == 0)
                || (Math.floorMod(z, PLOT) == 2 && Math.floorMod(x, 16) == 0);
        if (!post) return null;
        if (inPlaza(x, z)) {
            if (Math.abs(x) <= 2) return null;
        } else if (!isRoad(x, z) && !(Math.floorMod(x, PLOT) < 5 || Math.floorMod(z, PLOT) < 5)) {
            return null;
        }
        if (y == SURFACE + 1) return Blocks.OAK_FENCE.defaultBlockState();
        if (y == SURFACE + 2) return Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, false);
        return null;
    }
}
