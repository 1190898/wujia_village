package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.entity.combat.WuCombatRules;
import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 瞬移村民：模仿末影人的移动与瞬移方式。
 * 优雅从容，行走如常，移动时伴随末影粒子与音效瞬移，受击与接近目标时自主瞬移闪现。
 */
public class TeleportVillagerEntity extends WuVillagerBase {
    private int teleportCooldown = 0;

    public TeleportVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.teleport_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.teleport";
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide()) return;
        if (teleportCooldown > 0) teleportCooldown--;

        // 末影人式闲逛瞬移：概率瞬移到视线范围内的安全地面
        if (teleportCooldown == 0 && !getCombatController().busy()) {
            LivingEntity target = getTarget();
            if (target != null && target.isAlive()) {
                double dist = distanceTo(target);
                // 战斗中：如果距离较远，或者周期性绕后突袭
                if (dist > 4.0 && random.nextFloat() < 0.05f) {
                    teleportNearTarget(target);
                }
            } else if (random.nextFloat() < 0.005f) {
                // 平时闲逛：类似末影人，偶尔瞬移
                teleportRandomly(5.0, 10.0);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (!level().isClientSide() && isAlive()) {
            // 受击时像末影人一样瞬移脱离
            if (random.nextFloat() < 0.65f) {
                teleportRandomly(5.0, 9.0);
            }
        }
        return result;
    }

    public void wuTeleport() {
        teleportRandomly(4.0, 8.0);
    }

    public boolean teleportNearTarget(LivingEntity target) {
        if (target == null) return false;
        Vec3 tPos = target.position();
        double angle = random.nextDouble() * Math.PI * 2;
        double dist = 2.5 + random.nextDouble() * 2.0;
        Vec3 dest = new Vec3(tPos.x + Math.cos(angle) * dist, tPos.y, tPos.z + Math.sin(angle) * dist);
        return doEndermanTeleport(dest);
    }

    public boolean teleportRandomly(double minRadius, double maxRadius) {
        for (int i = 0; i < 16; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = minRadius + random.nextDouble() * (maxRadius - minRadius);
            double tx = getX() + Math.cos(angle) * dist;
            double tz = getZ() + Math.sin(angle) * dist;
            double ty = getY() + (random.nextInt(5) - 2);
            Vec3 candidate = new Vec3(tx, ty, tz);
            if (doEndermanTeleport(candidate)) return true;
        }
        return false;
    }

    public boolean doEndermanTeleport(Vec3 target) {
        if (level().isClientSide() || !(level() instanceof ServerLevel sl)) return false;
        if (!WuCombatRules.safeBlink(this, target)) return false;

        // 起点末影传送门粒子与音效
        sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 0.6, getZ(), 32, 0.35, 0.7, 0.35, 0.15);
        sl.playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.NEUTRAL, 0.9f, 1.0f);

        // 留下残影
        GhostVillagerEntity ghost = ModEntities.GHOST_VILLAGER.get().create(sl);
        if (ghost != null) {
            ghost.capture(this);
            sl.addFreshEntity(ghost);
        }

        // 瞬间位移（末影人机制）
        teleportTo(target.x, target.y, target.z);
        getNavigation().stop();
        setDeltaMovement(Vec3.ZERO);
        fallDistance = 0;

        // 终点末影传送门粒子
        sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 0.6, getZ(), 32, 0.35, 0.7, 0.35, 0.15);
        teleportCooldown = 40; // 2秒冷却
        return true;
    }

    @Override
    public net.minecraft.world.InteractionResult mobInteract(Player player, net.minecraft.world.InteractionHand hand) {
        var res = super.mobInteract(player, hand);
        if (!level().isClientSide() && teleportCooldown == 0) {
            teleportRandomly(4.0, 7.0);
        }
        return res;
    }
}
