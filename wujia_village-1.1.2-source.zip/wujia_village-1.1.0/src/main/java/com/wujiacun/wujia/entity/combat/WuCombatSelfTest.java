package com.wujiacun.wujia.entity.combat;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.*;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.util.ModDamageTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Actual controller/effect/projectile simulation ticks; no global time changes or real player accounts. */
public final class WuCombatSelfTest {
    private WuCombatSelfTest() {}
    public static void run(ServerLevel level, List<String> failures) {
        Map<BlockPos, BlockState> saved = new LinkedHashMap<>();
        List<Entity> entities = new ArrayList<>();
        BlockPos base = level.getSharedSpawnPos().offset(32, 0, 32);
        base = new BlockPos(base.getX(), Math.min(level.getMaxBuildHeight() - 20, Math.max(100, base.getY() + 30)), base.getZ());
        try {
            // Small reversible empty platform above existing structures, loaded explicitly for the test fixture.
            for (int x = -1; x <= 20; x++) for (int z = -1; z <= 16; z++) {
                level.getChunkAt(base.offset(x, 0, z));
                for (int y = -1; y <= 10; y++) {
                    BlockPos p = base.offset(x, y, z);
                    put(level, saved, p, y == -1 ? Blocks.STONE.defaultBlockState() : Blocks.AIR.defaultBlockState());
                }
            }
            GuardVillagerEntity guard = ModEntities.GUARD_VILLAGER.get().create(level);
            if (guard == null) { check(failures, "combat guard fixture", false); return; }
            spawn(level, entities, guard, point(base, 1, 2)); guard.setNoAi(true);
            guard.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(4);
            Zombie melee = zombie(level, entities, point(base, 3, 2));
            WuCombatController controller = guard.getCombatController();
            for (CombatAction expected : new CombatAction[]{CombatAction.MELEE_JAB, CombatAction.MELEE_SWEEP, CombatAction.MELEE_OVERHEAD, CombatAction.MELEE_THRUST}) {
                float before = melee.getHealth();
                int releaseBefore = controller.getReleaseCount();
                check(failures, "controller starts " + expected, controller.requestMelee(melee) && guard.getCombatAction() == expected);
                int contact = CombatAction.contactTick(guard.getActionDuration());
                for (int tick = 1; tick < contact; tick++) controller.tick();
                check(failures, "windup no damage " + expected, melee.getHealth() == before && controller.getReleaseCount() == releaseBefore);
                controller.tick();
                check(failures, "contact deals damage " + expected, melee.getHealth() < before && controller.getReleaseCount() == releaseBefore + 1);
                for (int tick = contact; tick < WuCombatController.duration(expected) + 6; tick++) controller.tick();
                check(failures, "single contact and recovery " + expected, controller.getReleaseCount() == releaseBefore + 1 && guard.getCombatAction() == CombatAction.IDLE);
                melee.invulnerableTime = 0; // Fixture only, so successive manual actions do not share frozen-world immunity.
            }
            melee.discard();
            guard.setPos(point(base, 1, 2));
            GuardVillagerEntity ally = ModEntities.GUARD_VILLAGER.get().create(level);
            spawn(level, entities, ally, point(base, 4, 2)); ally.setNoAi(true);
            Cow cow = new Cow(EntityType.COW, level); spawn(level, entities, cow, point(base, 5, 2)); cow.setNoAi(true);
            Zombie visible = zombie(level, entities, point(base, 7, 2));
            Zombie hidden = zombie(level, entities, point(base, 12, 2));
            for (int y = 0; y <= 4; y++) for (int z = 0; z <= 4; z++) put(level, saved, base.offset(10, y, z), Blocks.STONE.defaultBlockState());
            float allyHp = ally.getHealth(), cowHp = cow.getHealth(), visibleHp = visible.getHealth(), hiddenHp = hidden.getHealth();
            WuSkillEffectEntity ray = WuSkillEffectEntity.castLine(level, guard, guard.getEyePosition(), point(base, 17, 2).add(0, guard.getEyeHeight(), 0), WuSkillEffectEntity.SONIC, 0xFFAA33, 5);
            if (ray != null) entities.add(ray);
            check(failures, "sonic wall endpoint clipped", ray != null && ray.getDestination().x < base.getX() + 10.01);
            check(failures, "sonic hits exposed enemy", visible.getHealth() < visibleHp);
            check(failures, "sonic protects wall target and faction/animal", hidden.getHealth() == hiddenHp && ally.getHealth() == allyHp && cow.getHealth() == cowHp);
            if (ray != null) { float hp = visible.getHealth(); for (int i = 0; i < 14; i++) ray.tick();
                check(failures, "sonic one cast and finite disposal", ray.getImpactCount() == 1 && ray.isRemoved() && visible.getHealth() == hp); }
            var player = new net.minecraftforge.common.util.FakePlayer(level, new com.mojang.authlib.GameProfile(UUID.randomUUID(), "wu_combat_test"));
            check(failures, "neutral player protected", !WuCombatRules.canHit(guard, player));
            guard.rememberAttacker(player);
            check(failures, "valid player retaliation accepted", WuCombatRules.canHit(guard, player));
            player.setGameMode(net.minecraft.world.level.GameType.CREATIVE);
            check(failures, "creative overrides retaliation", player.isCreative() && !WuCombatRules.canHit(guard, player));
            guard.setTarget(null);
            guard.rememberAttacker(cow);
            check(failures, "animals never become retaliation targets", !WuCombatRules.canHit(guard, cow));

            guard.setPos(point(base, 1, 8));
            Zombie swordTarget = zombie(level, entities, point(base, 8, 8));
            for (int y = 0; y <= 4; y++) for (int z = 6; z <= 10; z++) put(level, saved, base.offset(5, y, z), Blocks.STONE.defaultBlockState());
            WuSwordEntity sword = WuSwordEntity.summon(level, guard, swordTarget, 0, 3, 0xABCDEF, 6);
            if (sword != null) {
                entities.add(sword);
                for (int i = 0; i < 11; i++) sword.tick();
                check(failures, "sword real orbit before release", !sword.hasLaunched() && !sword.isRemoved());
                float hp = swordTarget.getHealth();
                for (int i = 0; i < WuSwordEntity.MAX_LIFETIME; i++) if (!sword.isRemoved()) sword.tick();
                check(failures, "sword swept wall collision disposes", sword.hasLaunched() && sword.isRemoved() && swordTarget.getHealth() == hp);
                var source = ModDamageTypes.wuSword(level, sword, guard);
                check(failures, "sword owner and projectile damage classification", source.getEntity() == guard && source.getDirectEntity() == sword && source.is(DamageTypeTags.IS_PROJECTILE));
            } else check(failures, "sword fixture created", false);
            guard.setPos(point(base, 1, 13));
            Zombie openTarget = zombie(level, entities, point(base, 8, 13));
            WuSwordEntity openSword = WuSwordEntity.summon(level, guard, openTarget, 0, 1, 0xFFFFFF, 6);
            if (openSword != null) {
                entities.add(openSword); float hp = openTarget.getHealth();
                for (int i = 0; i < WuSwordEntity.MAX_LIFETIME; i++) if (!openSword.isRemoved()) openSword.tick();
                check(failures, "sword swept entity hit and disposal", openSword.isRemoved() && openTarget.getHealth() < hp);
            } else check(failures, "open sword created", false);

            Vec3 center = point(base, 15, 9);
            Zombie palmTarget = zombie(level, entities, center);
            Zombie circleOutside = zombie(level, entities, center.add(2.5, 0, 2.5));
            WuSkillEffectEntity palm = WuSkillEffectEntity.spawnPalm(level, guard, center, 0xFFEEDD, 7);
            if (palm != null) {
                entities.add(palm); float hp = palmTarget.getHealth(), outsideHp = circleOutside.getHealth();
                for (int i = 0; i < 23; i++) palm.tick();
                check(failures, "palm warning and descent do not damage", palm.getImpactCount() == 0 && palmTarget.getHealth() == hp);
                palm.tick();
                check(failures, "palm circular single impact at24", palm.getImpactCount() == 1 && palmTarget.getHealth() < hp && circleOutside.getHealth() == outsideHp);
                float after = palmTarget.getHealth();
                for (int i = 24; i < 33; i++) palm.tick();
                check(failures, "palm no repeat and finite lifetime32", palm.isRemoved() && palm.getImpactCount() == 1 && palmTarget.getHealth() == after);
            } else check(failures, "palm fixture created", false);
            palmTarget.invulnerableTime = 0;
            for (int x = 12; x <= 18; x++) for (int z = 6; z <= 12; z++) put(level, saved, base.offset(x, 3, z), Blocks.STONE.defaultBlockState());
            WuSkillEffectEntity roofPalm = WuSkillEffectEntity.spawnPalm(level, guard, center, 0xFFFFFF, 7);
            if (roofPalm != null) {
                entities.add(roofPalm); float hp = palmTarget.getHealth();
                for (int i = 0; i < 25; i++) roofPalm.tick();
                check(failures, "palm roof clip protects below", roofPalm.getDestination().y >= base.getY() + 4 && palmTarget.getHealth() == hp);
            } else check(failures, "roof palm fixture created", false);

            // Full bbox, wall crossing, unsupported floor and hazard restrictions use the real blink validator.
            guard.setPos(point(base, 1, 5));
            Vec3 from = guard.position(), to = from.add(3, 0, 0);
            check(failures, "blink safe path accepted", WuCombatRules.safeBlink(guard, to));
            guard.setNoGravity(true);
            check(failures, "blink starts pose", controller.requestBlink(to));
            for (int i = 0; i < 5; i++) controller.tick();
            check(failures, "blink cannot move before six ticks", guard.position().distanceToSqr(from) < 0.001);
            controller.tick();
            check(failures, "blink at six preserves gravity and clears motion", guard.position().distanceToSqr(to) < 0.001 && guard.isNoGravity() && guard.getDeltaMovement().lengthSqr() < 0.001 && guard.getNavigation().isDone());
            for (int i = 0; i < 8; i++) controller.tick();
            check(failures, "blink has recovery", guard.getCombatAction() == CombatAction.IDLE);
            guard.setPos(from);
            for (int y = 0; y < 4; y++) put(level, saved, base.offset(2, y, 5), Blocks.STONE.defaultBlockState());
            check(failures, "blink rejects wall crossing", !WuCombatRules.safeBlink(guard, to));
            for (int y = 0; y < 4; y++) put(level, saved, base.offset(2, y, 5), Blocks.AIR.defaultBlockState());
            put(level, saved, base.offset(4, -1, 5), Blocks.AIR.defaultBlockState());
            check(failures, "blink rejects unsupported destination", !WuCombatRules.safeBlink(guard, to));
            put(level, saved, base.offset(4, -1, 5), Blocks.MAGMA_BLOCK.defaultBlockState());
            check(failures, "blink rejects hazardous floor", !WuCombatRules.safeBlink(guard, to));
            check(failures, "blink bounded range and world border", !WuCombatRules.safeBlink(guard, from.add(6, 0, 0))
                    && !WuCombatRules.safeBlink(guard, new Vec3(level.getWorldBorder().getMaxX() + 1, from.y, from.z)));
            for (GhostVillagerEntity ghost : level.getEntitiesOfClass(GhostVillagerEntity.class, guard.getBoundingBox().inflate(6))) {
                entities.add(ghost);
                check(failures, "ghost copied role and action", ghost.getSkinVariant() == 5 && ghost.getGhostAction() == CombatAction.BLINK && ghost.getGhostActionAge() == 6);
                for (int i = 0; i < GhostVillagerEntity.LIFETIME; i++) ghost.tick();
                check(failures, "ghost bounded disposal", ghost.isRemoved());
            }

            FisherVillagerEntity fisher = ModEntities.FISHER_VILLAGER.get().create(level);
            spawn(level, entities, fisher, point(base, 1, 15)); fisher.setNoAi(true);
            fisher.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(8);
            Zombie waterTarget = zombie(level, entities, point(base, 8, 15));
            WuCombatController fishing = fisher.getCombatController();
            float waterHp = waterTarget.getHealth();
            int casts = fishing.getReleaseCount();
            check(failures, "fisher requestRanged chooses WATER", fishing.requestRanged(waterTarget)
                    && fisher.getCombatAction() == CombatAction.WATER && fisher.getActionDuration() == 24);
            check(failures, "fisher cannot overlap ranged casts", !fishing.requestRanged(waterTarget));
            for (int i = 0; i < 10; i++) fishing.tick();
            check(failures, "fisher WATER windup holds damage", waterTarget.getHealth() == waterHp && fishing.getReleaseCount() == casts);
            fishing.tick();
            List<WuSkillEffectEntity> waterEffects = level.getEntitiesOfClass(WuSkillEffectEntity.class,
                    fisher.getBoundingBox().inflate(20), e -> e.getEffectKind() == WuSkillEffectEntity.WATER);
            entities.addAll(waterEffects);
            check(failures, "fisher WATER releases at11 with slow", fishing.getReleaseCount() == casts + 1
                    && waterTarget.getHealth() < waterHp
                    && waterTarget.hasEffect(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN)
                    && waterEffects.size() == 1);
            float waterAfter = waterTarget.getHealth();
            for (WuSkillEffectEntity water : waterEffects) for (int i = 0; i < 14; i++) water.tick();
            for (int i = 11; i < 30; i++) fishing.tick();
            check(failures, "fisher WATER single damage and finite disposal", waterEffects.size() == 1
                    && waterEffects.get(0).isRemoved() && waterEffects.get(0).getImpactCount() == 1
                    && waterTarget.getHealth() == waterAfter && fishing.getReleaseCount() == casts + 1
                    && fisher.getCombatAction() == CombatAction.IDLE);
        } catch (Throwable t) {
            failures.add("combat selftest exception: " + t);
            WujiaVillageMod.LOGGER.error("[selftest] FAIL combat exception", t);
        } finally {
            for (Entity e : entities) if (e != null && !e.isRemoved()) e.discard();
            for (var entry : saved.entrySet()) level.setBlock(entry.getKey(), entry.getValue(), 2);
        }
    }
    private static Vec3 point(BlockPos base, double x, double z) { return new Vec3(base.getX() + x + 0.5, base.getY(), base.getZ() + z + 0.5); }
    private static void spawn(ServerLevel level, List<Entity> all, Entity entity, Vec3 at) {
        if (entity == null) throw new IllegalStateException("null entity fixture");
        entity.setPos(at); level.addFreshEntity(entity); all.add(entity);
    }
    private static Zombie zombie(ServerLevel level, List<Entity> all, Vec3 at) {
        Zombie zombie = new Zombie(EntityType.ZOMBIE, level); zombie.setNoAi(true); zombie.setNoGravity(true);
        zombie.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200); zombie.setHealth(200);
        spawn(level, all, zombie, at); return zombie;
    }
    private static void put(ServerLevel level, Map<BlockPos, BlockState> saved, BlockPos pos, BlockState state) {
        BlockPos key = pos.immutable(); saved.putIfAbsent(key, level.getBlockState(key)); level.setBlock(key, state, 2);
    }
    private static void check(List<String> failures, String name, boolean pass) {
        WujiaVillageMod.LOGGER.info("[selftest] {} {}", pass ? "OK" : "FAIL", name);
        if (!pass) failures.add(name);
    }
}
