package com.wujiacun.wujia.client;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.client.model.WuHumanoidModel;
import com.wujiacun.wujia.client.model.WuPalmModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Opt-in startup check only. Does not open a world or stand in for in-world visual acceptance. */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, value = Dist.CLIENT)
public final class WuClientSmokeTest {
    private static boolean finished;
    private static int readyTicks;

    private WuClientSmokeTest() {}

    @SubscribeEvent
    public static void tick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || finished || !Boolean.getBoolean("wujia.clientSmoke")) return;
        Minecraft client = Minecraft.getInstance();
        if (client.screen == null || client.getOverlay() != null || ++readyTicks < 60) return;
        finished = true;
        try {
            new WuHumanoidModel<Mob>(client.getEntityModels().bakeLayer(ModelLayers.PLAYER));
            new WuPalmModel(client.getEntityModels().bakeLayer(WuSkillEffectRenderer.PALM_LAYER));
            for (String name : new String[]{"dodge_villager", "teleport_villager", "chief_villager",
                    "ancestor_villager", "sweeper_villager", "guard_villager", "fisher_villager",
                    "him_villager", "ancestor_villager_eyes", "him_villager_eyes", "skill_white", "skill_palm"}) {
                ResourceLocation texture = new ResourceLocation(WujiaVillageMod.MODID, "textures/entity/" + name + ".png");
                if (client.getResourceManager().getResource(texture).isEmpty()) throw new IllegalStateException("Missing " + texture);
                client.getTextureManager().bindForSetup(texture);
            }
            WujiaVillageMod.LOGGER.info("CLIENT SMOKE OK: startup screen {}, model layers and twelve textures loaded; no world opened",
                    client.screen.getClass().getSimpleName());
        } catch (Throwable error) {
            WujiaVillageMod.LOGGER.error("CLIENT SMOKE FAIL", error);
        } finally {
            client.stop();
        }
    }
}
