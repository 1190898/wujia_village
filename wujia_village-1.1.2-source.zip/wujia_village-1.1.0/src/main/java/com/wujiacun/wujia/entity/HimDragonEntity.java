package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Him 的宠物龙。
 *
 * <p>它不再走"末地龙战"那套阶段循环（那套会让它一直围着 (0,0) 盘旋找末地）。
 * 现在它是真·宠物：绕着主人头顶慢慢兜圈，主人被打就去咬人，被打了会还手，
 * 到点自己飞回家（作业交完了）。</p>
 */
public class HimDragonEntity extends EnderDragon {

    /** 出现多久后自己飞回家 */
    public static final int RECALL_TICKS = 2400;
    /** 离主人超过这个距离就直接飞回主人身边 */
    private static final double TELEPORT_DISTANCE = 96.0;

    private UUID owner;
    private int age;
    private int attackCooldown;

    public static final float PET_MAX_HEALTH = 1024.0f; // 原版 max_health 硬顶

    public HimDragonEntity(EntityType<? extends EnderDragon> type, Level level) {
        super(type, level);
        this.setDragonFight(null);
        this.keepHoverPhase();
        this.setPersistenceRequired();
        this.setCustomName(Component.translatable("entity.wujia_village.him_dragon"));
        this.setCustomNameVisible(true);
        if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(PET_MAX_HEALTH);
            this.setHealth(PET_MAX_HEALTH);
        }
        if (this.getAttribute(Attributes.ARMOR) != null) {
            this.getAttribute(Attributes.ARMOR).setBaseValue(24.0);
        }
        if (this.getAttribute(Attributes.KNOCKBACK_RESISTANCE) != null) {
            this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
        }
    }

    @Override
    public EntityType<?> getType() {
        // 原版龙构造器忽略传入 type；生成包和存档必须保留自定义宠物类型。
        return ModEntities.HIM_DRAGON.get();
    }

    public void setPetOf(UUID owner) {
        this.owner = owner;
    }

    private LivingEntity ownerEntity() {
        if (this.owner == null) return null;
        if (!(this.level() instanceof ServerLevel level)) return null;
        Entity e = level.getEntity(this.owner);
        return e instanceof LivingEntity le && le.isAlive() ? le : null;
    }

    // ------------------------------------------------------------------
    // 飞行：不用原版阶段 AI，自己算航向，让原版只负责动画和碰撞
    // ------------------------------------------------------------------

    @Override
    public void aiStep() {
        if (this.level().isClientSide()) {
            super.aiStep();
            return;
        }
        // 先锁定悬停，防止生物蛋/NBT 初始阶段进入原版末地寻路。
        this.keepHoverPhase();
        // 原版在悬停阶段会自己刹车，所以移动放在它算完之后再做
        super.aiStep();
        if (this.isDeadOrDying()) return;

        this.age++;
        if (this.attackCooldown > 0) this.attackCooldown--;

        if (this.age >= RECALL_TICKS) {
            this.recall();
            return;
        }
        this.petFlight();
        this.petCombat();
    }

    /** 保证宠物永远在"悬停"阶段，不回到末地龙战的盘旋/冲锋循环。 */
    private void keepHoverPhase() {
        if (this.getPhaseManager() == null) return;
        if (this.getPhaseManager().getCurrentPhase() == null) return;
        if (this.getPhaseManager().getCurrentPhase().getPhase() != EnderDragonPhase.HOVERING) {
            this.getPhaseManager().setPhase(EnderDragonPhase.HOVERING);
        }
    }

    private void petFlight() {
        this.keepHoverPhase();

        LivingEntity focus = this.getTarget();
        boolean chasing = focus != null && focus.isAlive() && !(focus instanceof Player && focus.isSpectator());

        LivingEntity ownerEntity = this.ownerEntity();
        if (!chasing && ownerEntity == null) {
            // 生物蛋、发射器和未加载主人都允许无主；从第一 tick 起安全等待。
            this.setDeltaMovement(Vec3.ZERO);
            if (this.age >= 200) this.discard();
            return;
        }

        Vec3 center = chasing ? focus.position() : ownerEntity.position();
        double radius = chasing ? 8.0 : 10.0;
        double height = chasing ? 9.0 : 12.0;
        double phase = this.tickCount * 0.012;

        double tx = center.x + Math.cos(phase) * radius;
        double tz = center.z + Math.sin(phase) * radius;
        double ty = center.y + height;

        // 太远了直接飞回去，别让宠物走丢
        if (!chasing && this.distanceToSqr(center) > TELEPORT_DISTANCE * TELEPORT_DISTANCE) {
            this.randomTeleport(center.x, center.y + height, center.z, true);
            return;
        }

        double dx = tx - this.getX();
        double dz = tz - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        // 朝向目标点（平滑转向，别像陀螺）
        float wantYaw = (float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float yaw = Mth.approachDegrees(this.getYRot(), wantYaw, 6.0f);
        this.setYRot(yaw);
        this.yRotA = Mth.clamp(Mth.wrapDegrees(wantYaw - yaw), -20.0f, 20.0f);
        this.setYHeadRot(yaw);
        this.setXRot(0.0f);

        // 水平速度：离得远就快一点，靠近就收油
        double speed = Mth.clamp(dist * 0.06, 0.05, 0.62);
        double vx = dist > 0.05 ? dx / dist * speed : 0.0;
        double vz = dist > 0.05 ? dz / dist * speed : 0.0;
        double vy = Mth.clamp((ty - this.getY()) * 0.05, -0.22, 0.22);

        Vec3 step = new Vec3(vx, vy, vz);
        this.setDeltaMovement(step);
        this.move(MoverType.SELF, step);
        // 清空速度：下一 tick 交给本方法重新算，避免和原版各推一次
        this.setDeltaMovement(Vec3.ZERO);

        if (this.tickCount % 10 == 0) {
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 1.0, this.getZ(), 2, 0.6, 0.3, 0.6, 0.01);
        }
    }

    private void petCombat() {
        // 没目标就自己找：附近 40 格内的敌对生物
        if (this.getTarget() == null || !this.getTarget().isAlive()) {
            LivingEntity ownerEntity = this.ownerEntity();
            Vec3 around = ownerEntity != null ? ownerEntity.position() : this.position();
            var enemies = this.level().getEntitiesOfClass(LivingEntity.class,
                    new AABB(around, around).inflate(40.0),
                    e -> e instanceof Enemy && e != this && e.isAlive() && !(e instanceof HimDragonEntity));
            if (!enemies.isEmpty()) this.setTarget(enemies.get(0));
        } else if (this.attackCooldown <= 0) {
            LivingEntity target = this.getTarget();
            if (this.distanceToSqr(target) < 36.0) {
                target.hurt(this.damageSources().mobAttack(this), 28.0f);
                target.knockback(1.2, this.getX() - target.getX(), this.getZ() - target.getZ());
                target.hurtMarked = true;
                this.attackCooldown = 20;
                this.level().playSound(null, this.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP,
                        SoundSource.HOSTILE, 1.6f, 0.8f);
            }
        }
    }

    private void recall() {
        if (!(this.level() instanceof ServerLevel level)) {
            this.discard();
            return;
        }
        level.sendParticles(ParticleTypes.PORTAL,
                this.getX(), this.getY() + 2.0, this.getZ(), 40, 2.0, 1.5, 2.0, 0.2);
        AABB box = this.getBoundingBox().inflate(48.0);
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, box)) {
            player.sendSystemMessage(Component.translatable("message.wujia_village.him.recall"));
        }
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        // 谁打宠物，宠物咬回去（主人会被自己人劝住，不咬主人）
        if (!this.level().isClientSide() && source.getEntity() instanceof LivingEntity attacker
                && attacker != this && !(attacker instanceof HimVillagerEntity)) {
            this.setTarget(attacker);
        }
        return hurt;
    }

    @Override
    public void checkDespawn() {
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("HimAge", this.age);
        if (this.owner != null) tag.putUUID("HimOwner", this.owner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.age = Math.max(0, tag.getInt("HimAge"));
        this.owner = tag.hasUUID("HimOwner") ? tag.getUUID("HimOwner") : null;
        this.setDragonFight(null);
        this.keepHoverPhase();
    }
}
