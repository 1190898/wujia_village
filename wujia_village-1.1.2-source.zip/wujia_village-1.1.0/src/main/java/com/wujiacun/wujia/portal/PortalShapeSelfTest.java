package com.wujiacun.wujia.portal;

import com.wujiacun.wujia.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 无世界写入的传送门边界回归检查。 */
public final class PortalShapeSelfTest {
    private PortalShapeSelfTest() {}

    public static void run(List<String> failures) {
        for (Direction.Axis axis : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
            for (int size : new int[]{2, 21}) {
                TestBlocks blocks = frame(axis, size, size == 2 ? 3 : 21);
                var found = WujiaPortalShape.detect(blocks, new BlockPos(0, 65, 0), axis);
                check(failures, axis + " valid frame " + size, found.isPresent()
                        && found.get().width == size && found.get().height == (size == 2 ? 3 : 21));
            }
            TestBlocks openTop = frame(axis, 2, 3);
            openTop.states.remove(offset(axis, 0, 68));
            check(failures, axis + " missing top rejected", WujiaPortalShape.detect(openTop,
                    new BlockPos(0, 65, 0), axis).isEmpty());
            check(failures, axis + " missing top bounded", openTop.reads < 200);

            TestBlocks openSide = frame(axis, 2, 3);
            openSide.states.remove(offset(axis, -1, 65));
            check(failures, axis + " missing side bounded", WujiaPortalShape.detect(openSide,
                    new BlockPos(0, 65, 0), axis).isEmpty() && openSide.reads < 200);
            check(failures, axis + " oversized frame rejected", WujiaPortalShape.detect(frame(axis, 22, 3),
                    new BlockPos(0, 65, 0), axis).isEmpty());

            TestBlocks obstruction = frame(axis, 2, 3);
            obstruction.states.put(offset(axis, 1, 66), Blocks.STONE.defaultBlockState());
            check(failures, axis + " blocked interior rejected", WujiaPortalShape.detect(obstruction,
                    new BlockPos(0, 65, 0), axis).isEmpty());
        }
        TestBlocks air = new TestBlocks();
        check(failures, "open world scan bounded", WujiaPortalShape.detect(air,
                new BlockPos(0, 65, 0), Direction.Axis.X).isEmpty() && air.reads <= 24);
        check(failures, "vertical axis rejected", WujiaPortalShape.detect(air,
                new BlockPos(0, 65, 0), Direction.Axis.Y).isEmpty());
        check(failures, "outside build height rejected", WujiaPortalShape.detect(air,
                new BlockPos(0, 256, 0), Direction.Axis.X).isEmpty());
    }

    private static TestBlocks frame(Direction.Axis axis, int width, int height) {
        TestBlocks blocks = new TestBlocks();
        for (int w = -1; w <= width; w++) {
            for (int y = 64; y <= 65 + height; y++) {
                if (w == -1 || w == width || y == 64 || y == 65 + height) {
                    blocks.states.put(offset(axis, w, y), ModBlocks.CLOUD_BLOCK.get().defaultBlockState());
                }
            }
        }
        return blocks;
    }

    private static BlockPos offset(Direction.Axis axis, int w, int y) {
        return axis == Direction.Axis.X ? new BlockPos(w, y, 0) : new BlockPos(0, y, w);
    }

    private static void check(List<String> failures, String name, boolean passed) {
        if (!passed) failures.add("portal " + name);
        com.wujiacun.wujia.WujiaVillageMod.LOGGER.info("[selftest] {} portal {}", passed ? "OK" : "FAIL", name);
    }

    private static final class TestBlocks implements BlockGetter {
        private final Map<BlockPos, BlockState> states = new HashMap<>();
        private int reads;

        @Override
        public BlockState getBlockState(BlockPos pos) {
            reads++;
            return states.getOrDefault(pos, Blocks.AIR.defaultBlockState());
        }

        @Override
        public BlockEntity getBlockEntity(BlockPos pos) { return null; }

        @Override
        public FluidState getFluidState(BlockPos pos) { return getBlockState(pos).getFluidState(); }

        @Override
        public int getHeight() { return 256; }

        @Override
        public int getMinBuildHeight() { return 0; }
    }
}
