package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 吴家飞帚：清晰键位
 * <ul>
 *   <li>W / S：沿视角前进 / 后退（含俯仰，抬头升、低头降）</li>
 *   <li>A / D：水平左右平移</li>
 *   <li>空格：额外上升</li>
 *   <li>疾跑：加速</li>
 *   <li>松手：悬停轻晃</li>
 *   <li>潜行：下车 + 缓降</li>
 * </ul>
 */
public class BroomEntity extends Entity {

    private static final double CRUISE = 0.72;
    private static final double SPRINT = 1.05;
    private static final double STRAFE = 0.55;
    private static final double JUMP_LIFT = 0.42;
    private static final int IDLE_LIFETIME = 80;

    private int idleTicks;

    public BroomEntity(EntityType<? extends BroomEntity> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity le ? le : null;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().isEmpty();
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.85;
    }

    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        this.fallDistance = 0.0f;

        LivingEntity pilot = this.getControllingPassenger();

        if (this.level().isClientSide()) {
            if (pilot instanceof Player player && player.isLocalPlayer()) {
                this.flyWithInput(player);
                player.fallDistance = 0.0f;
                this.positionRider(player);
            }
            this.spawnTrail();
            return;
        }

        if (!(pilot instanceof Player player)) {
            this.idleTicks++;
            double bob = Math.sin(this.tickCount * 0.18) * 0.008;
            this.setDeltaMovement(0.0, bob, 0.0);
            this.move(MoverType.SELF, this.getDeltaMovement());
            if (this.idleTicks > IDLE_LIFETIME) this.discard();
            return;
        }
        this.idleTicks = 0;

        if (player.isShiftKeyDown()) {
            player.stopRiding();
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 140, 0, true, false));
            this.discard();
            return;
        }

        // 服务端跟骑手朝向，方便别人看到扫帚头朝哪
        this.setYRot(player.getYRot());
        this.setXRot(player.getXRot() * 0.45f);
        player.fallDistance = 0.0f;
        this.positionRider(player);

        if (this.tickCount % 3 == 0 && this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 0.15, this.getZ(), 1, 0.15, 0.05, 0.15, 0.01);
        }
    }

    private void flyWithInput(Player player) {
        float yaw = player.getYRot();
        float pitch = player.getXRot();
        this.setYRot(yaw);
        this.setXRot(pitch * 0.45f);

        // 水平前向 / 右向
        float yawRad = yaw * ((float) Math.PI / 180.0f);
        Vec3 forward = new Vec3(-Mth.sin(yawRad), 0.0, Mth.cos(yawRad));
        Vec3 right = new Vec3(forward.z, 0.0, -forward.x);

        double fwd = player.zza;   // W=+1 S=-1
        double str = player.xxa;   // A=+1 D=-1 in MC? actually A=+1 left
        boolean jump = player instanceof net.minecraft.client.player.LocalPlayer lp && lp.input.jumping;
        boolean sprint = player.isSprinting();

        double speed = sprint ? SPRINT : CRUISE;
        Vec3 vel = Vec3.ZERO;

        if (Math.abs(fwd) > 0.01) {
            // 沿完整视线（含俯仰）飞：抬头升、低头降
            Vec3 look = player.getLookAngle();
            vel = vel.add(look.scale(fwd * speed));
        }
        if (Math.abs(str) > 0.01) {
            vel = vel.add(right.scale(str * STRAFE * (sprint ? 1.15 : 1.0)));
        }
        if (jump) {
            vel = vel.add(0.0, JUMP_LIFT, 0.0);
        }

        if (vel.lengthSqr() < 1.0E-5) {
            // 悬停：轻微浮动，不乱飘
            double bob = Math.sin(this.tickCount * 0.12) * 0.015;
            vel = new Vec3(0.0, bob, 0.0);
            this.setDeltaMovement(vel);
            this.move(MoverType.SELF, vel);
            return;
        }

        // 限速，避免叠加失控
        if (vel.length() > SPRINT * 1.15) {
            vel = vel.normalize().scale(SPRINT * 1.15);
        }

        // 轻阻尼，手感干脆
        Vec3 blended = this.getDeltaMovement().scale(0.22).add(vel.scale(0.78));
        this.setDeltaMovement(blended);
        this.move(MoverType.SELF, blended);
    }

    private void spawnTrail() {
        if (this.tickCount % 2 != 0) return;
        double yaw = Math.toRadians(this.getYRot());
        // 扫帚毛在身后（模型 +Z 经 180 旋转后对应当前朝向后方）
        this.level().addParticle(ParticleTypes.CLOUD,
                this.getX() + Math.sin(yaw) * 0.9,
                this.getY() + 0.12,
                this.getZ() - Math.cos(yaw) * 0.9,
                0.0, -0.01, 0.0);
        if (this.getDeltaMovement().lengthSqr() > 0.04) {
            this.level().addParticle(ParticleTypes.END_ROD,
                    this.getX(), this.getY() + 0.2, this.getZ(),
                    0.0, 0.02, 0.0);
        }
    }
}
