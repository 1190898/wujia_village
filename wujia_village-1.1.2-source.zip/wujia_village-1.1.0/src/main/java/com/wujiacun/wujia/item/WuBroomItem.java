package com.wujiacun.wujia.item;

import com.wujiacun.wujia.entity.BroomEntity;
import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 吴家飞帚：扫地村民用了三千年的那把扫把，被吴家高人点化之后能飞了。
 * 右键骑上去，视角朝哪就飞哪；松手悬停，潜行跳车。
 */
public class WuBroomItem extends Item {

    public WuBroomItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isPassenger()) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide()) {
            BroomEntity broom = ModEntities.BROOM.get().create(level);
            if (broom == null) return InteractionResultHolder.fail(stack);
            broom.moveTo(player.getX(), player.getY() + 0.2, player.getZ(), player.getYRot(), 0.0f);
            level.addFreshEntity(broom);
            player.startRiding(broom, true);
            broom.setYRot(player.getYRot());
            level.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP,
                    SoundSource.PLAYERS, 0.8f, 1.7f);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wu_broom.tooltip").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("item.wujia_village.wu_broom.tooltip2").withStyle(ChatFormatting.GRAY));
    }
}
