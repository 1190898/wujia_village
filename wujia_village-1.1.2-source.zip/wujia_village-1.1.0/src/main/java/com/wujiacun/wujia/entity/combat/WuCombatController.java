package com.wujiacun.wujia.entity.combat;

import com.wujiacun.wujia.entity.*;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.util.ModDamageTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

/** The sole owner of attack cadence, windup, contact, recovery and ground blink movement. */
public final class WuCombatController {
    private final WuVillagerBase mob;
    private CombatAction action = CombatAction.IDLE;
    private int age, duration, cooldown, rangedCooldown, blinkCooldown, combo, rangedCycle;
    private LivingEntity focus;
    private Vec3 fixedAim, blinkFrom, ambientDestination;
    private boolean released;
    private int releaseCount;

    public WuCombatController(WuVillagerBase mob) { this.mob = mob; }
    public boolean busy() { return action != CombatAction.IDLE; }
    public int getReleaseCount() { return releaseCount; }
    public int getServerActionAge() { return age; }
    public static int duration(CombatAction action) {
        return switch (action) {
            case MELEE_JAB -> 14; case MELEE_SWEEP -> 22; case MELEE_OVERHEAD -> 26;
            case MELEE_THRUST -> 18; case BLINK -> 14; case DODGE -> 10; case SONIC -> 28;
            case SWORDS -> 34; case PALM -> 40; case WATER -> 24; case HIM_FLIGHT -> 36;
            case BLACK_HOLE -> 48;
            default -> 0;
        };
    }

    public void tick() {
        if (!(mob.level() instanceof ServerLevel)) return;
        if (cooldown > 0) cooldown--;
        if (rangedCooldown > 0) rangedCooldown--;
        if (blinkCooldown > 0) blinkCooldown--;
        if (mob instanceof HimVillagerEntity him && him.isFlyingAway()) {
            if (action != CombatAction.HIM_FLIGHT) interruptForFlight();
            return; // Never stop flight velocity/navigation from the ground controller.
        }
        if (action == CombatAction.HIM_FLIGHT) finish();
        LivingEntity target = mob.getTarget();
        if (target != null && !WuCombatRules.canHit(mob, target)) { mob.setTarget(null); target = null; }
        if (busy()) {
            if (action == CombatAction.DODGE) {
                tickDodgeMotion();
            } else {
                holdStill();
            }
            age++;
            if (focus != null && focus.isAlive()) mob.getLookControl().setLookAt(focus, 30, 30);
            int contact = action == CombatAction.BLINK ? 6 : action == CombatAction.DODGE ? 3 : action == CombatAction.SONIC ? 12 : CombatAction.contactTick(duration);
            if (!released && age >= contact) {
                released = true;
                releaseCount++;
                release();
            }
            if (age >= duration) finish();
            return;
        }
        if (cooldown > 0) return;
        if (target != null) {
            ambientDestination = null;
            double distance = mob.distanceTo(target);
            mob.getLookControl().setLookAt(target, 30, 30);
            if (distance < meleeReach(CombatAction.MELEE_THRUST) && mob.hasLineOfSight(target)) {
                requestMelee(target);
            } else if (distance <= rangedReach() && rangedCooldown == 0 && mob.hasLineOfSight(target)) {
                requestRanged(target);
            } else if (distance > 3.0) {
                if (mob instanceof TeleportVillagerEntity && blinkCooldown == 0 && mob.getRandom().nextFloat() < 0.25f) {
                    Vec3 toward = target.position().subtract(mob.position());
                    Vec3 step = mob.position().add(new Vec3(toward.x, 0, toward.z).normalize().scale(Math.min(6.0, distance - 2.0)));
                    if (requestBlink(step)) return;
                }
                mob.getNavigation().moveTo(target, 0.35);
            } else {
                mob.getNavigation().moveTo(target, 0.35);
            }
        }
    }

    private double rangedReach() { return mob instanceof DodgeVillagerEntity ? 9 : mob instanceof FisherVillagerEntity ? 18 : 26; }
    private double meleeReach(CombatAction move) {
        return mob.getBbWidth() * 0.5 + (move == CombatAction.MELEE_THRUST ? 3.0 : 2.25);
    }
    private void begin(CombatAction next, LivingEntity target, Vec3 aim) {
        action = next; age = 0; duration = duration(next); focus = target; fixedAim = aim; released = false;
        mob.syncCombatAction(next, duration);
        holdStill();
        if (next.ordinal() >= CombatAction.MELEE_JAB.ordinal() && next.ordinal() <= CombatAction.MELEE_THRUST.ordinal())
            mob.swing(InteractionHand.MAIN_HAND);
    }
    public boolean requestMelee(LivingEntity target) {
        if (mob.level().isClientSide() || busy() || cooldown > 0 || !WuCombatRules.canHit(mob, target)) return false;
        CombatAction next;
        if (mob instanceof AncestorVillagerEntity && combo % 3 == 2) {
            next = CombatAction.BLACK_HOLE;
        } else if (mob instanceof SweeperVillagerEntity && combo % 2 == 0) {
            next = CombatAction.MELEE_SWEEP;
        } else {
            next = CombatAction.values()[1 + combo % 4];
        }
        combo++;
        begin(next, target, target.getEyePosition());
        return true;
    }
    public boolean requestRanged(LivingEntity target) {
        if (mob.level().isClientSide() || busy() || cooldown > 0 || rangedCooldown > 0
                || !WuCombatRules.canHit(mob, target) || mob.distanceTo(target) > rangedReach() || !mob.hasLineOfSight(target)) return false;
        CombatAction next;
        if (mob instanceof TeleportVillagerEntity || mob instanceof GuardVillagerEntity) next = CombatAction.SWORDS;
        else if (mob instanceof FisherVillagerEntity) next = CombatAction.WATER;
        else if (mob instanceof ChiefVillagerEntity) next = rangedCycle % 2 == 0 ? CombatAction.SONIC : CombatAction.PALM;
        else if (mob instanceof AncestorVillagerEntity) next = switch (rangedCycle % 3) {
            case 0 -> CombatAction.SWORDS;
            case 1 -> CombatAction.PALM;
            default -> CombatAction.BLACK_HOLE;
        };
        else next = CombatAction.SONIC;
        rangedCycle++;
        begin(next, target, target.position()); // PALM never follows the target after warning starts.
        rangedCooldown = 65;
        return true;
    }
    public boolean requestBlink(Vec3 to) {
        if (mob.level().isClientSide() || busy() || blinkCooldown > 0
                || mob instanceof HimVillagerEntity him && him.isFlyingAway() || !WuCombatRules.safeBlink(mob, to)) return false;
        blinkFrom = mob.position();
        begin(CombatAction.BLINK, null, to);
        blinkCooldown = 26;
        return true;
    }
    public boolean requestDodge(Vec3 to) {
        if (mob.level().isClientSide() || busy() || blinkCooldown > 0
                || mob instanceof HimVillagerEntity him && him.isFlyingAway() || !WuCombatRules.safeBlink(mob, to)) return false;
        blinkFrom = mob.position();
        begin(CombatAction.DODGE, null, to);
        blinkCooldown = 16;
        if (mob.level() instanceof ServerLevel level) {
            level.playSound(null, mob.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.NEUTRAL, 0.9f, 1.4f);
        }
        return true;
    }
    private void tickDodgeMotion() {
        if (fixedAim == null) return;
        Vec3 diff = fixedAim.subtract(mob.position());
        double horizontalDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        if (horizontalDist > 0.1 && age <= 6) {
            Vec3 dir = new Vec3(diff.x, 0, diff.z).normalize();
            double speed = Math.min(horizontalDist, 0.65);
            mob.setDeltaMovement(dir.x * speed, mob.getDeltaMovement().y, dir.z * speed);
            mob.hasImpulse = true;
            if (mob.level() instanceof ServerLevel level && age % 2 == 0) {
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.SWEEP_ATTACK, mob.getX(), mob.getY() + 0.4, mob.getZ(), 1, 0, 0, 0, 0);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.CLOUD, mob.getX(), mob.getY() + 0.05, mob.getZ(), 2, 0.15, 0.05, 0.15, 0.01);
            }
        } else if (age > 6) {
            mob.setDeltaMovement(mob.getDeltaMovement().multiply(0.4, 1.0, 0.4));
        }
    }
    private void holdStill() {
        mob.getNavigation().stop();
        mob.getMoveControl().setWantedPosition(mob.getX(), mob.getY(), mob.getZ(), 0);
        mob.setSpeed(0);
        mob.setJumping(false);
        mob.setDeltaMovement(Vec3.ZERO);
    }
    public void interruptForFlight() {
        action = CombatAction.HIM_FLIGHT; age = 0; duration = 36; focus = null; fixedAim = null; released = true;
        mob.getNavigation().stop();
        mob.syncCombatAction(action, duration);
    }
    public void finishFlight() { if (action == CombatAction.HIM_FLIGHT) finish(); }
    private void finish() {
        if (action == CombatAction.DODGE && fixedAim != null) {
            mob.setDeltaMovement(Vec3.ZERO);
            if (mob.position().distanceToSqr(fixedAim) < 1.0) {
                mob.setPos(fixedAim.x, mob.getY(), fixedAim.z);
            }
        }
        action = CombatAction.IDLE; age = 0; focus = null; fixedAim = null;
        cooldown = 6;
        mob.syncCombatAction(CombatAction.IDLE, 0);
    }
    private void release() {
        if (!(mob.level() instanceof ServerLevel level)) return;
        if (action == CombatAction.DODGE) {
            spawnGhost(level);
            return;
        }
        if (action == CombatAction.BLINK) {
            if (mob.position().distanceToSqr(blinkFrom) > 0.25 || !WuCombatRules.safeBlink(mob, fixedAim)) return;
            spawnGhost(level);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL, mob.getX(), mob.getY() + 0.5, mob.getZ(), 24, 0.4, 0.8, 0.4, 0.15);
            mob.teleportTo(fixedAim.x, fixedAim.y, fixedAim.z);
            mob.getNavigation().stop(); mob.setDeltaMovement(Vec3.ZERO); mob.fallDistance = 0;
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL, mob.getX(), mob.getY() + 0.5, mob.getZ(), 24, 0.4, 0.8, 0.4, 0.15);
            level.playSound(null, mob.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.NEUTRAL, 0.85f, 1.0f);
            return;
        }
        if (focus == null || !WuCombatRules.canHit(mob, focus)) return;
        if (action.ordinal() >= 1 && action.ordinal() <= 4) { melee(level); return; }
        if (action == CombatAction.PALM) {
            WuSkillEffectEntity.spawnPalm(level, mob, fixedAim, mob.getSkillTint(), skillDamage(1.1f));
        } else if (action == CombatAction.BLACK_HOLE) {
            WuSkillEffectEntity.spawnBlackHole(level, mob, fixedAim != null ? fixedAim : focus.position(), mob.getSkillTint(), skillDamage(2.5f));
        } else if (action == CombatAction.SWORDS) {
            int count = mob instanceof GuardVillagerEntity ? 3 : mob instanceof AncestorVillagerEntity ? 7 : 5;
            for (int i = 0; i < count; i++) WuSwordEntity.summon(level, mob, focus, i, count, mob.getSkillTint(), skillDamage(0.38f));
        } else {
            Vec3 origin = mob.getEyePosition().add(0, -0.15, 0);
            Vec3 direction = focus.getEyePosition().subtract(origin).normalize();
            Vec3 end = origin.add(direction.scale(rangedReach()));
            WuSkillEffectEntity.castLine(level, mob, origin, end, action == CombatAction.WATER ? WuSkillEffectEntity.WATER : WuSkillEffectEntity.SONIC,
                    mob.getSkillTint(), skillDamage(action == CombatAction.WATER ? 0.55f : 0.7f));
        }
    }
    private float skillDamage(float factor) { return Math.max(4, (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE) * factor); }
    private void melee(ServerLevel level) {
        double reach = meleeReach(action);
        Vec3 front = focus.position().subtract(mob.position()).multiply(1, 0, 1).normalize();
        boolean sweep = action == CombatAction.MELEE_SWEEP;
        for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(reach, 1, reach),
                e -> WuCombatRules.canHit(mob, e))) {
            if (!sweep && victim != focus || mob.distanceTo(victim) > reach || !mob.hasLineOfSight(victim)) continue;
            Vec3 toward = victim.position().subtract(mob.position()).multiply(1, 0, 1).normalize();
            if (sweep && front.dot(toward) < -0.15) continue;
            float factor = action == CombatAction.MELEE_OVERHEAD ? 1.15f : sweep ? 0.75f : 1;
            if (victim.hurt(ModDamageTypes.wuStrike(level, mob), skillDamage(factor))) {
                victim.knockback(sweep ? 0.8 : 0.35, mob.getX() - victim.getX(), mob.getZ() - victim.getZ());
                victim.hurtMarked = true;
            }
        }
        level.playSound(null, mob.blockPosition(), sweep ? SoundEvents.PLAYER_ATTACK_SWEEP : SoundEvents.PLAYER_ATTACK_STRONG,
                SoundSource.NEUTRAL, 0.8f, 1);
    }
    private void spawnGhost(ServerLevel level) {
        GhostVillagerEntity ghost = ModEntities.GHOST_VILLAGER.get().create(level);
        if (ghost != null) {
            ghost.capture(mob);
            level.addFreshEntity(ghost);
        }
    }
}
