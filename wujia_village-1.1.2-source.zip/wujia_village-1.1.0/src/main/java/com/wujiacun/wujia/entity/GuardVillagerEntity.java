package com.wujiacun.wujia.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * 吴家村保安：村口那位"什么都管"的大爷。
 * 白天在村里来回巡逻，谁在村里闹事（敌对生物）就上去一顿电棍；地上掉的破烂也顺手收走。
 */
public class GuardVillagerEntity extends WuVillagerBase {

    private BlockPos patrolCenter;

    public GuardVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.guard_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.guard";
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        if (this.patrolCenter == null) this.patrolCenter = this.blockPosition();
        if (this.tickCount == 1 && this.getMainHandItem().isEmpty()) {
            ItemStack baton = new ItemStack(Items.IRON_SWORD);
            baton.setHoverName(net.minecraft.network.chat.Component.translatable("item.wujia_village.baton"));
            this.setItemSlot(EquipmentSlot.MAINHAND, baton);
            this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
        }
        if (this.level() instanceof ServerLevel sl && this.tickCount % 200 == 0) {
            sl.sendParticles(ParticleTypes.ENCHANT,
                    this.getX(), this.getY() + 2.2, this.getZ(), 4, 0.4, 0.4, 0.4, 0.4);
        }
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(4, new PatrolGoal(this));
        this.goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal(this, 0.7));
    }

    /** 巡逻：在村子中心附近来回走，顺便把地上的垃圾收起来。 */
    static class PatrolGoal extends Goal {
        private final GuardVillagerEntity guard;
        private int cooldown;
        private Vec3 waypoint;

        PatrolGoal(GuardVillagerEntity guard) {
            this.guard = guard;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.guard.getTarget() != null) return false;
            if (this.guard.level().getNearestPlayer(this.guard, 24.0) == null) return false;
            return --this.cooldown <= 0;
        }

        @Override
        public void start() {
            BlockPos center = this.guard.patrolCenter != null ? this.guard.patrolCenter : this.guard.blockPosition();
            double angle = this.guard.random.nextDouble() * Math.PI * 2.0;
            double radius = 6.0 + this.guard.random.nextDouble() * 10.0;
            this.waypoint = new Vec3(center.getX() + Math.cos(angle) * radius + 0.5,
                    center.getY(), center.getZ() + Math.sin(angle) * radius + 0.5);
            this.guard.getNavigation().moveTo(this.waypoint.x, this.waypoint.y, this.waypoint.z, 0.9);
            this.cooldown = 60 + this.guard.random.nextInt(80);
        }

        @Override
        public void stop() {
            this.guard.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (this.guard.tickCount % 40 != 0) return;
            // 顺手把地上的垃圾收进兜里（也就是直接消灭，村子要保持干净）
            for (ItemEntity item : this.guard.level().getEntitiesOfClass(ItemEntity.class,
                    new AABB(this.guard.blockPosition()).inflate(4.0))) {
                if (item.getItem().is(Items.IRON_SWORD)) continue;
                item.discard();
            }
        }
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (!this.level().isClientSide() && source.getEntity() instanceof LivingEntity attacker
                && !(attacker instanceof WuVillagerBase) && !(attacker instanceof Player)) {
            this.setTarget(attacker);
            if (this.level() instanceof ServerLevel sl) {
                sl.playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 0.8f, 1.6f);
            }
        }
        return hurt;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.patrolCenter != null) tag.putLong("PatrolCenter", this.patrolCenter.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("PatrolCenter")) this.patrolCenter = BlockPos.of(tag.getLong("PatrolCenter"));
    }

    /** 保安不需要 Enemy 判断以外的东西 */
    public static boolean isTrouble(LivingEntity e) {
        return e instanceof Enemy && !(e instanceof HimDragonEntity);
    }
}
