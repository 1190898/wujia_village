package com.wujiacun.wujia.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.LazyLoadedValue;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 吴家神甲：村口石碑都是大道本源浇的，何况这套盔甲。
 * 无限耐久，护甲值高得离谱。
 */
public class WuArmorItem extends ArmorItem {

    public WuArmorItem(Type type) {
        super(WuArmorMaterial.INSTANCE, type, new Properties().fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public boolean canBeDepleted() {
        return false; // 无限耐久
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wu_armor.tooltip").withStyle(ChatFormatting.AQUA));
    }

    /** 吴家神甲材质 */
    public static class WuArmorMaterial implements ArmorMaterial {
        public static final WuArmorMaterial INSTANCE = new WuArmorMaterial();

        @Override
        public int getDurabilityForType(Type type) {
            return 4096; // 反正也磨不坏
        }

        @Override
        public int getDefenseForType(Type type) {
            return switch (type) {
                case BOOTS -> 20;
                case LEGGINGS -> 30;
                case CHESTPLATE -> 40;
                case HELMET -> 20;
                default -> 10;
            };
        }

        @Override
        public int getEnchantmentValue() {
            return 30;
        }

        @Override
        public net.minecraft.sounds.SoundEvent getEquipSound() {
            return SoundEvents.ARMOR_EQUIP_NETHERITE;
        }

        @Override
        public net.minecraft.world.item.crafting.Ingredient getRepairIngredient() {
            return net.minecraft.world.item.crafting.Ingredient.of();
        }

        @Override
        public String getName() {
            return "wujia_village:wu";
        }

        @Override
        public float getToughness() {
            return 10.0f;
        }

        @Override
        public float getKnockbackResistance() {
            return 0.25f;
        }
    }
}
