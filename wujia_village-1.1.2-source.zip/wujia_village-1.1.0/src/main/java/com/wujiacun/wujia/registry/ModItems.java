package com.wujiacun.wujia.registry;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.item.*;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, WujiaVillageMod.MODID);

    public static final RegistryObject<Item> CLOUD_BLOCK =
            ITEMS.register("cloud_block", () -> new BlockItem(ModBlocks.CLOUD_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> WUJIA_STELE =
            ITEMS.register("wujia_stele", () -> new BlockItem(ModBlocks.WUJIA_STELE.get(), new Item.Properties()));
    public static final RegistryObject<Item> WUJIA_STONE =
            ITEMS.register("wujia_stone", () -> new BlockItem(ModBlocks.WUJIA_STONE.get(), new Item.Properties()));
    public static final RegistryObject<Item> WUJIA_AIR =
            ITEMS.register("wujia_air", () -> new BlockItem(ModBlocks.WUJIA_AIR.get(), new Item.Properties()));
    public static final RegistryObject<Item> WU_BROOM =
            ITEMS.register("wu_broom", WuBroomItem::new);
    public static final RegistryObject<Item> WU_CABBAGE =
            ITEMS.register("wu_cabbage", WuCabbageItem::new);

    public static final RegistryObject<Item> WU_CELL =
            ITEMS.register("wu_cell", WuCellItem::new);

    public static final RegistryObject<Item> WU_SWORD =
            ITEMS.register("wu_sword", WuSwordItem::new);

    public static final RegistryObject<Item> WU_HELMET =
            ITEMS.register("wu_helmet", () -> new WuArmorItem(net.minecraft.world.item.ArmorItem.Type.HELMET));
    public static final RegistryObject<Item> WU_CHESTPLATE =
            ITEMS.register("wu_chestplate", () -> new WuArmorItem(net.minecraft.world.item.ArmorItem.Type.CHESTPLATE));
    public static final RegistryObject<Item> WU_LEGGINGS =
            ITEMS.register("wu_leggings", () -> new WuArmorItem(net.minecraft.world.item.ArmorItem.Type.LEGGINGS));
    public static final RegistryObject<Item> WU_BOOTS =
            ITEMS.register("wu_boots", () -> new WuArmorItem(net.minecraft.world.item.ArmorItem.Type.BOOTS));

    public static final RegistryObject<Item> WU_ELIXIR =
            ITEMS.register("wu_elixir", WuElixirItem::new);

    public static final RegistryObject<Item> WILD_DOG_MILK =
            ITEMS.register("wild_dog_milk", WildDogMilkItem::new);

    public static final RegistryObject<Item> DODGE_VILLAGER_EGG =
            ITEMS.register("dodge_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.DODGE_VILLAGER, 0x7FE8D0, 0x2A6E5F, new Item.Properties()));
    public static final RegistryObject<Item> TELEPORT_VILLAGER_EGG =
            ITEMS.register("teleport_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.TELEPORT_VILLAGER, 0x8AA8FF, 0x3346B8, new Item.Properties()));
    public static final RegistryObject<Item> CHIEF_VILLAGER_EGG =
            ITEMS.register("chief_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.CHIEF_VILLAGER, 0xFFD34D, 0x8A6A10, new Item.Properties()));
    public static final RegistryObject<Item> ANCESTOR_VILLAGER_EGG =
            ITEMS.register("ancestor_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.ANCESTOR_VILLAGER, 0xFFF6D8, 0xC2A24E, new Item.Properties()));
    public static final RegistryObject<Item> SWEEPER_VILLAGER_EGG =
            ITEMS.register("sweeper_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SWEEPER_VILLAGER, 0xB0B0B8, 0x606068, new Item.Properties()));
    public static final RegistryObject<Item> GUARD_VILLAGER_EGG =
            ITEMS.register("guard_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.GUARD_VILLAGER, 0x2C3C57, 0xD8C070, new Item.Properties()));
    public static final RegistryObject<Item> FISHER_VILLAGER_EGG =
            ITEMS.register("fisher_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.FISHER_VILLAGER, 0x3A6EA5, 0xE8F2FF, new Item.Properties()));
    public static final RegistryObject<Item> WU_CHICKEN_EGG =
            ITEMS.register("wu_chicken_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.WU_CHICKEN, 0xE8D27A, 0xC45A2A, new Item.Properties()));
    public static final RegistryObject<Item> WU_DOG_EGG =
            ITEMS.register("wu_dog_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.WU_DOG, 0xC4A574, 0x6B4A2A, new Item.Properties()));
    public static final RegistryObject<Item> HIM_VILLAGER_EGG =
            ITEMS.register("him_villager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HIM_VILLAGER, 0xF7F7F7, 0x202228, new Item.Properties()));
    public static final RegistryObject<Item> HIM_DRAGON_EGG =
            ITEMS.register("him_dragon_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HIM_DRAGON, 0x1A1028, 0xE070E0, new Item.Properties()));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
