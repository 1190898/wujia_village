package com.wujiacun.wujia.block;

import com.wujiacun.wujia.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 吴家空气：村子里的空气都是吴家的。
 * 站进去会短暂飞起来（真的能飞，不是飘），另外还有一堆正面效果。
 */
public class WujiaAirBlock extends Block {

    public static final String UNTIL = "wujia_air_until";
    public static final String GRANTED = "wujia_air_granted";
    /** 每次吸入给多少 tick 的飞行 */
    public static final int FLIGHT_TICKS = 240;

    public WujiaAirBlock() {
        super(Properties.of()
                .noCollission()
                .noOcclusion()
                .instabreak()
                .lightLevel(state -> 4)
                .sound(SoundType.WOOL)
                .noLootTable());
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!(level instanceof ServerLevel sl)) return;
        if (!(entity instanceof ServerPlayer player)) return;

        long now = level.getGameTime();
        long until = player.getPersistentData().getLong(UNTIL);
        boolean fresh = until < now;
        if (fresh) {
            if (!player.getAbilities().mayfly) {
                player.getAbilities().mayfly = true;
                player.getPersistentData().putBoolean(GRANTED, true);
            }
            player.onUpdateAbilities();
            player.displayClientMessage(Component.translatable("message.wujia_village.air.breath"), true);
            sl.playSound(null, player.blockPosition(), SoundEvents.PLAYER_BREATH, SoundSource.PLAYERS, 0.7f, 1.6f);
        }
        player.getPersistentData().putLong(UNTIL, now + FLIGHT_TICKS);

        // 正面效果：回血、减伤、迅捷、缓降、抗火
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1, true, false));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 1, true, false));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 1, true, false));
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, true, false));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 160, 0, true, false));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 160, 1, true, false));

        if (now % 10 == 0) {
            sl.sendParticles(ParticleTypes.CLOUD,
                    player.getX(), player.getY() + 0.4, player.getZ(), 4, 0.3, 0.2, 0.3, 0.03);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(6) != 0) return;
        level.addParticle(ParticleTypes.CLOUD,
                pos.getX() + random.nextDouble(),
                pos.getY() + random.nextDouble(),
                pos.getZ() + random.nextDouble(),
                0.0, 0.01, 0.0);
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModItems.WUJIA_AIR.get());
    }
}
