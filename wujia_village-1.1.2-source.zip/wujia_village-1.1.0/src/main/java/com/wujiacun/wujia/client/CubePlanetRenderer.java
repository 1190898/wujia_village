package com.wujiacun.wujia.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.world.CubePlanetSchedule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * 天空里一颗很远的赤壤方星。地表是锈红色坑地、一条峡谷、一顶浅色极冠，
 * 还有一面不像火星的青色干湖——它是编出来的，只是借了火星那种干土和陨坑。
 * 贴图六面从上到下：+X 峡谷、-X 陨坑、+Y 极冠、-Y 暗岩、+Z 干湖、-Z 沙垄。
 */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, value = Dist.CLIENT)
public final class CubePlanetRenderer {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(WujiaVillageMod.MODID, "textures/environment/cube_planet.png");
    private static final float HALF = 11.0f;

    private CubePlanetRenderer() {}

    @SubscribeEvent
    public static void onSky(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !mc.level.dimension().equals(WujiaVillageMod.WUJIA_DIM)) return;

        long time = mc.level.getGameTime();
        float alpha = CubePlanetSchedule.alpha(time);
        if (alpha <= 0.01f) return;

        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        // 跟太阳同一套天空坐标，再偏开一截，免得叠在日头上。
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(-20.0f));
        pose.mulPose(com.mojang.math.Axis.XP.rotationDegrees(-28.0f));
        pose.translate(0.0f, 130.0f, 0.0f);
        float spin = (time + event.getPartialTick()) * 0.35f;
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(spin));
        pose.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(16.0f));

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShaderFogStart(800.0f);
        RenderSystem.setShaderFogEnd(1600.0f);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

        float gap = CubePlanetSchedule.separation(time);
        if (CubePlanetSchedule.phase(time) == CubePlanetSchedule.Phase.INTACT && gap == 0.0f) {
            drawShell(pose, 1.12f);
            drawSolid(pose.last().pose(), HALF, 255);
        } else {
            drawPieces(pose.last().pose(), gap, alpha);
        }

        RenderSystem.setShaderFogStart(fogStart);
        RenderSystem.setShaderFogEnd(fogEnd);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        pose.popPose();
    }

    private static void drawShell(PoseStack pose, float scale) {
        pose.pushPose();
        pose.scale(scale, scale, scale);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f mat = pose.last().pose();
        int argb = 0x30E07030;
        float h = HALF;
        solidColorCube(buf, mat, h, argb);
        com.mojang.blaze3d.vertex.BufferUploader.drawWithShader(buf.end());
        pose.popPose();
    }

    private static void drawSolid(Matrix4f mat, float half, int alpha) {
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, TEXTURE);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        texturedCube(buf, mat, 0, 0, 0, half, 0.0f, alpha, false);
        com.mojang.blaze3d.vertex.BufferUploader.drawWithShader(buf.end());
    }

    private static void drawPieces(Matrix4f mat, float gap, float alpha) {
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, TEXTURE);
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        int[] signs = {-1, 1};
        for (int sx : signs) {
            for (int sy : signs) {
                for (int sz : signs) {
                    texturedCube(buf, mat, sx, sy, sz, HALF, gap, a, true);
                }
            }
        }
        com.mojang.blaze3d.vertex.BufferUploader.drawWithShader(buf.end());
    }

    private static void solidColorCube(BufferBuilder buf, Matrix4f mat, float h, int argb) {
        int r = (argb >> 16) & 255;
        int g = (argb >> 8) & 255;
        int b = argb & 255;
        int a = (argb >> 24) & 255;
        faceColor(buf, mat, -h, -h, h, h, -h, h, h, h, h, -h, h, h, r, g, b, a);
        faceColor(buf, mat, -h, -h, -h, -h, h, -h, h, h, -h, h, -h, -h, r, g, b, a);
        faceColor(buf, mat, -h, h, -h, -h, h, h, h, h, h, h, h, -h, r, g, b, a);
        faceColor(buf, mat, -h, -h, -h, h, -h, -h, h, -h, h, -h, -h, h, r, g, b, a);
        faceColor(buf, mat, h, -h, -h, h, h, -h, h, h, h, h, -h, h, r, g, b, a);
        faceColor(buf, mat, -h, -h, -h, -h, -h, h, -h, h, h, -h, h, -h, r, g, b, a);
    }

    /** sx/sy/sz 为 0 时画整颗星；为 ±1 时画对应的八分之一，并沿该方向推开。 */
    private static void texturedCube(BufferBuilder buf, Matrix4f mat, int sx, int sy, int sz,
                                      float half, float gap, int alpha, boolean octant) {
        float x0;
        float x1;
        float y0;
        float y1;
        float z0;
        float z1;
        if (!octant) {
            x0 = y0 = z0 = -half;
            x1 = y1 = z1 = half;
        } else {
            x0 = sx < 0 ? -half : 0.0f;
            x1 = sx < 0 ? 0.0f : half;
            y0 = sy < 0 ? -half : 0.0f;
            y1 = sy < 0 ? 0.0f : half;
            z0 = sz < 0 ? -half : 0.0f;
            z1 = sz < 0 ? 0.0f : half;
            float push = gap;
            x0 += sx * push;
            x1 += sx * push;
            y0 += sy * push;
            y1 += sy * push;
            z0 += sz * push;
            z1 += sz * push;
        }
        // 外侧面用原色，裂开后朝向球心的面压暗，露出断面。
        face(buf, mat, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 4, u0(sz, octant), u1(sz, octant), v0(sy, octant), v1(sy, octant), alpha, faceShade(octant, sz, 1));
        face(buf, mat, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, 5, u0(sz, octant), u1(sz, octant), v0(sy, octant), v1(sy, octant), alpha, faceShade(octant, sz, -1));
        face(buf, mat, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 2, u0(sx, octant), u1(sx, octant), v0(sz, octant), v1(sz, octant), alpha, faceShade(octant, sy, 1));
        face(buf, mat, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 3, u0(sx, octant), u1(sx, octant), v0(sz, octant), v1(sz, octant), alpha, faceShade(octant, sy, -1));
        face(buf, mat, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 0, u0(sz, octant), u1(sz, octant), v0(sy, octant), v1(sy, octant), alpha, faceShade(octant, sx, 1));
        face(buf, mat, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, 1, u0(sz, octant), u1(sz, octant), v0(sy, octant), v1(sy, octant), alpha, faceShade(octant, sx, -1));
    }

    private static float u0(int sign, boolean octant) {
        if (!octant) return 0.0f;
        return sign < 0 ? 0.0f : 0.5f;
    }

    private static float u1(int sign, boolean octant) {
        if (!octant) return 1.0f;
        return sign < 0 ? 0.5f : 1.0f;
    }

    private static float v0(int sign, boolean octant) {
        if (!octant) return 0.0f;
        return sign > 0 ? 0.0f : 0.5f;
    }

    private static float v1(int sign, boolean octant) {
        if (!octant) return 1.0f;
        return sign > 0 ? 0.5f : 1.0f;
    }

    private static float faceShade(boolean octant, int sign, int normalSign) {
        if (!octant) return 1.0f;
        return sign == normalSign ? 1.0f : 0.42f;
    }

    private static void face(BufferBuilder buf, Matrix4f mat,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float x4, float y4, float z4,
                             int faceIndex, float u0, float u1, float v0, float v1,
                             int alpha, float shade) {
        float band = faceIndex / 6.0f;
        float vA = band + v0 / 6.0f;
        float vB = band + v1 / 6.0f;
        int c = Math.max(0, Math.min(255, Math.round(255 * shade)));
        vertex(buf, mat, x1, y1, z1, u0, vB, c, c, c, alpha);
        vertex(buf, mat, x2, y2, z2, u1, vB, c, c, c, alpha);
        vertex(buf, mat, x3, y3, z3, u1, vA, c, c, c, alpha);
        vertex(buf, mat, x4, y4, z4, u0, vA, c, c, c, alpha);
    }

    private static void faceColor(BufferBuilder buf, Matrix4f mat,
                                  float x1, float y1, float z1,
                                  float x2, float y2, float z2,
                                  float x3, float y3, float z3,
                                  float x4, float y4, float z4,
                                  int r, int g, int b, int a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).endVertex();
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).endVertex();
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a).endVertex();
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a).endVertex();
    }

    private static void vertex(BufferBuilder buf, Matrix4f mat, float x, float y, float z,
                               float u, float v, int r, int g, int b, int a) {
        buf.vertex(mat, x, y, z).uv(u, v).color(r, g, b, a).endVertex();
    }
}
