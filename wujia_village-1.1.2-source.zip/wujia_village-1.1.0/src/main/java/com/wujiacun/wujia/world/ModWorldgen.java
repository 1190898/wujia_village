package com.wujiacun.wujia.world;

import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import com.mojang.serialization.Codec;

public final class ModWorldgen {
    public static final DeferredRegister<Codec<? extends ChunkGenerator>> GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, WujiaVillageMod.MODID);

    public static final RegistryObject<Codec<? extends ChunkGenerator>> VILLAGE =
            GENERATORS.register("village", () -> WujiaChunkGenerator.CODEC);

    private ModWorldgen() {}

    public static void register(IEventBus bus) {
        GENERATORS.register(bus);
    }
}
