package com.wujiacun.wujia.world;

/**
 * 赤壤方星的公开时间表。客户端碎裂动画和服务端尘埃都读这里，
 * 这样每个人看见的是同一颗正在裂开的方星。
 * <p>
 * 一个周期先让完整的方星停一会儿，再裂开、散成八块、淡出，然后换下一颗。
 */
public final class CubePlanetSchedule {
    public static final int CYCLE = 1200;
    public static final int CRACK_AT = 200;
    public static final int BREAK_AT = 280;
    public static final int GONE_AT = 700;

    public enum Phase {
        INTACT, CRACK, BREAK, GONE
    }

    private CubePlanetSchedule() {}

    public static Phase phase(long gameTime) {
        int t = mod(gameTime);
        if (t < CRACK_AT) return Phase.INTACT;
        if (t < BREAK_AT) return Phase.CRACK;
        if (t < GONE_AT) return Phase.BREAK;
        return Phase.GONE;
    }

    /** 碎块离开原位的距离。裂开前是 0，散开时变大。 */
    public static float separation(long gameTime) {
        int t = mod(gameTime);
        if (t < CRACK_AT || t >= GONE_AT) return 0.0f;
        if (t < BREAK_AT) {
            return (t - CRACK_AT) / (float) (BREAK_AT - CRACK_AT) * 1.6f;
        }
        float progress = (t - BREAK_AT) / (float) (GONE_AT - BREAK_AT);
        return 1.6f + progress * progress * 42.0f;
    }

    /** 碎块透明度。散开后半段逐渐消失。 */
    public static float alpha(long gameTime) {
        int t = mod(gameTime);
        if (t >= GONE_AT) return 0.0f;
        if (t < BREAK_AT) return 1.0f;
        float progress = (t - BREAK_AT) / (float) (GONE_AT - BREAK_AT);
        if (progress < 0.55f) return 1.0f;
        return Math.max(0.0f, 1.0f - (progress - 0.55f) / 0.45f);
    }

    public static int mod(long gameTime) {
        return (int) Math.floorMod(gameTime, CYCLE);
    }
}
