package com.wujiacun.wujia.world;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Dedicated Forge-bus subscriber; intentionally independent of WujiaEvents. */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID)
public final class VillageFurnitureCommands {
    private VillageFurnitureCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        var furniture = Commands.literal("furniture").requires(source -> source.hasPermission(2));
        for (boolean repair : new boolean[]{false, true}) {
            furniture.then(Commands.literal(repair ? "repair" : "check")
                    .executes(context -> run(context.getSource(), 32, repair))
                    .then(Commands.argument("radius", IntegerArgumentType.integer(1, 64))
                            .executes(context -> run(context.getSource(), IntegerArgumentType.getInteger(context, "radius"), repair))));
        }
        event.getDispatcher().register(Commands.literal("wujia").then(furniture));
    }

    private static int run(CommandSourceStack source, int radius, boolean repair) {
        if (!source.getLevel().dimension().equals(WujiaVillageMod.WUJIA_DIM)) {
            source.sendFailure(Component.translatable("command.wujia_village.furniture.wrong_dimension"));
            return 0;
        }
        VillageFurnisher.Report report = VillageFurnisher.around(source.getLevel(), BlockPos.containing(source.getPosition()), radius, repair);
        source.sendSuccess(() -> Component.translatable("command.wujia_village.furniture.report",
                report.recognized, report.unloaded, report.unrecognized, report.alreadyProcessed,
                report.blocks, report.containers, report.collisions, report.modified), false);
        for (String detail : report.details) {
            int split = detail.indexOf(' ');
            String id = split < 0 ? detail : detail.substring(0, split);
            String reason = split < 0 ? "" : detail.substring(split + 1);
            source.sendSuccess(() -> Component.translatable("command.wujia_village.furniture.detail", id, reason), false);
        }
        return report.recognized + report.alreadyProcessed;
    }
}
