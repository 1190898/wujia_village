package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.util.HimLightning;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * 入门学徒 Him —— creepypasta 里那个白眼史蒂夫（Herobrine / HIM）。
 * 经典史蒂夫皮 + 纯白无瞳眼；受击后起飞、沿途拉出自定义闪电轨（无着火、高伤僵直），
 * 再召唤宠物末影龙。本人战力只是入门，宠物和闪电轨才是作业。
 */
public class HimVillagerEntity extends WuVillagerBase {
    private static final int FLY_DURATION = 36;
    private static final int FLY_COOLDOWN_TICKS = 45;
    private static final double LIGHTNING_SPACING = 2.4;

    private int flyCooldown;
    private int summonCooldown;
    private int flyTicks;
    private boolean flightActive;
    private boolean gravityBeforeFlight;
    private Vec3 flyVelocity = Vec3.ZERO;
    private double trailCarry;
    private UUID dragonId;
    private UUID lastAttackerId;

    public HimVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.him_villager");
        // 顶格血量 + 更高护甲/韧性（max_health 原版上限 1024）
        if (this.getAttribute(Attributes.ARMOR) != null) {
            this.getAttribute(Attributes.ARMOR).setBaseValue(30.0);
        }
        if (this.getAttribute(Attributes.ARMOR_TOUGHNESS) != null) {
            this.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(16.0);
        }
        if (this.getAttribute(Attributes.KNOCKBACK_RESISTANCE) != null) {
            this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
        }
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.him.hello";
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (this.level().isClientSide()) return hurt;

        LivingEntity attacker = null;
        if (!hurt) return false;
        if (source.getEntity() instanceof LivingEntity living
                && com.wujiacun.wujia.entity.combat.WuCombatRules.canHit(this, living)) {
            attacker = living;
            this.lastAttackerId = living.getUUID();
        }

        // Falling after landing must not trigger another escape flight (an endless fall/takeoff loop).
        // Only damage from an eligible living aggressor can request this combat reaction.
        if (attacker != null && this.flyCooldown <= 0 && this.flyTicks <= 0) {
            this.takeOff(attacker);
            this.flyCooldown = FLY_COOLDOWN_TICKS;
            this.summonCooldown = Math.min(this.summonCooldown, 60);
            if (attacker instanceof ServerPlayer player) {
                player.displayClientMessage(Component.translatable("message.wujia_village.him.fly"), true);
            }
        }

        if (attacker instanceof ServerPlayer player
                && !(attacker instanceof net.minecraftforge.common.util.FakePlayer)) {
            this.summonPet(player);
            this.orderPet(player);
        } else if (attacker != null) {
            this.orderPet(attacker);
        }
        return hurt;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;

        if (this.flyCooldown > 0) this.flyCooldown--;
        if (this.summonCooldown > 0) this.summonCooldown--;

        if (this.flyTicks > 0) {
            this.tickFlight((ServerLevel) this.level());
        } else if (this.flightActive) {
            // 兜底：飞行计数耗尽但标记未清时强制落地
            this.land((ServerLevel) this.level());
        }
    }

    /** 受击起飞：冲上天空，沿途落下自定义闪电轨。 */
    private void takeOff(LivingEntity attacker) {
        Vec3 away;
        if (attacker != null) {
            away = this.position().subtract(attacker.position());
            if (away.lengthSqr() < 0.01) {
                away = this.getLookAngle();
            }
        } else {
            away = this.getLookAngle();
        }
        away = new Vec3(away.x, 0.0, away.z).normalize();
        if (away.lengthSqr() < 0.01) {
            away = new Vec3(1.0, 0.0, 0.0);
        }
        // 斜上飞离：水平甩开 + 明显抬升，creepypasta 气质
        this.flyVelocity = new Vec3(away.x * 0.95, 0.85, away.z * 0.95);
        this.flyTicks = FLY_DURATION;
        this.flightActive = true;
        this.trailCarry = 0.0;
        this.gravityBeforeFlight = this.isNoGravity();
        this.getNavigation().stop();
        this.getCombatController().interruptForFlight();
        this.setNoGravity(true);
        this.setDeltaMovement(this.flyVelocity);
        this.hasImpulse = true;
        this.fallDistance = 0.0f;

        if (this.level() instanceof ServerLevel level) {
            level.playSound(null, this.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.2f, 0.55f);
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    this.getX(), this.getY() + 1.0, this.getZ(), 18, 0.35, 0.6, 0.35, 0.02);
            // 起飞点先砸一发，方便玩家立刻看见闪电轨
            LivingEntity focus = attacker != null ? attacker : this.resolveLastAttacker(level);
            HimLightning.strike(level, this.position(), this, focus, 28.0f);
        }
    }

    private void tickFlight(ServerLevel level) {
        this.flyTicks--;
        Vec3 before = this.position();
        this.setDeltaMovement(this.flyVelocity);
        this.move(MoverType.SELF, this.flyVelocity);
        this.fallDistance = 0.0f;
        this.hasImpulse = true;

        Vec3 after = this.position();
        double step = before.distanceTo(after);
        this.trailCarry += step;
        LivingEntity focus = this.resolveLastAttacker(level);

        while (this.trailCarry >= LIGHTNING_SPACING) {
            this.trailCarry -= LIGHTNING_SPACING;
            // 以当前位置落点：起飞路径上每隔一段砸一发
            HimLightning.strike(level, this.position(), this, focus, 36.0f);
        }

        // 尾迹粒子：白眼史蒂夫划过的冷光
        if (this.tickCount % 2 == 0) {
            level.sendParticles(ParticleTypes.END_ROD,
                    this.getX(), this.getY() + 0.9, this.getZ(), 2, 0.12, 0.2, 0.12, 0.01);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    this.getX(), this.getY() + 0.4, this.getZ(), 4, 0.2, 0.2, 0.2, 0.05);
        }

        // 轻微弧线：后半段往下收，方便落地
        if (this.flyTicks < FLY_DURATION / 2) {
            this.flyVelocity = this.flyVelocity.add(0.0, -0.035, 0.0);
        }

        if (this.flyTicks <= 0) {
            this.land(level);
        }
    }

    private void land(ServerLevel level) {
        this.flyTicks = 0;
        this.flightActive = false;
        this.setNoGravity(this.gravityBeforeFlight);
        this.getCombatController().finishFlight();
        this.flyVelocity = Vec3.ZERO;
        this.setDeltaMovement(Vec3.ZERO);
        this.trailCarry = 0.0;
        // 落地再补一发，收束闪电轨
        LivingEntity focus = this.resolveLastAttacker(level);
        HimLightning.strike(level, this.position(), this, focus, 40.0f);
        level.playSound(null, this.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 0.7f, 1.4f);
        level.sendParticles(ParticleTypes.CLOUD,
                this.getX(), this.getY() + 0.2, this.getZ(), 10, 0.4, 0.1, 0.4, 0.02);
    }

    private LivingEntity resolveLastAttacker(ServerLevel level) {
        if (this.lastAttackerId == null) return null;
        Entity e = level.getEntity(this.lastAttackerId);
        return e instanceof LivingEntity le && le.isAlive() ? le : null;
    }

    @Override
    public void travel(Vec3 input) {
        // Flight is moved once by tickFlight; vanilla travel must not move the velocity a second time.
        if (isFlyingAway()) return;
        super.travel(input);
    }

    private void orderPet(LivingEntity attacker) {
        if (!com.wujiacun.wujia.entity.combat.WuCombatRules.canHit(this, attacker)) return;
        if (this.dragonId == null) return;
        if (!(this.level() instanceof ServerLevel level)) return;
        Entity e = level.getEntity(this.dragonId);
        if (e instanceof HimDragonEntity dragon && dragon.isAlive()) {
            dragon.setTarget(attacker);
        }
    }

    private void summonPet(ServerPlayer player) {
        ServerLevel level = (ServerLevel) this.level();
        if (this.dragonId != null) {
            Entity existing = level.getEntity(this.dragonId);
            if (existing instanceof HimDragonEntity dragon && dragon.isAlive()) {
                player.displayClientMessage(Component.translatable("message.wujia_village.him.already"), true);
                return;
            }
        }
        if (this.summonCooldown > 0) {
            player.displayClientMessage(Component.translatable("message.wujia_village.him.rest"), true);
            return;
        }
        HimDragonEntity dragon = ModEntities.HIM_DRAGON.get().create(level);
        if (dragon == null) return;
        double x = this.getX() + 0.5;
        double y = this.getY() + 14.0;
        double z = this.getZ() + 0.5;
        dragon.moveTo(x, y, z, this.getYRot(), 0.0f);
        dragon.setPetOf(this.getUUID());
        if (this.lastAttackerId != null) {
            Entity attacker = level.getEntity(this.lastAttackerId);
            if (attacker instanceof LivingEntity living
                    && com.wujiacun.wujia.entity.combat.WuCombatRules.canHit(this, living)) {
                dragon.setTarget(living);
            }
        }
        level.addFreshEntity(dragon);
        this.dragonId = dragon.getUUID();
        this.summonCooldown = 900;
        level.playSound(null, this.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 2.0f, 1.0f);
        for (ServerPlayer nearby : level.getEntitiesOfClass(ServerPlayer.class, this.getBoundingBox().inflate(48.0))) {
            nearby.sendSystemMessage(Component.translatable("message.wujia_village.him.summon"));
        }
    }

    /** 自检与脚本用：当前是否在起飞段。 */
    public boolean isFlyingAway() {
        return this.flightActive || this.flyTicks > 0;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("HimSummon", this.summonCooldown);
        tag.putInt("HimFlyCd", this.flyCooldown);
        if (this.dragonId != null) tag.putUUID("HimDragon", this.dragonId);
        if (this.lastAttackerId != null) tag.putUUID("HimAttacker", this.lastAttackerId);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.summonCooldown = tag.getInt("HimSummon");
        this.flyCooldown = tag.getInt("HimFlyCd");
        if (tag.hasUUID("HimDragon")) this.dragonId = tag.getUUID("HimDragon");
        if (tag.hasUUID("HimAttacker")) this.lastAttackerId = tag.getUUID("HimAttacker");
        // 存档读回时不中途起飞，避免卡在半空
        this.flyTicks = 0;
        this.flightActive = false;
        this.setNoGravity(false);
    }
}
