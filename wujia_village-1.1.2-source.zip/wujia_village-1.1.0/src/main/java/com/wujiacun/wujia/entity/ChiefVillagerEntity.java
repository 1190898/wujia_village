package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * 村长：吴家村最强战力，一个意念捏爆黑洞。
 * 站在哪儿，哪儿就是全村的主心骨——金色光环庇佑周围所有村民与过客。
 */
public class ChiefVillagerEntity extends WuVillagerBase {

    private static final double AURA_RADIUS = 16.0;

    public ChiefVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.chief_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.chief";
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        ServerLevel sl = (ServerLevel) this.level();

        if (this.tickCount % 40 == 0) {
            // 村长威压：庇佑全村
            for (LivingEntity le : sl.getEntitiesOfClass(LivingEntity.class,
                    new AABB(this.blockPosition()).inflate(AURA_RADIUS),
                    e -> e instanceof AbstractVillager || e instanceof WuVillagerBase || e instanceof IronGolem)) {
                le.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 1));
                le.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
            }
        }
        if (this.tickCount % 10 == 0) {
            // 金色光环
            sl.sendParticles(ParticleTypes.END_ROD,
                    this.getX(), this.getY() + this.getBbHeight() * 0.7, this.getZ(),
                    1, 0.5, 0.4, 0.5, 0.01);
        }
        if (this.tickCount % 20 == 0) {
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                    this.getX(), this.getY() + this.getBbHeight() + 0.4, this.getZ(),
                    3, 0.6, 0.3, 0.6, 0.0);
        }
    }
}
