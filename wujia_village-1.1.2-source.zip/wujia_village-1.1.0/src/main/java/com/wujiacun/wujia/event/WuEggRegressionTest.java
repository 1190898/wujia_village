package com.wujiacun.wujia.event;

import com.mojang.authlib.GameProfile;
import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.HimDragonEntity;
import com.wujiacun.wujia.entity.WuChickenEntity;
import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

/** Isolated, opt-in integration test: never calls Entity.tick() or changes world clocks. */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID)
public final class WuEggRegressionTest {
    private static Run active;
    private WuEggRegressionTest() {}
    private static boolean flag(String property, String env) {
        return Boolean.getBoolean(property) || "true".equalsIgnoreCase(System.getenv(env));
    }
    private static boolean enabled() { return flag("wujia.eggtest", "WUJIA_EGGTEST"); }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void starting(ServerStartingEvent event) {
        if (enabled() && flag("wujia.selftest", "WUJIA_SELFTEST")) {
            WujiaVillageMod.LOGGER.error("[eggtest] FAIL old selftest must be false; EGGTEST FAIL");
            throw new IllegalStateException("Egg regression requires WUJIA_SELFTEST=false and wujia.selftest=false");
        }
    }
    @SubscribeEvent
    public static void started(ServerStartedEvent event) {
        if (!enabled()) return;
        active = new Run(event.getServer());
        WujiaVillageMod.LOGGER.info("[eggtest] START 1.1.1 real-world tick regression");
        if (active.observer) WujiaVillageMod.LOGGER.info("EGGTEST WAITING FOR OBSERVER on loopback port {}", event.getServer().getPort());
    }
    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || active == null || active.done) return;
        try { active.tick(); }
        catch (Throwable error) { active.error("server END test step", error); active.finish(); }
    }
    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void joining(EntityJoinLevelEvent event) {
        if (!enabled() || active == null || active.done || active.capturing == null) return;
        active.capturing.capture(event);
    }
    @SubscribeEvent
    public static void stopping(ServerStoppingEvent event) {
        if (active != null && !active.done) {
            active.check("server did not stop before test completed", false);
            active.finish();
        }
    }

    private static final class Run {
        final MinecraftServer server;
        final boolean observer = flag("wujia.eggObserver", "WUJIA_EGG_OBSERVER");
        final List<Arena> arenas = new ArrayList<>();
        final List<Sample> samples = new ArrayList<>();
        final List<DragonCase> dragons = new ArrayList<>();
        final Set<Integer> dragonIds = new HashSet<>();
        final List<PendingEgg> pendingEggs = new ArrayList<>();
        PendingEgg capturing;
        Cow dyingOwner, dyingTarget;
        boolean prepared, spawned, done;
        int warmup, elapsed, failures;
        Run(MinecraftServer server) { this.server = server; }
        void check(String label, boolean ok) {
            if (!ok) failures++;
            WujiaVillageMod.LOGGER.info("[eggtest] {} {}", ok ? "OK" : "FAIL", label);
        }
        void error(String label, Throwable error) {
            failures++;
            WujiaVillageMod.LOGGER.error("[eggtest] FAIL " + label, error);
        }
        void tick() {
            if (!prepared) {
                ServerPlayer viewer = server.getPlayerList().getPlayers().stream()
                        .filter(p -> !(p instanceof FakePlayer)).findFirst().orElse(null);
                if (observer && viewer == null) return; // No chunks or blocks touched while waiting.
                if (observer && !Set.of("127.0.0.1", "localhost", "::1").contains(server.getLocalIp()))
                    throw new IllegalStateException("Observer tests require server-ip=127.0.0.1 (loopback)");
                ServerLevel wujia = server.getLevel(WujiaVillageMod.WUJIA_DIM);
                check("both dimensions loaded", wujia != null);
                if (wujia == null) { finish(); return; }
                for (ServerLevel level : List.of(server.overworld(), wujia)) arenas.add(new Arena(level));
                for (Arena arena : arenas) arena.prepare(); // Snapshot shared rules before either arena changes them.
                if (observer) {
                    viewer.setGameMode(GameType.SPECTATOR);
                    viewer.teleportTo(server.overworld(), 4136.5, 201, 4104.5, 90, 20);
                    WujiaVillageMod.LOGGER.info("[eggtest] observer {} at overworld 4136.5 201 4104.5 (spectator)", viewer.getGameProfile().getName());
                }
                prepared = true;
                warmup = observer ? 40 : 5; // Let forced chunks become entity-ticking; no synthetic ticks.
                return;
            }
            if (warmup-- > 0) return;
            if (!spawned) {
                List<ForgeSpawnEggItem> eggs = new ArrayList<>();
                for (var item : ForgeRegistries.ITEMS) {
                    var id = ForgeRegistries.ITEMS.getKey(item);
                    if (id != null && id.getNamespace().equals(WujiaVillageMod.MODID) && item instanceof ForgeSpawnEggItem egg) eggs.add(egg);
                }
                eggs.sort(Comparator.comparing(e -> Objects.requireNonNull(ForgeRegistries.ITEMS.getKey(e)).toString()));
                check("all registered mod ForgeSpawnEggItems (expected 11, got " + eggs.size() + ")", eggs.size() == 11);
                for (Arena arena : arenas) {
                    int slot = 0;
                    for (ForgeSpawnEggItem egg : eggs) {
                        try { spawnEgg(arena, egg, egg.getType(null) == ModEntities.HIM_DRAGON.get() ? -1 : slot++); }
                        catch (Throwable error) { error(arena.name() + " egg " + ForgeRegistries.ITEMS.getKey(egg), error); }
                    }
                }
                extraDragons(arenas.get(0));
                Cow ordinary = cow(arenas.get(1), arenas.get(1).cell(10), false);
                samples.add(new Sample(ordinary, "Wujia ordinary Cow"));
                check("ordinary Cow lacks attack attributes", ordinary.getAttribute(Attributes.ATTACK_DAMAGE) == null);
                check("ordinary Cow receives no unsafe MeleeAttackGoal", ordinary.goalSelector.getAvailableGoals().stream()
                        .noneMatch(g -> g.getGoal() instanceof MeleeAttackGoal));
                spawned = true;
                return;
            }
            elapsed++;
            for (PendingEgg pending : pendingEggs) pending.observe();
            if (elapsed == 30) { dyingOwner.setHealth(0); check("early owner death applied", !dyingOwner.isAlive()); }
            if (elapsed == 40) { dyingTarget.setHealth(0); check("target death applied", !dyingTarget.isAlive()); }
            for (DragonCase dragon : dragons) dragon.observe();
            if (elapsed < 240) return;
            boolean ticked = samples.stream().allMatch(s -> s.entity.tickCount - s.baseline >= 240);
            if (!ticked && elapsed < 400) return;
            for (Sample sample : samples) {
                int ticks = sample.entity.tickCount - sample.baseline;
                check(sample.label + " alive, AI enabled, >=240 actual ticks (" + ticks + ")", sample.entity.isAlive()
                        && !sample.entity.isNoAi() && ticks >= 240 && sample.entity.level().getEntity(sample.entity.getId()) == sample.entity);
            }
            for (DragonCase dragon : dragons) dragon.verify();
            check("22 actual egg spawns across both dimensions", pendingEggs.size() == 22 && pendingEggs.stream().allMatch(p -> p.inserted)
                    && samples.size() == 21 && dragons.stream().filter(d -> d.egg).count() == 2);
            for (Sample sample : samples) if (sample.entity instanceof WuChickenEntity chicken
                    && chicken.level().dimension().equals(WujiaVillageMod.WUJIA_DIM)) {
                try {
                    Cow victim = cow(arenas.get(1), arenas.get(1).cell(11), true);
                    victim.setInvulnerable(false);
                    float health = victim.getHealth();
                    check("Wujia chicken has damage AND knockback attributes", chicken.getAttribute(Attributes.ATTACK_DAMAGE) != null
                            && chicken.getAttribute(Attributes.ATTACK_KNOCKBACK) != null);
                    check("Wujia chicken actual doHurtTarget damages valid fixture", chicken.doHurtTarget(victim) && victim.getHealth() < health);
                } catch (Throwable error) { error("chicken actual attack", error); }
            }
            check("real END tick window >=240 (" + elapsed + ")", elapsed >= 240);
            finish();
        }
        void spawnEgg(Arena arena, ForgeSpawnEggItem egg, int slot) {
            BlockPos floor = slot < 0 ? arena.dragon(0).below() : arena.cell(slot).below();
            arena.block(floor, Blocks.SEA_LANTERN.defaultBlockState());
            ItemStack stack = new ItemStack(egg, 2);
            FakePlayer user = new FakePlayer(arena.level, new GameProfile(UUID.randomUUID(), "egg_survival"));
            user.setGameMode(GameType.SURVIVAL);
            user.setItemInHand(InteractionHand.MAIN_HAND, stack); // Not inserted: cannot become a combat target.
            user.setPos(floor.getX() + .5, floor.getY() + 1, floor.getZ() + .5);
            EntityType<?> expected = egg.getType(stack.getTag());
            String label = arena.name() + " " + ForgeRegistries.ITEMS.getKey(egg);
            PendingEgg pending = new PendingEgg(arena, expected, floor, label);
            pendingEggs.add(pending);
            capturing = pending;
            try {
                var result = egg.useOn(new UseOnContext(user, InteractionHand.MAIN_HAND,
                        new BlockHitResult(Vec3.atBottomCenterOf(floor.above()), Direction.UP, floor, false)));
                check(label + " survival useOn consumes exactly one", !user.getAbilities().instabuild && result.consumesAction() && stack.getCount() == 1);
            } finally { capturing = null; }
            if (pending.entities.size() != 1) return; // Deferred insertion check reports missing/duplicate join too.
            Entity entity = pending.entities.get(0);
            check(label + " add-entity packet", entity.getAddEntityPacket() != null);
            if (entity instanceof HimDragonEntity dragon) addDragon(arena, dragon, label + " unowned", true);
            else if (entity instanceof Mob mob) {
                check(label + " AI active at insertion", !mob.isNoAi());
                samples.add(new Sample(mob, label));
            } else check(label + " expected living Mob", false);
        }
        Cow cow(Arena arena, BlockPos at, boolean fixture) {
            Cow cow = new Cow(EntityType.COW, arena.level);
            if (fixture) { cow.setNoAi(true); cow.setInvulnerable(true); cow.setNoGravity(true); }
            cow.setPersistenceRequired();
            cow.moveTo(at.getX() + .5, at.getY(), at.getZ() + .5, 0, 0);
            arena.owned.add(cow);
            check(arena.name() + " Cow fixture inserted", arena.level.addFreshEntity(cow));
            return cow;
        }
        void extraDragons(Arena arena) {
            for (int i = 1; i <= 4; i++) {
                HimDragonEntity dragon = Objects.requireNonNull(ModEntities.HIM_DRAGON.get().create(arena.level));
                String label = switch (i) { case 1 -> "unresolvable owner UUID"; case 2 -> "NBT missing owner";
                    case 3 -> "early owner death"; default -> "target death"; };
                dragon.setPetOf(UUID.randomUUID());
                if (i == 2) {
                    CompoundTag tag = new CompoundTag();
                    check("dragon NBT save custom id", dragon.save(tag) && tag.getString("id").equals("wujia_village:him_dragon"));
                    tag.remove("HimOwner");
                    dragon.load(tag); // Loading into previously-owned object must clear stale owner too.
                    check("NBT load absent owner clears old UUID", !dragon.saveWithoutId(new CompoundTag()).hasUUID("HimOwner"));
                }
                BlockPos at = arena.dragon(i);
                dragon.moveTo(at.getX() + .5, at.getY(), at.getZ() + .5, 0, 0);
                if (i == 3) { dyingOwner = cow(arena, at.below(12), true); dragon.setPetOf(dyingOwner.getUUID()); }
                if (i == 4) { dyingTarget = cow(arena, at.below(12), true); dragon.setTarget(dyingTarget); }
                arena.owned.add(dragon);
                check(label + " inserted", arena.level.addFreshEntity(dragon));
                addDragon(arena, dragon, label, false);
            }
        }
        void addDragon(Arena arena, HimDragonEntity dragon, String label, boolean egg) {
            dragons.add(new DragonCase(dragon, label, egg));
            check(label + " runtime custom type", dragon.getType() == ModEntities.HIM_DRAGON.get());
            check(label + " packet custom type", dragon.getAddEntityPacket() instanceof ClientboundAddEntityPacket packet
                    && packet.getType() == ModEntities.HIM_DRAGON.get());
            CompoundTag tag = new CompoundTag();
            check(label + " NBT custom id", dragon.save(tag) && tag.getString("id").equals("wujia_village:him_dragon"));
            boolean unique = dragonIds.add(dragon.getId());
            var parts = dragon.getParts();
            if (parts != null) for (var part : parts) unique &= dragonIds.add(part.getId());
            check(label + " multipart shape; globally unique parent/part IDs", dragon.isMultipartEntity() && parts != null && parts.length == 8 && unique);
        }
        void finish() {
            if (done) return;
            done = true;
            for (Arena arena : arenas) try { arena.cleanup(); } catch (Throwable error) { error("arena cleanup", error); }
            int code = failures == 0 ? 0 : 1;
            WujiaVillageMod.LOGGER.info("EGGTEST {} (failures={})", code == 0 ? "OK" : "FAIL", failures);
            server.halt(false);
            new Thread(() -> {
                server.halt(true); // Join from an independent thread, never the server/shutdown-hook cycle.
                System.out.flush(); System.err.flush(); System.exit(code);
            }, "wujia-eggtest-exit").start();
        }
        private final class PendingEgg {
            final Arena arena;
            final EntityType<?> expected;
            final BlockPos floor;
            final String label;
            final List<Entity> entities = new ArrayList<>();
            boolean canceled, resolved, inserted;
            int waited;
            PendingEgg(Arena arena, EntityType<?> expected, BlockPos floor, String label) {
                this.arena = arena; this.expected = expected; this.floor = floor; this.label = label;
            }
            void capture(EntityJoinLevelEvent event) {
                Entity entity = event.getEntity();
                if (event.getLevel() != arena.level || entity.getType() != expected) return;
                entities.add(entity); arena.owned.add(entity); canceled |= event.isCanceled();
            }
            void observe() {
                if (resolved) return;
                waited++;
                Entity entity = entities.size() == 1 ? entities.get(0) : null;
                boolean tracked = entity != null && arena.level.getEntity(entity.getId()) == entity;
                if (entity != null && !canceled && !entity.isRemoved() && (entity.tickCount == 0 || !tracked) && waited < 20) return;
                resolved = true;
                inserted = entity != null && !canceled && entity.isAlive() && entity.isAddedToWorld() && tracked && entity.tickCount > 0
                        && entity.level() == arena.level && entity.getType() == expected && entity.distanceToSqr(Vec3.atCenterOf(floor)) < 1024;
                check(label + " inserts exactly expected type and ticks (wait=" + waited + ")", inserted);
                if (!inserted) WujiaVillageMod.LOGGER.error("[eggtest] insertion diagnostic {} expected={} joins={} canceled={} entity={} level={} pos={} ticks={} added={} tracked={} removed={} reason={}",
                        label, ForgeRegistries.ENTITY_TYPES.getKey(expected), entities.size(), canceled, entity,
                        entity == null ? null : entity.level().dimension().location(), entity == null ? null : entity.position(), entity == null ? -1 : entity.tickCount,
                        entity != null && entity.isAddedToWorld(), tracked, entity != null && entity.isRemoved(), entity == null ? null : entity.getRemovalReason());
            }
        }
        private final class DragonCase {
            final HimDragonEntity entity;
            final String label;
            final boolean egg;
            final int baseline;
            boolean first, after20, before200, removed;
            DragonCase(HimDragonEntity entity, String label, boolean egg) {
                this.entity = entity; this.label = label; this.egg = egg; baseline = entity.tickCount;
            }
            boolean partsTracked() {
                ServerLevel level = (ServerLevel) entity.level();
                var parts = entity.getParts();
                if (level.getEntity(entity.getId()) != entity || parts == null || parts.length != 8) return false;
                for (var part : parts) if (level.getEntityOrPart(part.getId()) != part) return false;
                return true;
            }
            void observe() {
                int ticks = entity.tickCount - baseline;
                if (!first && ticks >= 1) { first = true; check(label + " first actual tick survives, AI active", entity.isAlive() && !entity.isNoAi());
                    check(label + " first actual tick parent and 8 parts tracked", partsTracked()); }
                if (!after20 && ticks >= 21) { after20 = true; check(label + " >20 actual ticks survives", entity.isAlive());
                    check(label + " >20 actual ticks parent and 8 parts tracked", partsTracked()); }
                if (!before200 && ticks >= 180) { before200 = true; check(label + " waits safely before cleanup", entity.isAlive()); }
                if (!removed && entity.isRemoved()) {
                    removed = true;
                    check(label + " finite idle cleanup at 200 actual ticks (" + ticks + ")", ticks == 200 && entity.getRemovalReason() == Entity.RemovalReason.DISCARDED);
                }
            }
            void verify() { check(label + " complete real-tick lifecycle", first && after20 && before200 && removed && !entity.isNoAi()); }
        }
    }
    private record Sample(Mob entity, String label, int baseline) {
        Sample(Mob entity, String label) { this(entity, label, entity.tickCount); }
    }
    private static final class Arena {
        final ServerLevel level;
        final Map<BlockPos, BlockState> saved = new LinkedHashMap<>();
        final Set<Long> forced = new HashSet<>();
        final Set<UUID> existing = new HashSet<>();
        final List<Entity> owned = new ArrayList<>();
        final boolean mobSpawning;
        Arena(ServerLevel level) { this.level = level; mobSpawning = level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING); }
        String name() { return level.dimension().location().toString(); }
        BlockPos cell(int slot) { return new BlockPos(4100 + slot % 6 * 8, 193, 4100 + slot / 6 * 8); }
        BlockPos dragon(int slot) { return new BlockPos(4208 + slot * 96, 224, 4104); }
        void force(BlockPos at) {
            int cx = at.getX() >> 4, cz = at.getZ() >> 4;
            for (int x = cx - 1; x <= cx + 1; x++) for (int z = cz - 1; z <= cz + 1; z++) {
                long key = ChunkPos.asLong(x, z);
                if (!level.getForcedChunks().contains(key)) { forced.add(key); level.setChunkForced(x, z, true); }
                level.getChunk(x, z);
            }
        }
        void block(BlockPos pos, BlockState state) {
            saved.putIfAbsent(pos.immutable(), level.getBlockState(pos));
            level.setBlock(pos, state, 2);
        }
        void prepare() {
            level.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false, level.getServer());
            force(cell(0)); force(cell(11));
            for (int i = 0; i <= (level.dimension().equals(net.minecraft.world.level.Level.OVERWORLD) ? 4 : 0); i++) force(dragon(i));
            for (Entity entity : level.getAllEntities()) existing.add(entity.getUUID());
            for (int x = 4096; x < 4144; x++) for (int z = 4096; z < 4112; z++) {
                block(new BlockPos(x, 192, z), Blocks.SEA_LANTERN.defaultBlockState());
                boolean wall = (x - 4096) % 8 == 0 || (z - 4096) % 8 == 0 || x == 4143 || z == 4111;
                for (int y = 193; y <= 197; y++) block(new BlockPos(x, y, z), (wall ? Blocks.GLASS : Blocks.AIR).defaultBlockState());
            }
        }
        void cleanup() {
            try {
                for (Entity entity : owned) entity.discard();
                List<Entity> strays = level.getEntitiesOfClass(Entity.class, new AABB(4096, 192, 4096, 4640, 256, 4128),
                        e -> !(e instanceof ServerPlayer) && !existing.contains(e.getUUID()));
                for (Entity entity : strays) entity.discard();
                for (var entry : saved.entrySet()) level.setBlock(entry.getKey(), entry.getValue(), 2);
            } finally {
                try { for (long key : forced) level.setChunkForced(ChunkPos.getX(key), ChunkPos.getZ(key), false); }
                finally { level.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(mobSpawning, level.getServer()); }
            }
        }
    }
}
