package com.wujiacun.wujia.client.model;

import com.wujiacun.wujia.entity.BroomEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * 飞帚模型：一根木杆 + 一捆扫帚毛 + 一道铜箍。
 * 模型空间里 16 单位 = 1 格，扫帚整体约 1.4 格长，朝 -Z 方向。
 */
public class BroomModel extends EntityModel<BroomEntity> {

    private final ModelPart root;
    private final ModelPart bristles;

    public BroomModel(ModelPart root) {
        this.root = root;
        this.bristles = root.getChild("bristles");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition part = mesh.getRoot();

        part.addOrReplaceChild("handle",
                CubeListBuilder.create().texOffs(0, 0).addBox(-0.5f, -1.0f, -14.0f, 1.0f, 1.0f, 20.0f),
                PartPose.ZERO);
        part.addOrReplaceChild("bristles",
                CubeListBuilder.create().texOffs(0, 21).addBox(-2.5f, -3.0f, 6.0f, 5.0f, 5.0f, 6.0f),
                PartPose.ZERO);
        part.addOrReplaceChild("band",
                CubeListBuilder.create().texOffs(22, 21).addBox(-1.5f, -2.0f, 5.0f, 3.0f, 3.0f, 2.0f),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(BroomEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        // 悬停时扫帚毛轻轻抖，像还被主人握着在扫
        this.bristles.xRot = (float) Math.sin(ageInTicks * 0.18) * 0.09f;
        this.bristles.zRot = (float) Math.sin(ageInTicks * 0.11 + 1.0f) * 0.05f;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(pose, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
