package com.wujiacun.wujia.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * 直接铺村子，不跑主世界噪声。填充是同步完成的，进维度时不会去排队生成一整张地图。
 */
public class WujiaChunkGenerator extends ChunkGenerator {
    public static final Codec<WujiaChunkGenerator> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(WujiaChunkGenerator::getBiomeSource))
                    .apply(instance, WujiaChunkGenerator::new));

    public WujiaChunkGenerator(BiomeSource biomeSource) {
        super(biomeSource);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public void applyCarvers(WorldGenRegion level, long seed, RandomState random, BiomeManager biomes,
                              StructureManager structures, ChunkAccess chunk, GenerationStep.Carving step) {
    }

    @Override
    public void buildSurface(WorldGenRegion level, StructureManager structures, RandomState random, ChunkAccess chunk) {
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion level) {
    }

    @Override
    public int getGenDepth() {
        return 256;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState random,
                                                         StructureManager structures, ChunkAccess chunk) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        BlockState stone = net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int wx = minX + lx;
                int wz = minZ + lz;
                chunk.setBlockState(pos.set(wx, 0, wz), WujiaVillageLayout.blockAt(wx, 0, wz), false);
                for (int y = 1; y <= 60; y++) {
                    chunk.setBlockState(pos.set(wx, y, wz), stone, false);
                }
                for (int y = 61; y <= WujiaVillageLayout.MAX_BUILD_Y; y++) {
                    BlockState state = WujiaVillageLayout.blockAt(wx, y, wz);
                    if (!state.isAir()) {
                        chunk.setBlockState(pos.set(wx, y, wz), state, false);
                    }
                }
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }

    @Override
    public int getSeaLevel() {
        return WujiaVillageLayout.SURFACE;
    }

    @Override
    public int getMinY() {
        return 0;
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        for (int y = WujiaVillageLayout.MAX_BUILD_Y; y >= 0; y--) {
            if (type.isOpaque().test(WujiaVillageLayout.blockAt(x, y, z))) {
                return y + 1;
            }
        }
        return level.getMinBuildHeight();
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        BlockState[] states = new BlockState[256];
        BlockState air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        for (int y = 0; y < states.length; y++) {
            states[y] = y <= WujiaVillageLayout.MAX_BUILD_Y ? WujiaVillageLayout.blockAt(x, y, z) : air;
        }
        return new NoiseColumn(0, states);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
        info.add("Wujia village plot");
    }

    @Override
    public int getSpawnHeight(LevelHeightAccessor level) {
        return WujiaVillageLayout.SURFACE + 1;
    }
}
