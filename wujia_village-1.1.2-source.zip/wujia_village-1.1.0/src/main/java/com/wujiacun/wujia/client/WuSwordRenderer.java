package com.wujiacun.wujia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.wujiacun.wujia.entity.WuSwordEntity;
import com.wujiacun.wujia.registry.ModItems;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** The actual registered sword item, aligned tip-first with velocity and depth-tested colored wake. */
public final class WuSwordRenderer extends EntityRenderer<WuSwordEntity> {
    private final ItemRenderer items;
    private final ItemStack sword = new ItemStack(ModItems.WU_SWORD.get());

    public WuSwordRenderer(EntityRendererProvider.Context context) {
        super(context);
        items = context.getItemRenderer();
        shadowRadius = 0.12f;
    }

    @Override
    public ResourceLocation getTextureLocation(WuSwordEntity entity) { return WuEffectGeometry.WHITE; }

    @Override
    public void render(WuSwordEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        Vec3 velocity = entity.getDeltaMovement();
        float facingYaw = -Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        float pitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
        if (velocity.lengthSqr() > 0.0001) {
            facingYaw = (float) Math.toDegrees(Math.atan2(-velocity.x, velocity.z));
            pitch = (float) -Math.toDegrees(Math.atan2(velocity.y, velocity.horizontalDistance()));
        }
        Vec3 forward = new Vec3(-Mth.sin(facingYaw * Mth.DEG_TO_RAD) * Mth.cos(pitch * Mth.DEG_TO_RAD),
                -Mth.sin(pitch * Mth.DEG_TO_RAD), Mth.cos(facingYaw * Mth.DEG_TO_RAD) * Mth.cos(pitch * Mth.DEG_TO_RAD));
        int tint = entity.getTint();
        VertexConsumer vertices = WuEffectGeometry.buffer(buffers);
        double length = Math.min(2.8, 0.7 + velocity.length() * 1.2);
        for (int i = 0; i < 6; i++) {
            double a = i / 6.0, b = (i + 1) / 6.0;
            WuEffectGeometry.tube(pose, vertices, forward.scale(-0.15 - length * a),
                    forward.scale(-0.15 - length * b), 0.075 * (1 - a), 0.075 * (1 - b),
                    tint, 0.5f * (1 - (float) a));
        }
        WuEffectGeometry.ring(pose, vertices, Vec3.ZERO, forward, 0.22, 0.035, tint, 0.6f);
        WuEffectGeometry.tube(pose, vertices, forward.scale(-0.45), forward.scale(0.5),
                0.08, 0.035, WuEffectGeometry.brighten(tint, 0.65f), 0.25f);
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-facingYaw));
        pose.mulPose(Axis.XP.rotationDegrees(pitch + 90));
        // The generated sprite's hilt is bottom-left and tip top-right. NONE avoids FIXED's 180deg flip.
        pose.mulPose(Axis.ZP.rotationDegrees(45));
        pose.scale(1.35f, 1.35f, 1.35f);
        items.renderStatic(sword, ItemDisplayContext.NONE, LightTexture.FULL_BRIGHT,
                OverlayTexture.NO_OVERLAY, pose, buffers, entity.level(), entity.getId());
        pose.popPose();
        super.render(entity, yaw, partialTick, pose, buffers, light);
    }
}
