package com.wujiacun.wujia.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/** 村鸡——上古神禽。天一黑就叫，叫完天就亮了；叫一声，空气里的战力因子又浓一分。 */
public class WuChickenEntity extends Chicken {
    private int crowCooldown;

    public WuChickenEntity(EntityType<? extends Chicken> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setCustomName(Component.translatable("entity.wujia_village.wu_chicken"));
        this.setCustomNameVisible(true);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        if (this.crowCooldown > 0) this.crowCooldown--;
        long time = this.level().getDayTime() % 24000L;
        if (time > 13000L && this.crowCooldown <= 0 && this.level() instanceof ServerLevel server) {
            long day = this.level().getDayTime() / 24000L;
            server.setDayTime(day * 24000L + 1000L);
            this.crowCooldown = 600;
            server.playSound(null, this.blockPosition(), SoundEvents.CHICKEN_AMBIENT, SoundSource.NEUTRAL, 1.2f, 0.6f);
            AABB box = this.getBoundingBox().inflate(32.0);
            for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class, box)) {
                player.displayClientMessage(Component.translatable("message.wujia_village.chicken.crow"), true);
            }
        }
    }

    @Override
    public boolean isFood(net.minecraft.world.item.ItemStack stack) {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
