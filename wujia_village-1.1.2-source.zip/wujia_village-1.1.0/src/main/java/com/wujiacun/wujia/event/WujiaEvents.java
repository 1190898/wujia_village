package com.wujiacun.wujia.event;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.block.WujiaAirBlock;
import com.wujiacun.wujia.entity.DodgeVillagerEntity;
import com.wujiacun.wujia.entity.TeleportVillagerEntity;
import com.wujiacun.wujia.entity.GuardVillagerEntity;
import com.wujiacun.wujia.entity.HimDragonEntity;
import com.wujiacun.wujia.entity.WuChickenEntity;
import com.wujiacun.wujia.entity.WuDogEntity;
import com.wujiacun.wujia.entity.WuVillagerBase;
import com.wujiacun.wujia.entity.WuSwordEntity;
import com.wujiacun.wujia.item.WuSwordItem;
import com.wujiacun.wujia.registry.ModItems;
import com.wujiacun.wujia.util.ModDamageTypes;
import com.wujiacun.wujia.world.CubePlanetShow;
import com.wujiacun.wujia.world.WujiaSpawnHandler;
import com.wujiacun.wujia.world.WujiaVillageLayout;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraftforge.event.entity.EntityMobGriefingEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * 吴家村的世界法则。
 */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID)
public class WujiaEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger("WujiaVillage");

    private static final UUID BUFF_HEALTH = UUID.nameUUIDFromBytes("wujia_buff_health".getBytes(StandardCharsets.UTF_8));
    private static final UUID BUFF_ARMOR = UUID.nameUUIDFromBytes("wujia_buff_armor".getBytes(StandardCharsets.UTF_8));
    private static final UUID BUFF_TOUGH = UUID.nameUUIDFromBytes("wujia_buff_tough".getBytes(StandardCharsets.UTF_8));
    private static final UUID BUFF_KNOCK = UUID.nameUUIDFromBytes("wujia_buff_knock".getBytes(StandardCharsets.UTF_8));
    private static final UUID BUFF_ATTACK = UUID.nameUUIDFromBytes("wujia_buff_attack".getBytes(StandardCharsets.UTF_8));

    private static final String RETALIATE = "wujia_retaliate";

    // ------------------------------------------------------------------
    // 服务器 tick：维度运营
    // ------------------------------------------------------------------

    /** 敌对生物进村会被同化。Him 的宠物龙除外。 */
    public static boolean shouldAssimilate(Entity entity) {
        if (entity instanceof Player || entity instanceof HimDragonEntity) return false;
        return entity instanceof Enemy;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = event.getServer();
        ServerLevel wujia = server.getLevel(WujiaVillageMod.WUJIA_DIM);
        if (wujia != null) CubePlanetShow.tick(wujia);
        WujiaSpawnHandler.tick(server);
    }

    // ------------------------------------------------------------------
    // 生物进村：普通生物大加强 + 会还手；敌对生物被同化
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!level.dimension().equals(WujiaVillageMod.WUJIA_DIM)) return;

        Entity entity = event.getEntity();

        // 普通生物：血厚、甲厚、抗击退、打人疼，被打了还会还手
        if (entity instanceof LivingEntity living && !(entity instanceof Player)
                && !(entity instanceof WuVillagerBase) && !(entity instanceof HimDragonEntity)) {
            buffLocalCreature(living);
            teachRetaliation(living);
        }

        if (!shouldAssimilate(entity)) return;
        event.setCanceled(true);
        WujiaSpawnHandler.convertEnemy(level, entity.blockPosition(), entity.getYRot());
    }

    /** 吴家村的普通生物：血量 ×4、护甲 +18、韧性 +8、抗击退、攻击翻倍。 */
    private static void buffLocalCreature(LivingEntity living) {
        addModifier(living, Attributes.MAX_HEALTH, BUFF_HEALTH, "wujia_health", 3.0, AttributeModifier.Operation.MULTIPLY_TOTAL);
        addModifier(living, Attributes.ARMOR, BUFF_ARMOR, "wujia_armor", 18.0, AttributeModifier.Operation.ADDITION);
        addModifier(living, Attributes.ARMOR_TOUGHNESS, BUFF_TOUGH, "wujia_toughness", 8.0, AttributeModifier.Operation.ADDITION);
        addModifier(living, Attributes.KNOCKBACK_RESISTANCE, BUFF_KNOCK, "wujia_knockback", 0.85, AttributeModifier.Operation.ADDITION);
        addModifier(living, Attributes.ATTACK_DAMAGE, BUFF_ATTACK, "wujia_attack", 1.5, AttributeModifier.Operation.MULTIPLY_TOTAL);
        if (living.getHealth() > 0.0f) living.setHealth(living.getMaxHealth());
    }

    private static void addModifier(LivingEntity living, Attribute attribute, UUID id, String name,
                                    double amount, AttributeModifier.Operation op) {
        AttributeInstance instance = living.getAttribute(attribute);
        if (instance == null) return;
        if (instance.getModifier(id) != null) return;
        instance.addPermanentModifier(new AttributeModifier(id, name, amount, op));
    }

    /** 被打了会还手：加一个"记仇"目标选择器 + 近战反击。 */
    private static void teachRetaliation(LivingEntity living) {
        if (!(living instanceof PathfinderMob mob)) return;
        if (mob.getPersistentData().getBoolean(RETALIATE)) return;
        mob.getPersistentData().putBoolean(RETALIATE, true);
        mob.targetSelector.addGoal(1, new HurtByTargetGoal(mob));
        // 原版动物未必注册攻击属性；Mob.doHurtTarget 会读取它们，不能盲目添加近战。
        if ((mob instanceof Animal || mob instanceof Villager)
                && mob.getAttribute(Attributes.ATTACK_DAMAGE) != null
                && mob.getAttribute(Attributes.ATTACK_KNOCKBACK) != null) {
            mob.goalSelector.addGoal(2, new MeleeAttackGoal(mob, 1.15, true));
        }
    }

    /** Him 的宠物龙不拆方块。火球、俯冲和龙息还在。 */
    @SubscribeEvent
    public static void onDragonGrief(EntityMobGriefingEvent event) {
        if (event.getEntity() instanceof HimDragonEntity) {
            event.setResult(Event.Result.DENY);
        }
    }

    // ------------------------------------------------------------------
    // 神剑穿甲：吴家神剑的攻击无视护甲
    // ------------------------------------------------------------------

    /**
     * 神剑穿甲走正常攻击流程，不再取消原攻击。
     * 护甲结算之后把伤害抬回武器面板，近战敲击、击退和攻速都还在。
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onSwordPierce(LivingDamageEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        if (!event.getSource().is(net.minecraft.world.damagesource.DamageTypes.PLAYER_ATTACK)) return;
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        if (!(attacker.getMainHandItem().getItem() instanceof WuSwordItem)) return;
        if (attacker == event.getEntity() || isVillageProtected(event.getEntity())) return;

        float raw = (float) attacker.getAttributeValue(Attributes.ATTACK_DAMAGE);
        if (attacker instanceof Player player) {
            float scale = player.getAttackStrengthScale(0.5f);
            raw *= 0.2f + scale * scale * 0.8f;
            if (scale > 0.9f && player.fallDistance > 0.0f && !player.onGround() && !player.isInWater()) {
                raw *= 1.5f;
            }
        }
        if (raw > event.getAmount()) event.setAmount(raw);
    }

    // ------------------------------------------------------------------
    // 闪身步：闪身步村民闪避攻击
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onDodge(LivingAttackEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide()) return;
        if (event.getSource().getEntity() == target) return;

        if (target instanceof DodgeVillagerEntity dodge) {
            if (event.getSource().getEntity() instanceof DodgeVillagerEntity) return;
            if (event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE)) {
                // 箭矢？国家级非遗闪身步从容避让
                event.setCanceled(true);
                dodge.dodgeStep();
            } else if (event.getSource().getEntity() != null) {
                // 近战：发动闪身步闪避动作
                if (dodge.tryDodgeAttack()) {
                    event.setCanceled(true);
                }
            }
        } else if (target instanceof TeleportVillagerEntity teleport) {
            if (event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE)) {
                // 瞬移村民：如末影人般弹射物免疫，直接瞬移走
                event.setCanceled(true);
                teleport.teleportRandomly(4.0, 9.0);
            }
        }
    }

    // ------------------------------------------------------------------
    // 吴家神剑：右键格挡与时机盾反（借力打力，万剑归宗）
    // ------------------------------------------------------------------

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onSwordParry(LivingAttackEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide()) return;
        if (!(target instanceof Player player)) return;
        if (!player.isUsingItem()) return;
        ItemStack using = player.getUseItem();
        if (!(using.getItem() instanceof WuSwordItem)) return;

        event.setCanceled(true);
        ServerLevel level = (ServerLevel) player.level();
        Entity direct = event.getSource().getDirectEntity();
        Entity attacker = event.getSource().getEntity();

        int useTicks = player.getTicksUsingItem();
        boolean perfectParry = useTicks <= 25; // 举剑前 1.25 秒内判定为精准盾反

        if (perfectParry) {
            // 完美盾反：清脆打铁音 + 暴击闪光 + 击退反弹 + 飞剑追击
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.SHIELD_BLOCK,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 1.5f);
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.ANVIL_PLACE,
                    net.minecraft.sounds.SoundSource.PLAYERS, 0.9f, 1.8f);
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.2f);

            level.sendParticles(net.minecraft.core.particles.ParticleTypes.FLASH,
                    player.getX(), player.getY() + 1.0, player.getZ(), 1, 0, 0, 0, 0);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                    player.getX(), player.getY() + 1.0, player.getZ(), 18, 0.5, 0.5, 0.5, 0.25);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.SWEEP_ATTACK,
                    player.getX(), player.getY() + 1.0, player.getZ(), 2, 0.2, 0.2, 0.2, 0);

            player.displayClientMessage(Component.translatable("message.wujia_village.sword_parry"), true);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 2, false, false));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1, false, false));

            // 弹射物原路弹回
            if (direct instanceof Projectile proj) {
                Vec3 motion = proj.getDeltaMovement().scale(-1.6);
                proj.setDeltaMovement(motion);
                proj.setOwner(player);
                proj.hasImpulse = true;
            }

            // 反击近战攻击者：击退、迟缓与万剑归宗追击
            if (attacker instanceof LivingEntity livingAttacker && livingAttacker != player) {
                livingAttacker.knockback(1.8, player.getX() - livingAttacker.getX(), player.getZ() - livingAttacker.getZ());
                livingAttacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3));
                livingAttacker.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 2));
                livingAttacker.hurtMarked = true;

                for (int i = 0; i < 4; i++) {
                    WuSwordEntity.summon(level, player, livingAttacker, i, 4, 0xFFD700, 200.0f);
                }
            }
        } else {
            // 普通格挡持续防御
            level.playSound(null, player.blockPosition(), net.minecraft.sounds.SoundEvents.SHIELD_BLOCK,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.0f);
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                    player.getX(), player.getY() + 1.0, player.getZ(), 6, 0.3, 0.3, 0.3, 0.1);
            if (attacker instanceof LivingEntity livingAttacker && livingAttacker != player) {
                livingAttacker.knockback(0.5, player.getX() - livingAttacker.getX(), player.getZ() - livingAttacker.getZ());
                livingAttacker.hurtMarked = true;
            }
        }
    }

    // ------------------------------------------------------------------
    // 吴家之躯：伤害封顶（几乎不可能被正常方式杀死）
    // ------------------------------------------------------------------

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onWuBody(LivingHurtEvent event) {
        LivingEntity entity = event.getEntity();
        float cap;
        if (entity instanceof WuVillagerBase base) {
            cap = Math.max(2.0f, base.getMaxHealth() * 0.01f);
        } else if (entity instanceof WuChickenEntity || entity instanceof WuDogEntity) {
            cap = 8.0f;
        } else {
            return;
        }
        if (event.getAmount() > cap) event.setAmount(cap);
    }

    private static boolean isVillageProtected(LivingEntity entity) {
        return entity instanceof WuVillagerBase
                || entity instanceof WuChickenEntity
                || entity instanceof WuDogEntity
                || entity instanceof Player;
    }

    // ------------------------------------------------------------------
    // 吴家空气：飞行的时限一到就收回去
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        CompoundTag data = player.getPersistentData();
        long until = data.getLong(WujiaAirBlock.UNTIL);
        if (until == 0L) return;
        if (player.level().getGameTime() <= until) return;

        data.putLong(WujiaAirBlock.UNTIL, 0L);
        if (!data.getBoolean(WujiaAirBlock.GRANTED)) return;
        data.putBoolean(WujiaAirBlock.GRANTED, false);
        if (player.isCreative() || player.isSpectator()) return;
        player.getAbilities().mayfly = false;
        player.getAbilities().flying = false;
        player.onUpdateAbilities();
        player.displayClientMessage(Component.translatable("message.wujia_village.air.fade"), true);
    }

    // ------------------------------------------------------------------
    // 玩家进出维度：赐福礼包 + 落地装备
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onDimChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!event.getTo().equals(WujiaVillageMod.WUJIA_DIM)) return;

        ItemStack cabbage = new ItemStack(ModItems.WU_CABBAGE.get(), 8);
        player.addItem(cabbage);
        player.sendSystemMessage(Component.translatable("message.wujia_village.arrive"));

        // 首次进门：吴家大礼包
        if (!player.getPersistentData().getBoolean("wujia_kit")) {
            player.getPersistentData().putBoolean("wujia_kit", true);
            player.addItem(new ItemStack(ModItems.WU_SWORD.get()));
            player.addItem(new ItemStack(ModItems.WU_HELMET.get()));
            player.addItem(new ItemStack(ModItems.WU_CHESTPLATE.get()));
            player.addItem(new ItemStack(ModItems.WU_LEGGINGS.get()));
            player.addItem(new ItemStack(ModItems.WU_BOOTS.get()));
            ItemStack elixirs = new ItemStack(ModItems.WU_ELIXIR.get(), 16);
            player.addItem(elixirs);
            player.addItem(new ItemStack(ModItems.WILD_DOG_MILK.get()));
            ItemStack clouds = new ItemStack(ModItems.CLOUD_BLOCK.get(), 32);
            player.addItem(clouds);
            player.addItem(new ItemStack(ModItems.WU_CELL.get()));
            player.addItem(new ItemStack(ModItems.WU_BROOM.get()));
            player.sendSystemMessage(Component.translatable("message.wujia_village.kit"));
            player.sendSystemMessage(Component.translatable("message.wujia_village.kit2"));
        }
    }

    // ------------------------------------------------------------------
    // 维度内吃喝加成：食物与药水都会变得极强
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onItemFinish(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!player.level().dimension().equals(WujiaVillageMod.WUJIA_DIM)) return;

        ItemStack used = event.getItem();
        if (used.isEdible() && !(used.getItem() instanceof PotionItem)) {
            // 在吴家村吃饭：饭菜里都是宇宙本源
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 2));
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 1));
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 3));
        } else if (used.getItem() instanceof PotionItem) {
            // 在吴家村喝药水：效果翻倍再翻倍
            for (MobEffectInstance inst : PotionUtils.getMobEffects(used)) {
                player.addEffect(new MobEffectInstance(inst.getEffect(),
                        Math.min(inst.getDuration() * 2, 9600),
                        Math.min(inst.getAmplifier() + 2, 9)));
            }
        }
    }

    // ------------------------------------------------------------------
    // 服务器启动自检：数据包内容验证（写错不崩服，只会静默失效，必须主动查）
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent event) {
        var server = event.getServer();
        var registry = server.registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE);
        var holder = registry.getHolder(ModDamageTypes.WU_STRIKE);
        boolean inTag = registry.getTag(net.minecraft.tags.DamageTypeTags.BYPASSES_ARMOR)
                .map(set -> holder.map(set::contains).orElse(false))
                .orElse(false);
        if (holder.isPresent() && inTag) {
            LOGGER.info("[WujiaVillage] 伤害类型 wu_strike 已注册并挂入 bypasses_armor（吴家神剑穿甲生效）");
        } else {
            LOGGER.warn("[WujiaVillage] wu_strike 未注册或未穿甲！holder={}, inTag={}", holder.isPresent(), inTag);
        }

        boolean dimOk = server.getLevel(WujiaVillageMod.WUJIA_DIM) != null;
        LOGGER.info("[WujiaVillage] 吴家村维度 {}", dimOk ? "已就绪，全村老祖恭候大驾" : "加载失败！");
        if (dimOk) {
            server.getLevel(WujiaVillageMod.WUJIA_DIM).setDefaultSpawnPos(WujiaVillageLayout.PLAYER_SPAWN, 180.0f);
        }
        if (Boolean.getBoolean("wujia.selftest") || "true".equalsIgnoreCase(System.getenv("WUJIA_SELFTEST"))) {
            WujiaSelfTest.finish(server);
        }
    }
}
