package com.wujiacun.wujia.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 吴家灵丹：老祖吐口唾沫就能把恒星重新点亮，这丹药不过尔尔。
 */
public class WuElixirItem extends Item {
    public WuElixirItem() {
        super(new Properties().rarity(Rarity.RARE).food(new FoodProperties.Builder()
                .nutrition(20)
                .saturationMod(1.4f)
                .alwaysEat()
                .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 4), 1.0f)
                .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 9), 1.0f)
                .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 2400, 2), 1.0f)
                .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2400, 1), 1.0f)
                .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2400, 0), 1.0f)
                .build()));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wu_elixir.tooltip").withStyle(ChatFormatting.GOLD));
    }
}
