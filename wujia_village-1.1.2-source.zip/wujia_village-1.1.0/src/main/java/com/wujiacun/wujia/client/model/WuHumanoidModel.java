package com.wujiacun.wujia.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.wujiacun.wujia.entity.GhostVillagerEntity;
import com.wujiacun.wujia.entity.WuVillagerBase;
import com.wujiacun.wujia.entity.combat.CombatAction;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/** Wide-player UVs, including jacket/sleeves/pants. Combat never uses vanilla attack/sprint swings. */
public class WuHumanoidModel<T extends Mob> extends PlayerModel<T> {
    private final ModelPart root;
    private float renderAlpha = 1.0f;

    public WuHumanoidModel(ModelPart root) {
        super(root, false);
        this.root = root;
    }

    public void setRenderAlpha(float alpha) {
        renderAlpha = Mth.clamp(alpha, 0.0f, 1.0f);
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                               float red, float green, float blue, float alpha) {
        super.renderToBuffer(pose, vertices, light, overlay, red, green, blue, alpha * renderAlpha);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbAmount, float ageInTicks,
                          float headYaw, float headPitch) {
        // Models are shared by every entity of a renderer: reset translation AND rotation each call.
        root.getAllParts().forEach(ModelPart::resetPose);
        attackTime = 0.0f;
        swimAmount = 0.0f;
        crouching = false;
        rightArmPose = entity.getMainHandItem().isEmpty() ? ArmPose.EMPTY : ArmPose.ITEM;
        leftArmPose = entity.getOffhandItem().isEmpty() ? ArmPose.EMPTY : ArmPose.ITEM;
        super.setupAnim(entity, 0.0f, 0.0f, ageInTicks, headYaw, headPitch);

        float step = Mth.cos(limbSwing * 0.55f) * 0.23f * Math.min(1.0f, limbAmount * 2.0f);
        rightLeg.xRot = step;
        leftLeg.xRot = -step;
        rightArm.xRot = -step * 0.55f - (entity.getMainHandItem().isEmpty() ? 0.0f : 0.28f);
        leftArm.xRot = step * 0.55f - (entity.getOffhandItem().isEmpty() ? 0.0f : 0.28f);
        rightArm.zRot = 0.035f;
        leftArm.zRot = -0.035f;

        CombatAction action = CombatAction.IDLE;
        float age = 0.0f;
        int duration = 24;
        if (entity instanceof WuVillagerBase villager) {
            action = villager.getCombatAction();
            age = villager.getActionAge(Mth.clamp(ageInTicks - entity.tickCount, 0.0f, 1.0f));
            duration = villager.getActionDuration();
        } else if (entity instanceof GhostVillagerEntity ghost) {
            action = ghost.getGhostAction();
            age = ghost.getGhostActionAge(); // Frozen source pose, not the ghost lifetime.
            duration = ghostDuration(action);
        }
        if (action != CombatAction.IDLE) animateAction(action, age, Math.max(1, duration), ageInTicks);
        hat.copyFrom(head);
        jacket.copyFrom(body);
        rightSleeve.copyFrom(rightArm);
        leftSleeve.copyFrom(leftArm);
        rightPants.copyFrom(rightLeg);
        leftPants.copyFrom(leftLeg);
    }

    private void animateAction(CombatAction action, float age, int duration, float clock) {
        // Contact occurs on the same integer tick as the server's damage, not at half of a sine wave.
        float contact = Math.max(1, Math.round(duration * 0.45f));
        float windEnd = contact * 0.65f;
        float[] wind;
        float[] hit;
        switch (action) {
            case MELEE_JAB -> {
                wind = pose(-0.65f, -0.65f, 0.35f, -0.9f, 0.3f, -0.3f, 0.08f, -0.3f, 0, 0.1f, -0.12f);
                hit = pose(-1.56f, 0.06f, 0, -0.9f, 0.25f, -0.4f, 0.14f, 0.2f, 0, -0.28f, 0.3f);
            }
            case MELEE_SWEEP -> {
                wind = pose(-1.1f, -1.25f, 0.4f, -0.7f, 0.3f, -0.5f, 0.04f, -0.65f, 0, 0.15f, -0.2f);
                hit = pose(-1.3f, 1.05f, -0.15f, -0.9f, 0.3f, -0.5f, 0.12f, 0.65f, 0, -0.25f, 0.25f);
            }
            case MELEE_OVERHEAD -> {
                wind = pose(-2.95f, -0.2f, 0.22f, -2.65f, 0.2f, -0.22f, -0.18f, -0.08f, 0, 0.18f, -0.15f);
                hit = pose(-1.15f, 0.08f, 0.1f, -1.35f, -0.08f, -0.1f, 0.4f, 0.12f, 0, -0.35f, 0.4f);
            }
            case MELEE_THRUST -> {
                wind = pose(-0.65f, -0.9f, 0.15f, -1.0f, 0.5f, -0.2f, -0.08f, -0.4f, 0, 0.25f, -0.3f);
                hit = pose(-1.7f, 0.02f, 0.02f, -1.55f, 0.3f, -0.12f, 0.25f, 0.15f, 0, -0.4f, 0.35f);
            }
            case BLINK -> {
                // 端正挺拔的末影大师身法姿态：摒弃怪异蹲地动作，保持身姿挺拔从容
                float progress = Mth.clamp(age / duration, 0, 1);
                float factor = progress < 0.4f ? smooth(progress / 0.4f)
                        : 1.0f - smooth((progress - 0.5f) / 0.5f);
                rightArm.xRot = -0.45f * factor;
                rightArm.yRot = -0.25f * factor;
                leftArm.xRot = -0.3f * factor;
                leftArm.yRot = 0.2f * factor;
                return;
            }
            case DODGE -> {
                // 闪身步专属动作：侧身伏低重心、前臂护体、后臂展衡、两腿滑步疾闪
                float progress = Mth.clamp(age / duration, 0, 1);
                float factor = progress < 0.35f ? smooth(progress / 0.35f)
                        : 1.0f - smooth((progress - 0.45f) / 0.55f);

                body.xRot = 0.2f * factor;
                body.yRot = -0.32f * factor;
                body.zRot = 0.28f * factor;
                head.yRot = 0.32f * factor;

                rightArm.xRot = -0.95f * factor;
                rightArm.yRot = -0.42f * factor;
                rightArm.zRot = 0.35f * factor;
                leftArm.xRot = 0.65f * factor;
                leftArm.yRot = 0.25f * factor;
                leftArm.zRot = -0.45f * factor;

                rightLeg.xRot = -0.55f * factor;
                rightLeg.zRot = 0.2f * factor;
                leftLeg.xRot = 0.55f * factor;
                leftLeg.zRot = -0.2f * factor;

                for (ModelPart part : new ModelPart[]{head, body, rightArm, leftArm, rightLeg, leftLeg}) {
                    part.y += 1.2f * factor;
                }
                return;
            }
            case HIM_FLIGHT -> {
                float lift = smooth(age / 6.0f);
                body.xRot = -0.08f * lift;
                rightArm.xRot = -0.3f * lift;
                leftArm.xRot = -0.3f * lift;
                rightArm.zRot = (0.42f + Mth.sin(clock * 0.08f) * 0.035f) * lift;
                leftArm.zRot = -rightArm.zRot;
                rightLeg.xRot = 0.14f * lift;
                leftLeg.xRot = -0.1f * lift;
                rightLeg.zRot = 0.08f * lift;
                leftLeg.zRot = -0.08f * lift;
                return;
            }
            default -> {
                // Two-handed gathering and release: distinct silhouette for every spell.
                contact = switch (action) {
                    case SONIC -> 12;
                    case WATER -> 11;
                    case SWORDS -> 15;
                    case PALM -> 18;
                    case BLACK_HOLE -> 20;
                    default -> Math.max(1, duration * 0.45f);
                };
                windEnd = contact * 0.7f;
                wind = pose(-1.0f, -0.65f, 0.1f, -1.0f, 0.65f, -0.1f, -0.08f, 0, 0, 0.08f, -0.08f);
                hit = switch (action) {
                    case SONIC -> pose(-1.57f, -0.3f, 0.05f, -1.57f, 0.3f, -0.05f, 0.15f, 0, 0, -0.2f, 0.2f);
                    case PALM -> pose(-2.7f, -0.18f, 0.2f, -2.7f, 0.18f, -0.2f, -0.14f, 0, 0, 0, 0);
                    case SWORDS -> pose(-1.9f, -0.8f, 0.5f, -1.9f, 0.8f, -0.5f, -0.06f, 0, 0, -0.1f, 0.1f);
                    case WATER -> pose(-1.4f, -0.22f, 0.12f, -1.4f, 0.22f, -0.12f, 0.16f, 0, 0, -0.16f, 0.16f);
                    case BLACK_HOLE -> pose(-2.1f, -0.4f, 0.35f, -2.1f, 0.4f, -0.35f, -0.1f, 0, 0, -0.1f, 0.1f);
                    default -> wind;
                };
            }
        }
        float[] idle = pose(rightArm.xRot, rightArm.yRot, rightArm.zRot, leftArm.xRot, leftArm.yRot,
                leftArm.zRot, body.xRot, body.yRot, body.zRot, rightLeg.xRot, leftLeg.xRot);
        float[] result;
        if (age < windEnd) result = mix(idle, wind, smooth(age / Math.max(1, windEnd)));
        else if (age < contact) result = mix(wind, hit, smooth((age - windEnd) / Math.max(1, contact - windEnd)));
        else {
            // A short readable contact hold, then recover without an abrupt pose reset.
            float recover = smooth((age - contact - 2) / Math.max(1, duration - contact - 2));
            result = mix(hit, idle, recover);
        }
        rightArm.setRotation(result[0], result[1], result[2]);
        leftArm.setRotation(result[3], result[4], result[5]);
        body.setRotation(result[6], result[7], result[8]);
        rightLeg.xRot = result[9];
        leftLeg.xRot = result[10];
        // Rotate shoulder anchors with the torso, keeping held items attached to the fists.
        rightArm.x = -5.0f * Mth.cos(body.yRot);
        rightArm.z = 5.0f * Mth.sin(body.yRot);
        leftArm.x = -rightArm.x;
        leftArm.z = -rightArm.z;
    }

    private static float[] pose(float... values) { return values; }
    private static float smooth(float value) {
        float v = Mth.clamp(value, 0, 1);
        return v * v * (3 - 2 * v);
    }
    private static float[] mix(float[] a, float[] b, float t) {
        float[] result = new float[a.length];
        for (int i = 0; i < result.length; i++) result[i] = Mth.lerp(t, a[i], b[i]);
        return result;
    }

    private static int ghostDuration(CombatAction action) {
        // Ghost snapshots have no duration getter; this table mirrors the server action durations.
        return switch (action) {
            case MELEE_JAB -> 14;
            case MELEE_SWEEP -> 22;
            case MELEE_OVERHEAD -> 26;
            case MELEE_THRUST -> 18;
            case BLINK -> 14;
            case SONIC -> 28;
            case WATER -> 24;
            case SWORDS -> 34;
            case PALM -> 40;
            case HIM_FLIGHT -> 36;
            case DODGE -> 10;
            default -> 24;
        };
    }
}
