package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * 村口大黄——上古神兽。它一跑，时间就往回退一点；拿桶可以挤野生狗奶。
 *
 * <p>它永远不认主：骨头不收、肉不吃、项圈不戴，所以不会跟着玩家跑。
 * 但你要是动手打它，它会咬回来。空气里的战力因子，有一半是它呼出来的。</p>
 */
public class WuDogEntity extends Wolf {
    private int milkCooldown;
    private int rewindCooldown;
    private double lastX;
    private double lastZ;
    private boolean hasLast;

    public WuDogEntity(EntityType<? extends Wolf> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setTame(false);
        this.setOwnerUUID(null);
        this.setCustomName(Component.translatable("entity.wujia_village.wu_dog"));
        this.setCustomNameVisible(true);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    // 无论如何都不算被驯服，也就不会有"跟着主人跑"的逻辑
    @Override
    public boolean isTame() {
        return false;
    }

    @Override
    public void setTame(boolean tamed) {
        super.setTame(false);
    }

    @Override
    public void tame(Player player) {
        // 这条狗不跟人回家
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(Items.BONE)) {
            if (!this.level().isClientSide()) {
                player.displayClientMessage(Component.translatable("message.wujia_village.dog.bone"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (!stack.is(Items.BUCKET)) {
            // 不把交互交给原版 Wolf，避免喂肉被"驯服"
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide()) return InteractionResult.SUCCESS;
        if (this.milkCooldown > 0) {
            player.displayClientMessage(Component.translatable("message.wujia_village.dog.dry"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        ItemStack milk = new ItemStack(ModItems.WILD_DOG_MILK.get());
        if (!player.getInventory().add(milk)) player.drop(milk, false);
        this.milkCooldown = 1200;
        this.level().playSound(null, this.blockPosition(), SoundEvents.COW_MILK, SoundSource.NEUTRAL, 1.0f, 0.8f);
        return InteractionResult.CONSUME;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        if (this.milkCooldown > 0) this.milkCooldown--;
        if (this.rewindCooldown > 0) this.rewindCooldown--;
        if (!this.hasLast) {
            this.lastX = this.getX();
            this.lastZ = this.getZ();
            this.hasLast = true;
            return;
        }
        double dx = this.getX() - this.lastX;
        double dz = this.getZ() - this.lastZ;
        this.lastX = this.getX();
        this.lastZ = this.getZ();
        if (this.rewindCooldown <= 0 && dx * dx + dz * dz > 0.05 && this.level() instanceof ServerLevel server) {
            server.setDayTime(Math.max(0L, server.getDayTime() - 1500L));
            this.rewindCooldown = 400;
            server.playSound(null, this.blockPosition(), SoundEvents.WOLF_AMBIENT, SoundSource.NEUTRAL, 0.8f, 0.7f);
            AABB box = this.getBoundingBox().inflate(32.0);
            for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class, box)) {
                player.displayClientMessage(Component.translatable("message.wujia_village.dog.rewind"), true);
            }
        }
    }

    @Override
    public boolean isAngry() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("WujiaMilk", this.milkCooldown);
        tag.putInt("WujiaRewind", this.rewindCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.milkCooldown = tag.getInt("WujiaMilk");
        this.rewindCooldown = tag.getInt("WujiaRewind");
        this.setTame(false);
        this.setOwnerUUID(null);
    }
}
