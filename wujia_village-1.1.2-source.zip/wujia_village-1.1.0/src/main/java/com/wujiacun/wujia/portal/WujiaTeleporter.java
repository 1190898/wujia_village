package com.wujiacun.wujia.portal;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.registry.ModBlocks;
import com.wujiacun.wujia.world.WujiaVillageLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.util.ITeleporter;

import java.util.function.Function;

/**
 * 进村落在村口石碑前的地面上。不再把人扔到一百多格的高空，
 * 也不在传送过程里到处量地形高度。
 */
public class WujiaTeleporter implements ITeleporter {
    public static final String RETURN_X = "WujiaReturnX";
    public static final String RETURN_Y = "WujiaReturnY";
    public static final String RETURN_Z = "WujiaReturnZ";
    public static final String RETURN_SET = "WujiaReturnSet";

    @Override
    public Entity placeEntity(Entity entity, ServerLevel currentLevel, ServerLevel destLevel,
                              float yaw, Function<Boolean, Entity> repositionEntity) {
        boolean entering = destLevel.dimension().equals(WujiaVillageMod.WUJIA_DIM);
        Entity moved = repositionEntity.apply(false);
        if (entering) {
            landInVillage(destLevel, moved);
        } else {
            landInOverworld(destLevel, moved);
        }
        return moved;
    }

    private static void landInVillage(ServerLevel level, Entity entity) {
        BlockPos spawn = WujiaVillageLayout.PLAYER_SPAWN;
        ChunkPos chunk = new ChunkPos(spawn);
        level.getChunkSource().addRegionTicket(net.minecraft.server.level.TicketType.PORTAL, chunk, 3, spawn);
        level.getChunk(chunk.x, chunk.z);
        ensureGate(level);
        entity.teleportTo(spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5);
        entity.setYRot(180.0f);
        entity.setXRot(-12.0f);
        entity.setYHeadRot(180.0f);
        entity.fallDistance = 0.0f;
        entity.setDeltaMovement(0.0, 0.0, 0.0);
        if (entity instanceof ServerPlayer player) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 160, 0, false, false, true));
        }
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                spawn.getX() + 0.5, spawn.getY() + 1.0, spawn.getZ() + 0.5,
                12, 0.6, 0.4, 0.6, 0.0);
    }

    private static void landInOverworld(ServerLevel level, Entity entity) {
        CompoundTag data = entity.getPersistentData();
        BlockPos saved;
        if (data.getBoolean(RETURN_SET)) {
            saved = new BlockPos(data.getInt(RETURN_X), data.getInt(RETURN_Y), data.getInt(RETURN_Z));
        } else {
            saved = level.getSharedSpawnPos();
        }
        level.getChunkSource().addRegionTicket(net.minecraft.server.level.TicketType.PORTAL, new ChunkPos(saved), 3, saved);
        level.getChunk(saved.getX() >> 4, saved.getZ() >> 4);
        BlockPos stand = findStand(level, saved);
        entity.teleportTo(stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5);
        entity.fallDistance = 0.0f;
        entity.setDeltaMovement(0.0, 0.0, 0.0);
    }

    private static BlockPos findStand(ServerLevel level, BlockPos origin) {
        BlockPos[] spots = {
                origin.relative(Direction.SOUTH, 2),
                origin.relative(Direction.NORTH, 2),
                origin.relative(Direction.EAST, 2),
                origin.relative(Direction.WEST, 2),
                origin
        };
        for (BlockPos spot : spots) {
            BlockPos stand = standable(level, spot);
            if (stand != null) return stand;
        }
        return new BlockPos(origin.getX(), Mth.clamp(origin.getY(), level.getMinBuildHeight() + 2, level.getMaxBuildHeight() - 3), origin.getZ());
    }

    private static BlockPos standable(ServerLevel level, BlockPos column) {
        int y = Mth.clamp(column.getY(), level.getMinBuildHeight() + 2, level.getMaxBuildHeight() - 3);
        for (int dy = 3; dy >= -8; dy--) {
            int yy = y + dy;
            if (yy <= level.getMinBuildHeight() + 1 || yy >= level.getMaxBuildHeight() - 2) continue;
            BlockPos feet = new BlockPos(column.getX(), yy, column.getZ());
            BlockState floor = level.getBlockState(feet.below());
            BlockState body = level.getBlockState(feet);
            BlockState head = level.getBlockState(feet.above());
            if (floor.blocksMotion() && !body.blocksMotion() && !head.blocksMotion()
                    && !body.is(ModBlocks.WUJIA_PORTAL.get())) {
                return feet;
            }
        }
        return null;
    }

    private static void ensureGate(ServerLevel level) {
        int z = WujiaVillageLayout.PORTAL_Z;
        BlockPos interior = new BlockPos(0, WujiaVillageLayout.SURFACE + 1, z);
        if (level.getBlockState(interior).is(ModBlocks.WUJIA_PORTAL.get())) return;
        for (int x = -1; x <= 2; x++) {
            for (int y = WujiaVillageLayout.SURFACE; y <= WujiaVillageLayout.SURFACE + 4; y++) {
                level.setBlock(new BlockPos(x, y, z), WujiaVillageLayout.blockAt(x, y, z), 2);
            }
        }
    }
}
