package com.wujiacun.wujia.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;

/** One terminal, conservative migration attempt per recognized complete house. */
public final class VillageFurnitureData extends SavedData {
    public static final String DATA_NAME = "wujia_furniture_v2";
    private final Map<String, String> outcomes = new HashMap<>();

    public static VillageFurnitureData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(VillageFurnitureData::load,
                VillageFurnitureData::new, DATA_NAME);
    }

    public boolean processed(String id) { return outcomes.containsKey(id); }
    public String outcome(String id) { return outcomes.getOrDefault(id, ""); }

    public void record(String id, String outcome) {
        if (outcomes.putIfAbsent(id, outcome) == null) setDirty();
    }

    public static VillageFurnitureData load(CompoundTag tag) {
        VillageFurnitureData data = new VillageFurnitureData();
        ListTag entries = tag.getList("Houses", Tag.TAG_COMPOUND);
        for (int i = 0; i < entries.size(); i++) {
            CompoundTag entry = entries.getCompound(i);
            data.outcomes.put(entry.getString("Id"), entry.getString("Outcome"));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("Version", 2);
        ListTag entries = new ListTag();
        outcomes.forEach((id, outcome) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("Id", id);
            entry.putString("Outcome", outcome);
            entries.add(entry);
        });
        tag.put("Houses", entries);
        return tag;
    }
}
