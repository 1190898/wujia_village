package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.util.ModDamageTypes;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 钓鱼村民：玩家骨架，手持钓竿。
 * 水里回血、水下呼吸；远程甩出「水线」造成击退与短暂缓慢。
 */
public class FisherVillagerEntity extends WuVillagerBase implements RangedAttackMob {

    private int castCooldown;

    public FisherVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.fisher_villager");
        this.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.FISHING_ROD));
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.fisher";
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // Ranged actions are scheduled by the unified server controller.
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        if (this.castCooldown > 0) this.castCooldown--;

        if (this.isInWaterOrRain()) {
            this.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 40, 0, true, false));
            this.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 40, 0, true, false));
            if (this.tickCount % 20 == 0) this.heal(4.0f);
        }

        if (this.tickCount % 16 == 0 && this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.FISHING,
                    this.getX(), this.getY() + 1.1, this.getZ(), 2, 0.2, 0.2, 0.2, 0.0);
        }
    }

    @Override
    public void performRangedAttack(LivingEntity target, float power) {
        getCombatController().requestRanged(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInWaterOrRain()) amount *= 0.65f;
        return super.hurt(source, amount);
    }
}
