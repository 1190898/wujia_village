package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.entity.combat.WuCombatRules;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 闪身步村民：拥有真正的武学身法闪避动作（DODGE），不再采用简陋瞬移。
 * 受到箭矢或近战攻击时侧伏滑步疾闪、气劲破空、原地留残影，潇洒躲过攻击。
 */
public class DodgeVillagerEntity extends WuVillagerBase {
    public DodgeVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.dodge_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.dodge";
    }

    public void dodgeStep() {
        requestDodge();
    }

    public boolean requestDodge() {
        LivingEntity threat = getTarget();
        if (threat == null) threat = level().getNearestPlayer(this, 12);
        Vec3 away;
        if (threat != null) {
            away = position().subtract(threat.position());
        } else {
            away = getLookAngle().scale(-1);
        }
        if (away.horizontalDistanceSqr() < 0.001) away = new Vec3(1, 0, 0);
        away = new Vec3(away.x, 0, away.z).normalize();

        // 优先左右横跨滑步，其次斜后撤步
        boolean left = random.nextBoolean();
        Vec3 side = new Vec3(-away.z, 0, away.x).scale(left ? 2.8 : -2.8);
        Vec3 target = position().add(side).add(away.scale(0.6));

        if (!WuCombatRules.safeBlink(this, target)) {
            // 尝试反向侧闪
            target = position().subtract(side).add(away.scale(0.6));
            if (!WuCombatRules.safeBlink(this, target)) {
                // 尝试正后撤步
                target = position().add(away.scale(2.5));
                if (!WuCombatRules.safeBlink(this, target)) return false;
            }
        }
        return getCombatController().requestDodge(target);
    }

    public boolean tryDodgeAttack() {
        return random.nextFloat() < 0.75f && requestDodge();
    }

    @Override
    public net.minecraft.world.InteractionResult mobInteract(Player player, net.minecraft.world.InteractionHand hand) {
        var res = super.mobInteract(player, hand);
        if (!level().isClientSide() && !getCombatController().busy()) {
            requestDodge();
        }
        return res;
    }
}
