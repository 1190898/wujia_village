package com.wujiacun.wujia.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 路边的石头。左键去踢，它会把人弹开。
 */
public class WujiaStoneBlock extends Block {
    public WujiaStoneBlock() {
        super(Properties.of()
                .sound(SoundType.STONE)
                .strength(2.5f, 6.0f)
                .requiresCorrectToolForDrops());
    }

    @Override
    public void attack(BlockState state, Level level, BlockPos pos, Player player) {
        if (level.isClientSide()) return;
        int now = player.tickCount;
        int last = player.getPersistentData().contains("WujiaStoneKick")
                ? player.getPersistentData().getInt("WujiaStoneKick") : -100;
        if (now - last < 8) return;
        player.getPersistentData().putInt("WujiaStoneKick", now);
        player.knockback(0.7, pos.getX() + 0.5 - player.getX(), pos.getZ() + 0.5 - player.getZ());
        player.hurtMarked = true;
        if (player.getHealth() > 6.0f) {
            player.hurt(level.damageSources().generic(), 1.0f);
        }
        player.displayClientMessage(Component.translatable("message.wujia_village.stone.kick"), true);
    }
}
