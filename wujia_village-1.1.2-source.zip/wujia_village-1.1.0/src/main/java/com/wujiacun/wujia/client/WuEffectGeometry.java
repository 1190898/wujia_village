package com.wujiacun.wujia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/** Depth-tested translucent geometry: no wall-penetrating render states or client hitboxes. */
final class WuEffectGeometry {
    static final ResourceLocation WHITE = new ResourceLocation(WujiaVillageMod.MODID, "textures/entity/skill_white.png");
    private WuEffectGeometry() {}

    static VertexConsumer buffer(MultiBufferSource source) {
        return source.getBuffer(RenderType.entityTranslucent(WHITE));
    }

    static void ring(PoseStack pose, VertexConsumer out, Vec3 center, Vec3 normal, double radius,
                     double thickness, int tint, float alpha) {
        Vec3 axis = normal.lengthSqr() < 0.0001 ? new Vec3(0, 1, 0) : normal.normalize();
        Vec3 u = perpendicular(axis), v = axis.cross(u).normalize();
        for (int i = 0; i < 48; i++) {
            double a = i * Math.PI * 2 / 48, b = (i + 1) * Math.PI * 2 / 48;
            Vec3 da = u.scale(Math.cos(a)).add(v.scale(Math.sin(a)));
            Vec3 db = u.scale(Math.cos(b)).add(v.scale(Math.sin(b)));
            quad(pose, out, center.add(da.scale(Math.max(0, radius - thickness))),
                    center.add(da.scale(radius)), center.add(db.scale(radius)),
                    center.add(db.scale(Math.max(0, radius - thickness))), tint, alpha);
        }
    }

    static void tube(PoseStack pose, VertexConsumer out, Vec3 start, Vec3 end, double r0, double r1,
                     int tint, float alpha) {
        Vec3 delta = end.subtract(start);
        if (delta.lengthSqr() < 0.00001) return;
        Vec3 axis = delta.normalize(), u = perpendicular(axis), v = axis.cross(u).normalize();
        for (int i = 0; i < 10; i++) {
            double a = i * Math.PI * 2 / 10, b = (i + 1) * Math.PI * 2 / 10;
            Vec3 da = u.scale(Math.cos(a)).add(v.scale(Math.sin(a)));
            Vec3 db = u.scale(Math.cos(b)).add(v.scale(Math.sin(b)));
            quad(pose, out, start.add(da.scale(r0)), end.add(da.scale(r1)),
                    end.add(db.scale(r1)), start.add(db.scale(r0)), tint, alpha);
        }
    }

    static Vec3 perpendicular(Vec3 normal) {
        return normal.cross(Math.abs(normal.y) > 0.92 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize();
    }

    static int brighten(int tint, float amount) {
        int r = (tint >> 16) & 255, g = (tint >> 8) & 255, b = tint & 255;
        return ((int) (r + (255 - r) * amount) << 16)
                | ((int) (g + (255 - g) * amount) << 8) | (int) (b + (255 - b) * amount);
    }

    private static void quad(PoseStack pose, VertexConsumer out, Vec3 a, Vec3 b, Vec3 c, Vec3 d,
                             int tint, float alpha) {
        Vec3 normal = b.subtract(a).cross(c.subtract(a)).normalize();
        vertex(pose, out, a, normal, tint, alpha, 0, 0);
        vertex(pose, out, b, normal, tint, alpha, 0, 1);
        vertex(pose, out, c, normal, tint, alpha, 1, 1);
        vertex(pose, out, d, normal, tint, alpha, 1, 0);
    }

    private static void vertex(PoseStack pose, VertexConsumer out, Vec3 point, Vec3 normal,
                               int tint, float alpha, float u, float v) {
        out.vertex(pose.last().pose(), (float) point.x, (float) point.y, (float) point.z)
                .color(((tint >> 16) & 255) / 255.0f, ((tint >> 8) & 255) / 255.0f,
                        (tint & 255) / 255.0f, alpha)
                .uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(pose.last().normal(), (float) normal.x, (float) normal.y, (float) normal.z).endVertex();
    }
}
