package com.wujiacun.wujia.registry;

import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WujiaVillageMod.MODID);

    public static final RegistryObject<CreativeModeTab> WUJIA_TAB =
            TABS.register("wujia_tab", () -> CreativeModeTab.builder()
                    .icon(() -> new ItemStack(ModItems.WU_CELL.get()))
                    .title(Component.translatable("itemGroup.wujia_village"))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.WU_CELL.get());
                        output.accept(ModItems.CLOUD_BLOCK.get());
                        output.accept(ModItems.WU_SWORD.get());
                        output.accept(ModItems.WU_HELMET.get());
                        output.accept(ModItems.WU_CHESTPLATE.get());
                        output.accept(ModItems.WU_LEGGINGS.get());
                        output.accept(ModItems.WU_BOOTS.get());
                        output.accept(ModItems.WU_ELIXIR.get());
                        output.accept(ModItems.WILD_DOG_MILK.get());
                        output.accept(ModItems.WU_CABBAGE.get());
                        output.accept(ModItems.WU_BROOM.get());
                        output.accept(ModItems.WUJIA_STELE.get());
                        output.accept(ModItems.WUJIA_STONE.get());
                        output.accept(ModItems.DODGE_VILLAGER_EGG.get());
                        output.accept(ModItems.TELEPORT_VILLAGER_EGG.get());
                        output.accept(ModItems.CHIEF_VILLAGER_EGG.get());
                        output.accept(ModItems.ANCESTOR_VILLAGER_EGG.get());
                        output.accept(ModItems.SWEEPER_VILLAGER_EGG.get());
                        output.accept(ModItems.GUARD_VILLAGER_EGG.get());
                        output.accept(ModItems.FISHER_VILLAGER_EGG.get());
                        output.accept(ModItems.WU_CHICKEN_EGG.get());
                        output.accept(ModItems.WU_DOG_EGG.get());
                        output.accept(ModItems.HIM_VILLAGER_EGG.get());
                        output.accept(ModItems.HIM_DRAGON_EGG.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}
