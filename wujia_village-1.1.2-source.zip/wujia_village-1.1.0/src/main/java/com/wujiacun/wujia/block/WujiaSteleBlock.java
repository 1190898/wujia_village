package com.wujiacun.wujia.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * 村口石碑。右键把碑文念出来。上下两格是同一块碑。
 */
public class WujiaSteleBlock extends Block {
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;
    private static final VoxelShape SHAPE = Block.box(2.0, 0.0, 6.0, 14.0, 16.0, 10.0);
    private static boolean breakingPair;

    private static final String[] LINES = {
            "message.wujia_village.stele.1",
            "message.wujia_village.stele.2",
            "message.wujia_village.stele.3",
            "message.wujia_village.stele.4",
            "message.wujia_village.stele.5",
            "message.wujia_village.stele.6",
            "message.wujia_village.stele.7",
            "message.wujia_village.stele.8",
            "message.wujia_village.stele.9",
            "message.wujia_village.stele.10"
    };

    public WujiaSteleBlock() {
        super(Properties.of()
                .sound(SoundType.STONE)
                .strength(8.0f, 1200.0f)
                .requiresCorrectToolForDrops());
        this.registerDefaultState(this.stateDefinition.any().setValue(HALF, DoubleBlockHalf.LOWER));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HALF);
    }

    @Override
    public VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    @Nullable
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockPos above = ctx.getClickedPos().above();
        if (!ctx.getLevel().getBlockState(above).canBeReplaced(ctx)) return null;
        if (above.getY() >= ctx.getLevel().getMaxBuildHeight()) return null;
        return this.defaultBlockState().setValue(HALF, DoubleBlockHalf.LOWER);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.above(), state.setValue(HALF, DoubleBlockHalf.UPPER), 3);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!breakingPair && !level.isClientSide() && !state.is(newState.getBlock())) {
            BlockPos other = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos.above() : pos.below();
            if (level.getBlockState(other).is(this)) {
                breakingPair = true;
                try {
                    level.removeBlock(other, false);
                } finally {
                    breakingPair = false;
                }
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide()) {
            for (String line : LINES) {
                player.sendSystemMessage(Component.translatable(line));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }
}
