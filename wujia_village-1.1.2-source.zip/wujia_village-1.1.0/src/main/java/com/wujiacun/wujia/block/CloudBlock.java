package com.wujiacun.wujia.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 云朵方块 —— 吴家村的门框材料。
 * 一砖一瓦都蕴含着宇宙本源的力量（但摸起来像羊毛）。
 */
public class CloudBlock extends Block {
    public CloudBlock() {
        super(Properties.of()
                .sound(SoundType.WOOL)
                .strength(0.6f)
                .lightLevel(state -> 7));
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0f;
    }
}
