package com.wujiacun.wujia.client;

import com.wujiacun.wujia.WujiaVillageMod;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/** 村子的天色偏暖，好让头顶那颗锈红色方星被认出来。 */
@OnlyIn(Dist.CLIENT)
public class WujiaSkyEffects extends DimensionSpecialEffects {
    public WujiaSkyEffects() {
        super(220.0F, true, SkyType.NORMAL, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 color, float brightness) {
        float scale = brightness * 0.94F + 0.06F;
        return color.multiply(scale, scale * 0.96F, scale * 0.88F);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return false;
    }
}
