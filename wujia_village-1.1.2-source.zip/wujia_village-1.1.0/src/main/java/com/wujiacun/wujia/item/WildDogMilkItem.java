package com.wujiacun.wujia.item;

import net.minecraft.ChatFormatting;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MilkBucketItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 野生狗奶：产自吴家村路边的一条野狗，野生狗奶的永恒之源。
 * 喝一口，负面效果全消，还附赠吴家级别的庇佑。
 */
public class WildDogMilkItem extends MilkBucketItem {
    public WildDogMilkItem() {
        super(new Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity); // 先像奶桶一样清空所有效果

        // 再补上吴家庇佑
        if (!level.isClientSide()) {
            entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 3));
            entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 4));
            entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 1));
            entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            entity.heal(entity.getMaxHealth() * 0.25f);
        }
        if (entity instanceof ServerPlayer sp) {
            CriteriaTriggers.CONSUME_ITEM.trigger(sp, stack);
            sp.awardStat(Stats.ITEM_USED.get(this));
            level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.WARDEN_ROAR, SoundSource.PLAYERS, 0.5f, 1.6f);
            sp.sendSystemMessage(Component.literal("§b[吴家村]§f 一口野生狗奶下肚，你感觉自己能硬扛盘古三斧。"));
        }
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wild_dog_milk.tooltip").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("item.wujia_village.wild_dog_milk.tooltip2").withStyle(ChatFormatting.GRAY));
    }
}
