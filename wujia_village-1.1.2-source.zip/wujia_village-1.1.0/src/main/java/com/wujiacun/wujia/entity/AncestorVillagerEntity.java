package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/** Hovering ancestor. Attacks now have visible windup/contact/recovery, never passive instant kills. */
public class AncestorVillagerEntity extends WuVillagerBase {
    public AncestorVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.ancestor_villager");
        setNoGravity(true);
    }
    @Override protected String greetKey() { return "message.wujia_village.greet.ancestor"; }
    @Override public void tick() {
        super.tick();
        // Cosmetic hovering only: no independent upward velocity fighting the controller/floor checks.
        if (level() instanceof ServerLevel sl && tickCount % 6 == 0) {
            sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.4, getZ(), 2, 0.6, 0.8, 0.6, 0.02);
            if (tickCount % 12 == 0) {
                sl.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 0.8, getZ(), 4, 0.4, 0.6, 0.4, 0.05);
            }
        }
    }
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide() && source.getEntity() instanceof LivingEntity attacker) {
            if (level() instanceof ServerLevel sl && getRandom().nextFloat() < 0.35f) {
                // 翻身震慑：遭受攻击时概率直接发动归墟黑洞
                WuSkillEffectEntity.spawnBlackHole(sl, this, attacker.position(), getSkillTint(), 600.0f);
            }
        }
        return hit;
    }
}
