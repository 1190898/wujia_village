package com.wujiacun.wujia.entity.ai;

import com.wujiacun.wujia.entity.WuVillagerBase;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;

/** Reserves movement/look while fighting or posing; cadence lives only in the server controller. */
public final class WuCombatGoal extends Goal {
    private final WuVillagerBase mob;
    public WuCombatGoal(WuVillagerBase mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }
    @Override public boolean canUse() { return mob.getCombatController().busy() || mob.getTarget() != null; }
    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public boolean requiresUpdateEveryTick() { return true; }
}
