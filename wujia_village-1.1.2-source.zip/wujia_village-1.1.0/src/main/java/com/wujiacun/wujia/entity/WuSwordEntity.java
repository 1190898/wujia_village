package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.entity.combat.WuCombatRules;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.util.ModDamageTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import java.util.UUID;

/** Real finite projectile: short orbit, staggered launch, limited steering, swept collision. */
public class WuSwordEntity extends Projectile {
    private static final EntityDataAccessor<Integer> TINT = SynchedEntityData.defineId(WuSwordEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> BIRTH = SynchedEntityData.defineId(WuSwordEntity.class, EntityDataSerializers.LONG);
    public static final int ORBIT_TICKS = 12, STAGGER_TICKS = 3, MAX_LIFETIME = 72;
    private UUID targetId;
    private int age, slot, count = 1, flightAge;
    private boolean launched;
    private float damage;

    public WuSwordEntity(EntityType<? extends WuSwordEntity> type, Level level) {
        super(type, level); setNoGravity(true);
    }
    @Override protected void defineSynchedData() {
        entityData.define(TINT, 0xFFFFFF); entityData.define(BIRTH, 0L);
    }
    public int getTint() { return entityData.get(TINT); }
    public float getSwordAge(float partialTick) { return Math.max(0, level().getGameTime() - entityData.get(BIRTH) + partialTick); }
    public ItemStack getItem() { return new ItemStack(Items.IRON_SWORD); }
    public boolean hasLaunched() { return launched; }

    public static WuSwordEntity summon(ServerLevel level, LivingEntity owner, LivingEntity target,
                                       int slot, int count, int tint, float damage) {
        if (!WuCombatRules.canHit(owner, target)) return null;
        WuSwordEntity sword = ModEntities.WU_SWORD.get().create(level);
        if (sword == null) return null;
        sword.setOwner(owner); sword.targetId = target.getUUID(); sword.slot = slot; sword.count = Math.max(1, count);
        sword.damage = damage; sword.entityData.set(TINT, tint); sword.entityData.set(BIRTH, level.getGameTime());
        sword.setPos(sword.orbitPosition(owner));
        if (!WuCombatRules.loaded(level, sword.getBoundingBox()) || !level.noCollision(sword, sword.getBoundingBox())) return null;
        level.addFreshEntity(sword);
        return sword;
    }
    private Vec3 orbitPosition(LivingEntity owner) {
        double a = slot * Math.PI * 2 / count + age * 0.16;
        return owner.position().add(Math.cos(a) * 1.15, owner.getBbHeight() * 0.7 + 0.2 * Math.sin(a * 2), Math.sin(a) * 1.15);
    }
    @Override public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel level)) {
            setPos(position().add(getDeltaMovement()));
            return;
        }
        age++;
        if (age >= MAX_LIFETIME || !(getOwner() instanceof LivingEntity owner) || !owner.isAlive()) { discard(); return; }
        Entity resolved = targetId == null ? null : level.getEntity(targetId);
        LivingEntity target = resolved instanceof LivingEntity living && WuCombatRules.canHit(owner, living) ? living : null;
        if (target == null) { discard(); return; }
        if (!launched) {
            if (age < ORBIT_TICKS + slot * STAGGER_TICKS) {
                Vec3 next = orbitPosition(owner);
                if (!moveSwept(level, owner, next, false)) return;
                pointAt(target.getEyePosition().subtract(position()));
                setDeltaMovement(Vec3.ZERO);
                return;
            }
            launched = true;
            setDeltaMovement(target.getEyePosition().subtract(position()).normalize().scale(1.15));
        }
        flightAge++;
        Vec3 velocity = getDeltaMovement();
        // Only the first ten flight ticks may steer; blend limits turning and cannot orbit forever.
        if (flightAge <= 10) {
            Vec3 desired = target.getEyePosition().subtract(position()).normalize();
            velocity = velocity.normalize().scale(0.94).add(desired.scale(0.06)).normalize().scale(1.15);
            setDeltaMovement(velocity);
        }
        pointAt(velocity);
        moveSwept(level, owner, position().add(velocity), true);
    }
    private void pointAt(Vec3 dir) {
        setYRot((float) (Mth.atan2(dir.x, dir.z) * 180 / Math.PI));
        setXRot((float) (-Mth.atan2(dir.y, dir.horizontalDistance()) * 180 / Math.PI));
    }
    private boolean moveSwept(ServerLevel level, LivingEntity owner, Vec3 to, boolean hitEntities) {
        Vec3 from = position();
        AABB sweep = getBoundingBox().expandTowards(to.subtract(from)).inflate(0.1);
        if (!WuCombatRules.loaded(level, sweep) || !level.getWorldBorder().isWithinBounds(sweep)) { discard(); return false; }
        var block = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 end = block.getLocation();
        LivingEntity nearest = null;
        Vec3 contact = null;
        double best = from.distanceToSqr(end);
        if (hitEntities) {
            for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, sweep,
                    e -> e != owner && e.isAlive() && !e.isSpectator() && !(e instanceof GhostVillagerEntity))) {
                AABB bounds = candidate.getBoundingBox().inflate(0.16);
                var point = bounds.clip(from, end);
                Vec3 p = bounds.contains(from) ? from : point.orElse(null);
                if (p != null && from.distanceToSqr(p) <= best) {
                    best = from.distanceToSqr(p); nearest = candidate; contact = p;
                }
            }
        }
        if (nearest != null) {
            setPos(contact);
            if (WuCombatRules.canHit(owner, nearest)) nearest.hurt(ModDamageTypes.wuSword(level, this, owner), damage);
            discard(); return false;
        }
        // The ray plus sampled full projectile bbox prevents skimming through block corners.
        int samples = Math.max(1, (int) Math.ceil(from.distanceTo(end) / 0.12));
        for (int i = 1; i <= samples; i++) {
            Vec3 p = from.lerp(end, i / (double) samples);
            AABB bounds = getBoundingBox().move(p.subtract(from));
            if (!level.noCollision(this, bounds)) { setPos(p); discard(); return false; }
        }
        setPos(end);
        if (block.getType() != HitResult.Type.MISS) { discard(); return false; }
        return true;
    }
    @Override public boolean isPickable() { return false; }
    @Override public void readAdditionalSaveData(CompoundTag tag) { discard(); }
    @Override public void addAdditionalSaveData(CompoundTag tag) {}
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
