package com.wujiacun.wujia.entity.combat;

import com.wujiacun.wujia.entity.*;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** One faction/geometry policy for melee, rays, projectiles, palms and lightning. */
public final class WuCombatRules {
    private WuCombatRules() {}

    public static boolean protectedEntity(LivingEntity owner, LivingEntity victim) {
        return victim == owner || !victim.isAlive() || victim.isSpectator()
                || victim instanceof WuVillagerBase || victim instanceof GhostVillagerEntity
                || victim instanceof HimDragonEntity || victim instanceof Animal
                || victim instanceof AbstractVillager || victim instanceof IronGolem
                || victim instanceof Player player && (player.isCreative() || player.isSpectator())
                || owner != null && (owner.isAlliedTo(victim) || victim.isAlliedTo(owner));
    }

    public static boolean canHit(LivingEntity owner, LivingEntity victim) {
        if (owner == null || victim == null || owner.level() != victim.level() || protectedEntity(owner, victim)) return false;
        if (owner instanceof Player) return true;
        return WuVillagerBase.isHostile(victim)
                || owner instanceof WuVillagerBase wu && wu.isRetaliationTarget(victim);
    }

    public static Vec3 clip(Level level, LivingEntity owner, Vec3 from, Vec3 to) {
        return level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, owner)).getLocation();
    }

    public static boolean clearLine(Level level, LivingEntity owner, Vec3 from, Vec3 to) {
        return level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, owner)).getType() == HitResult.Type.MISS;
    }

    /** Never query collision/block data in a missing chunk (including the bbox's far edges). */
    public static boolean loaded(Level level, AABB box) {
        if (box.minY < level.getMinBuildHeight() || box.maxY >= level.getMaxBuildHeight()) return false;
        for (int x = ((int) Math.floor(box.minX)) >> 4; x <= ((int) Math.floor(box.maxX)) >> 4; x++) {
            for (int z = ((int) Math.floor(box.minZ)) >> 4; z <= ((int) Math.floor(box.maxZ)) >> 4; z++) {
                if (!level.hasChunk(x, z)) return false;
            }
        }
        return true;
    }

    public static boolean hazard(Level level, AABB box) {
        for (BlockPos p : BlockPos.betweenClosed(BlockPos.containing(box.minX, box.minY, box.minZ),
                BlockPos.containing(box.maxX, box.maxY, box.maxZ))) {
            var state = level.getBlockState(p);
            if (!state.getFluidState().isEmpty() || state.is(BlockTags.FIRE) || state.is(Blocks.CACTUS)
                    || state.is(Blocks.MAGMA_BLOCK) || state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE)
                    || state.is(Blocks.SWEET_BERRY_BUSH) || state.is(Blocks.WITHER_ROSE)
                    || state.is(Blocks.POWDER_SNOW) || state.is(Blocks.POINTED_DRIPSTONE)) return true;
        }
        return false;
    }

    /** Full-body swept samples, conservative floor support and no doors/walls skipped. */
    public static boolean safeBlink(WuVillagerBase mob, Vec3 to) {
        Vec3 delta = to.subtract(mob.position());
        double length = delta.length();
        if (!Double.isFinite(length) || length < 0.25 || length > 4.25 || Math.abs(delta.y) > 1.05) return false;
        AABB original = mob.getBoundingBox().deflate(0.001);
        int steps = Math.max(1, (int) Math.ceil(length / 0.15));
        for (int i = 0; i <= steps; i++) {
            AABB body = original.move(delta.scale(i / (double) steps));
            AABB floor = new AABB(body.minX + 0.03, body.minY - 0.18, body.minZ + 0.03,
                    body.maxX - 0.03, body.minY + 0.002, body.maxZ - 0.03);
            if (!loaded(mob.level(), body.minmax(floor)) || !mob.level().getWorldBorder().isWithinBounds(body)
                    || !mob.level().noCollision(mob, body) || hazard(mob.level(), body.minmax(floor))) return false;
            // A corner over a cliff is not a safe destination/path, even for a hovering ancestor.
            for (double x : new double[]{floor.minX, floor.maxX}) {
                for (double z : new double[]{floor.minZ, floor.maxZ}) {
                    if (mob.level().noCollision(mob, new AABB(x - 0.015, floor.minY, z - 0.015,
                            x + 0.015, floor.maxY, z + 0.015))) return false;
                }
            }
        }
        return true;
    }
}
