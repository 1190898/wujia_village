package com.wujiacun.wujia;

import com.mojang.logging.LogUtils;
import com.wujiacun.wujia.registry.ModBlocks;
import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.registry.ModItems;
import com.wujiacun.wujia.registry.ModTabs;
import com.wujiacun.wujia.world.ModWorldgen;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(WujiaVillageMod.MODID)
public class WujiaVillageMod {
    public static final String MODID = "wujia_village";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final ResourceKey<Level> WUJIA_DIM =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(MODID, "wujia"));

    public WujiaVillageMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(bus);
        ModItems.register(bus);
        ModEntities.register(bus);
        ModTabs.register(bus);
        ModWorldgen.register(bus);
        LOGGER.info("Wujia Village mod loading: the village where everyone is an ancestor.");
    }
}
