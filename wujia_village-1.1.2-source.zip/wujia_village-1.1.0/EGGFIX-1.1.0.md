# 1.1.0 同版本修复：宠物末影龙生物蛋崩溃

本次修复保持 **mod_version=1.1.0**，Minecraft 1.20.1 / Forge 47.3.0 / Java 17 不变。安装时请移走旧的同名 JAR，只保留新 JAR；仅凭版本号不能区分本次修复，需参考新版 SHA-256。

## 根因与修复

### 宠物龙第一 tick 空主人

普通生物蛋生成的宠物龙没有主人；旧 `petFlight()` 只有 `age > 20` 时才跳过空主人，前20 tick 会直接读取 `ownerEntity.position()`，导致服务端／单人集成服务端空指针异常。

现在从第一 tick 起处理无主、主人死亡或未加载状态：没有有效目标和主人时悬停等待，不读取空对象，按既有有限生命周期回收（无主达到200 tick，即约10秒）。Him 正常召唤绑定不变。缺失主人 NBT 不再意外保留旧 owner，生命周期达到回收阈值及超过阈值均能清理。

### 原版龙构造器忽略自定义实体类型

针对本机实际 Forge 1.20.1 映射依赖进行字节码检查，原版 `EnderDragon` 构造器固定传 `EntityType.ENDER_DRAGON` 给父类，忽略子类构造参数。这会使自定义宠物龙的类型、生成包及存档标识退回原版龙。

新版显式返回注册的 `wujia_village:him_dragon` 类型。保留 Forge 已有的多部件编号及原版生成包机制，不另写一套不兼容的包。

### 村鸡及普通动物近战属性

原版 `Mob.doHurtTarget()` 会读取 `ATTACK_DAMAGE` 和 `ATTACK_KNOCKBACK`。旧村鸡只有原版鸡属性和血量，却在吴家村维度被添加近战目标，缺少必要攻击属性。

新版为战斗村鸡注册两项必要属性。通用动物／村民近战注入先检查属性能力，缺属性者不进入会抛异常的近战路径；不盲目给所有普通动物套攻击 AI。

## 升级与存档

- 同版本替换前先退出游戏并备份世界。
- 原发布包、源码包、校验清单及说明已保存在发布目录的 `backups/1.1.0-before-eggfix/`。
- 不需要删维度或重开世界。不要同时安装两个 `wujia_village` JAR。
- 若旧存档已经保存成原版 `minecraft:ender_dragon`，本次不会批量扫描并强制改写所有原版龙；本修复保证之后的宠物龙采用正确自定义类型。

## 回归验证

### 最终通过结果

- 原有独立服务端自检：**283 项命名断言通过，SELFTEST OK，退出码0**。
- 专用生物蛋回归：**193 项命名断言通过，EGGTEST OK，0项失败，退出码0**。
- 枚举全部11种注册生物蛋，在主世界和吴家村维度各进行一次真实生存模式 `useOn`，合计 **22次实际生物蛋生成**；验证消耗、加入世界、正确类型和 AI。
- 非龙样本保持 AI 启用并经历至少240个真实实体 tick；无主龙验证第一 tick、超过20 tick、180 tick存活及200 tick安全回收。
- 额外验证缺失主人 UUID、缺失主人 NBT、早期主人死亡、目标死亡；验证宠物龙运行类型、生成包类型、NBT ID、多部件编号与实际父体／部件追踪。
- 吴家村村鸡实际调用近战造成伤害且无属性异常；普通牛不被注入不安全的近战目标。
- **真实本地联机客户端：EGGCLIENT OK**，全部11类网络实体均收到并实际调用 `EntityRenderDispatcher.render`，包含自定义宠物龙与其8个正确追踪的部件；不是仅加载纹理或查询渲染器。
- 最终完整构建及重混淆打包通过；版本仍为1.1.0。

日志位于发布目录：`eggfix-existing-selftest.log`、`eggfix-server-observer-final.log`、`eggfix-client-final.log`。

### 测试过程与限制

首轮专用测试曾因隔离服 `spawn-animals=false` 移除动物样本、实体刚加入时的即时查找时序，以及本地客户端未完成握手而失败；这些失败没有计入最终通过。测试改为捕获实际 Join 引用，并在真实 tick 后验证追踪和类型；没有用人工创建的替代实体掩盖生物蛋失败。修正隔离服设置并使用正常 Forge 状态预检连接后，完整复测通过。

本轮客户端验证针对 **生成、网络类型、多部件及渲染不崩溃**，不等同于所有技能观感、全部模组组合或所有存档情形的完整验收。没有实际执行发射器放蛋、多个观察客户端、跨版本存档全量迁移或完整2400 tick有主回收流程；无主保护同时位于实体公共逻辑，不只限于玩家右键蛋。

### 可重现入口

测试代码仅在显式启用时运行，正常游戏不自动启动。使用独立测试目录、已接受 EULA、动物／NPC允许存在的本地测试服：

```bash
WUJIA_EGGTEST=true ./gradlew -PwujiaRunDir=/absolute/isolated/server runServer
```

若要客户端观察，服务端设置 `server-ip=127.0.0.1`、`server-port=25578`、独立测试世界，并启用等待：

```bash
WUJIA_EGGTEST=true WUJIA_EGG_OBSERVER=true ./gradlew -PwujiaRunDir=/absolute/isolated/server runServer
WUJIA_EGG_CLIENT=true WUJIA_EGG_PORT=25578 ./gradlew -PwujiaRunDir=/absolute/isolated/client runClient
```

测试客户端限定离线开发账号及loopback地址，不对外连接；全部实体渲染完成后自动关闭。不要同时启用 `WUJIA_SELFTEST`，也不要指向正式存档。
