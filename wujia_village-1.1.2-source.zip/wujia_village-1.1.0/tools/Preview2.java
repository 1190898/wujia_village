import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Preview2 {
    static void blit(Graphics2D g, BufferedImage src, int sx, int sy, int sw, int sh, int dx, int dy, int scale) {
        for (int y=0;y<sh;y++) for (int x=0;x<sw;x++) {
            int c = src.getRGB(sx+x, sy+y);
            if (((c>>>24)&0xFF)==0) continue;
            g.setColor(new Color(c, true));
            g.fillRect(dx + x*scale, dy + y*scale, scale, scale);
        }
    }
    public static void main(String[] a) throws Exception {
        String[] names = {"him_villager","dodge_villager","teleport_villager","chief_villager","ancestor_villager","sweeper_villager","guard_villager"};
        int scale = 10, cw = 24*scale, ch = 32*scale;
        BufferedImage out = new BufferedImage(cw*names.length, ch, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setColor(new Color(24,28,34)); g.fillRect(0,0,out.getWidth(),out.getHeight());
        for (int i=0;i<names.length;i++) {
            BufferedImage img = ImageIO.read(new File("src/main/resources/assets/wujia_village/textures/entity/"+names[i]+".png"));
            int ox = i*cw + 4*scale;
            blit(g, img, 8,8,8,8, ox+4*scale, 0, scale);            // head front
            blit(g, img, 20,20,8,12, ox+4*scale, 8*scale, scale);   // body front
            blit(g, img, 44,20,4,12, ox, 8*scale, scale);           // right arm
            blit(g, img, 36,52,4,12, ox+12*scale, 8*scale, scale);  // left arm
            blit(g, img, 4,20,4,12, ox+4*scale, 20*scale, scale);   // right leg
            blit(g, img, 20,52,4,12, ox+8*scale, 20*scale, scale);  // left leg
        }
        g.dispose();
        ImageIO.write(out, "png", new File("tools/preview_front.png"));
        System.out.println("ok");
    }
}
