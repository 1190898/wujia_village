import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

/**
 * Deterministic, pixel-painted wide-player skins. Only Him reuses vanilla Steve.
 * Usage: java GenSkins.java <client-extra.jar> <assets/wujia_village> [preview-output-directory]
 * The optional preview is a nearest-neighbor front/back UV reconstruction, NOT an in-game screenshot.
 */
public class GenSkins {
    static File outRoot;
    static final String[] NAMES = {"dodge", "teleport", "chief", "ancestor", "sweeper", "guard", "fisher", "him"};
    static final String[] LABELS = {"DODGE / TEAL MARTIAL", "TELEPORT / RUNE HOOD", "CHIEF / RED & GOLD",
            "ANCESTOR / IVORY", "SWEEPER / PATCHWORK", "GUARD / NAVY UNIFORM", "FISHER / SEA OVERALLS", "HIM / CLASSIC STEVE"};
    static final int[] ACCENTS = {0x65D9BD, 0xAAA0FA, 0xE9BE59, 0xDFCA8E, 0xB79E7C, 0xD6BD78, 0x70BCCA, 0xE7F5FF};

    public static void main(String[] args) throws Exception {
        if (args.length < 2) throw new IllegalArgumentException("GenSkins <client-extra.jar> <asset-root> [preview-dir]");
        outRoot = new File(args[1]);
        BufferedImage[] skins = new BufferedImage[8];
        for (int i = 0; i < 7; i++) skins[i] = paintRole(i);
        try (ZipFile jar = new ZipFile(args[0])) {
            var entry = jar.getEntry("assets/minecraft/textures/entity/player/wide/steve.png");
            if (entry == null) throw new IOException("Vanilla wide Steve skin missing");
            try (var input = jar.getInputStream(entry)) { skins[7] = copy(ImageIO.read(input)); }
        }
        // Preserve every classic Steve pixel except the four pupil pixels inside the original eye whites.
        rect(skins[7], 9, 12, 2, 1, 0xFFFFFF);
        rect(skins[7], 13, 12, 2, 1, 0xFFFFFF);
        for (int i = 0; i < skins.length; i++) save(skins[i], "textures/entity/" + NAMES[i] + "_villager.png");
        save(eyes(0xFFFFFF), "textures/entity/him_villager_eyes.png");
        save(eyes(0xFFF0AE), "textures/entity/ancestor_villager_eyes.png");
        BufferedImage white = new BufferedImage(2, 2, BufferedImage.TYPE_INT_ARGB);
        rect(white, 0, 0, 2, 2, 0xFFFFFF);
        save(white, "textures/entity/skill_white.png");
        save(palmTexture(), "textures/entity/skill_palm.png");
        save(broomItem(), "textures/item/wu_broom.png");
        if (args.length > 2) {
            File preview = new File(args[2]);
            preview.mkdirs();
            ImageIO.write(contactSheet(skins), "png", new File(preview, "wujia_skin_front_back.png"));
            ImageIO.write(atlasSheet(skins), "png", new File(preview, "wujia_skin_uv.png"));
            System.out.println("Preview: " + preview.getAbsolutePath());
        }
        System.out.println("Generated 8 skins, 2 eye overlays, 2 effect textures and held broom icon.");
    }

    static BufferedImage paintRole(int role) {
        BufferedImage image = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        int[] shirt = {0x287F75, 0x37375F, 0xA53D39, 0xE2DDCA, 0x777366, 0x293E59, 0x317990};
        int[] pants = {0x234C4B, 0x272840, 0x792D33, 0xC5C8BF, 0x554D45, 0x233146, 0x235A71};
        int[] hair = {0x252E32, 0x242331, 0x51504D, 0xDDE1DD, 0x939185, 0x292A2A, 0x50392D};
        int[] skin = {0xD6A67F, 0xCDA68E, 0xCBA080, 0xDBC1A7, 0xC39976, 0xCAA07F, 0xD5AE88};
        int cloth = shirt[role], leg = pants[role], accent = ACCENTS[role];
        cube(image, 0, 0, 8, 8, 8, hair[role]);
        // Body/limbs are painted independently, not color-filtered from Steve's shirt.
        cube(image, 16, 16, 8, 12, 4, cloth);
        cube(image, 40, 16, 4, 12, 4, cloth);
        cube(image, 32, 48, 4, 12, 4, cloth);
        cube(image, 0, 16, 4, 12, 4, leg);
        cube(image, 16, 48, 4, 12, 4, leg);
        // Wrapped sleeve hems, bare hands on every side, and proper bottom hand UVs.
        for (int[] arm : new int[][]{{40, 16}, {32, 48}}) {
            stripe(image, arm[0], arm[1], 4, 4, 7, 2, shade(cloth, 0.65));
            stripe(image, arm[0], arm[1], 4, 4, 9, 3, skin[role]);
            panel(image, arm[0] + 8, arm[1], 4, 4, shade(skin[role], 0.82));
            rect(image, arm[0] + 5, arm[1] + 15, 2, 1, shade(skin[role], 0.76));
        }
        for (int[] boot : new int[][]{{0, 16}, {16, 48}}) {
            stripe(image, boot[0], boot[1], 4, 4, 9, 3, role == 3 ? 0x7D837F : 0x303337);
            panel(image, boot[0] + 8, boot[1], 4, 4, 0x25272A);
        }
        face(image, skin[role], hair[role], role);
        // Continuous belt joins front, back and sides; one discrete buckle, not noisy random pixels.
        stripe(image, 16, 16, 8, 4, 9, 2, role == 3 ? 0x9CA69F : shade(leg, 0.72));
        rect(image, 23, 29, 2, 2, accent);
        pixel(image, 24, 30, shade(accent, 0.6));
        switch (role) {
            case 0 -> {
                // Cross-over lapels and diagonal sash. Forearm and shin bindings wrap the sides.
                for (int i = 0; i < 6; i++) {
                    pixel(image, 20 + i / 2, 20 + i, 0xB4D9C8);
                    pixel(image, 27 - i / 2, 20 + i, 0x183F3D);
                }
                rect(image, 24, 24, 1, 5, 0x63B39C);
                for (int y : new int[]{7, 9}) {
                    stripe(image, 0, 16, 4, 4, y, 1, 0xA6C6B1);
                    stripe(image, 16, 48, 4, 4, y, 1, 0xA6C6B1);
                }
                stripe(image, 40, 16, 4, 4, 7, 1, 0xBAD9C9);
                stripe(image, 32, 48, 4, 4, 7, 1, 0xBAD9C9);
                headBand(image, 0xDCE9D8, 10);
                rect(image, 28, 11, 1, 4, 0xDCE9D8); // tied ribbon at rear
                rect(image, 30, 11, 1, 3, 0x8CBFB0);
                rect(image, 35, 23, 2, 3, 0x4EA38F);
                pixel(image, 34, 24, 0xB5DBBE);
                pixel(image, 37, 24, 0xB5DBBE);
                outerCuffs(image, 0xA6D2BD);
            }
            case 1 -> {
                // Raised hood shell leaves the face aperture open; layered collar uses jacket UVs.
                cube(image, 32, 0, 8, 8, 8, 0x333653);
                clear(image, 40, 8, 8, 8);
                rect(image, 40, 8, 8, 2, 0x5B5B86);
                rect(image, 40, 10, 1, 6, 0x444865);
                rect(image, 47, 10, 1, 6, 0x444865);
                rect(image, 41, 15, 6, 1, 0x272B47);
                rect(image, 20, 20, 8, 2, 0x61648C);
                rect(image, 21, 22, 6, 1, 0x454768);
                rect(image, 20, 36, 8, 2, 0x73759B);
                rect(image, 21, 38, 6, 1, 0x3F4268);
                rect(image, 23, 23, 2, 6, 0x292A47);
                rune(image, 25, 24, 0xAA9DE5);
                rune(image, 35, 24, 0x887EBC);
                rune(image, 45, 23, 0x7C92B6);
                rune(image, 37, 55, 0x7C92B6);
                rect(image, 28, 29, 2, 3, 0x8E81C4);
                outerCuffs(image, 0x7975A4);
            }
            case 2 -> {
                // Red robe, broad gold lapels, dark waist sash and a distinct medallion front/back.
                robe(image, 0xDEB557, 0x782C32);
                rect(image, 22, 20, 1, 8, 0xF1CC72);
                rect(image, 25, 20, 1, 8, 0xD9A34A);
                rect(image, 23, 23, 2, 3, 0xDAAE4C);
                pixel(image, 24, 24, 0x752B2E);
                rune(image, 35, 23, 0xE5BD66);
                rect(image, 43, 20, 5, 1, 0xE4BD68);
                rect(image, 35, 52, 5, 1, 0xE4BD68);
                headBand(image, 0xAC7E40, 9);
                pixel(image, 11, 9, 0xE5C16A);
                outerCuffs(image, 0xDCB35C);
            }
            case 3 -> {
                // Ivory folds, silver side panels, gold fastenings and a long white rear braid.
                robe(image, 0xC7AA62, 0xD5D7CA);
                rect(image, 20, 21, 1, 7, 0xBBC5C0);
                rect(image, 27, 21, 1, 7, 0xF2EDD7);
                rect(image, 23, 21, 1, 7, 0xAAAFA6);
                for (int y = 22; y < 28; y += 2) pixel(image, 24, y, 0xD7BB72);
                rect(image, 35, 20, 2, 7, 0xE9ECE4);
                rect(image, 36, 21, 1, 5, 0xC0C9C6);
                rect(image, 35, 27, 2, 1, 0xC1A25B);
                headBand(image, 0xD6BF7C, 9);
                outerCuffs(image, 0xCEC3A1);
            }
            case 4 -> {
                // Rough gray-brown work tunic: asymmetrical sewn patches and rolled elbow cuffs.
                patch(image, 21, 24, 3, 3, 0x9A8D74);
                patch(image, 36, 25, 3, 4, 0x605D55);
                patch(image, 5, 24, 2, 3, 0x8B7E63);
                patch(image, 21, 58, 2, 3, 0x736F61);
                patch(image, 45, 24, 2, 2, 0xA59B7E);
                rect(image, 25, 20, 1, 8, 0x524B43);
                pixel(image, 26, 23, 0xB5A78A);
                rect(image, 20, 30, 8, 1, 0xA69C83);
                cap(image, 0x5D5B50, 0x8F8B72, false);
                outerCuffs(image, 0x9C9784);
            }
            case 5 -> {
                // Navy service uniform: cap badge, collar, chest pocket and gold shoulder tabs.
                cap(image, 0x22374F, 0xC4A65F, true);
                rect(image, 20, 20, 3, 1, 0x7B8B99);
                rect(image, 25, 20, 3, 1, 0x7B8B99);
                rect(image, 23, 21, 2, 6, 0x1B2B3E);
                for (int y = 22; y < 28; y += 2) pixel(image, 24, y, 0xC1AD76);
                rect(image, 26, 23, 2, 2, 0xBF9D55);
                pixel(image, 27, 24, 0xE1C780);
                rect(image, 20, 24, 2, 2, 0x1F3045);
                rect(image, 20, 24, 2, 1, 0x647B8D);
                rect(image, 44, 20, 4, 1, 0xB99B5D);
                rect(image, 36, 52, 4, 1, 0xB99B5D);
                rect(image, 34, 23, 4, 1, 0x9EAFAE);
                rect(image, 35, 24, 2, 2, 0x3C5367);
                outerCuffs(image, 0x53677C);
            }
            case 6 -> {
                // Sea-blue work overalls: bib, buckled straps, rear X-straps and large utility pocket.
                rect(image, 21, 23, 6, 6, 0x24546A);
                rect(image, 21, 20, 1, 6, 0x9DBFC0);
                rect(image, 26, 20, 1, 6, 0x9DBFC0);
                pixel(image, 21, 23, 0xD8C18B);
                pixel(image, 26, 23, 0xD8C18B);
                rect(image, 23, 25, 3, 2, 0x1D4456);
                rect(image, 23, 25, 3, 1, 0x78A2AA);
                for (int i = 0; i < 7; i++) {
                    pixel(image, 32 + i, 20 + i, 0x7AA4AA);
                    pixel(image, 39 - i, 20 + i, 0x7AA4AA);
                }
                patch(image, 20, 56, 3, 3, 0x2E6D80);
                cap(image, 0xBCA46E, 0x785D39, false);
                for (int x = 33; x < 64; x += 3) pixel(image, x, 9, 0xDDC88D);
                outerCuffs(image, 0x77ADB4);
            }
        }
        return image;
    }

    static void face(BufferedImage image, int skin, int hair, int role) {
        panel(image, 8, 8, 8, 8, skin);
        rect(image, 8, 8, 8, 2, hair);
        rect(image, 8, 10, 1, 4, shade(hair, 1.15));
        rect(image, 15, 10, 1, 4, shade(hair, 0.85));
        for (int x : new int[]{0, 16}) {
            rect(image, x + 1, 12, 6, 4, shade(skin, 0.83));
            pixel(image, x + 4, 12, shade(skin, 1.05));
        }
        rect(image, 9, 11, 2, 1, shade(hair, 0.9));
        rect(image, 13, 11, 2, 1, shade(hair, 0.9));
        rect(image, 9, 12, 2, 1, 0xE3DFCE);
        rect(image, 13, 12, 2, 1, 0xE3DFCE);
        int eye = role == 1 ? 0xB8AFEB : role == 3 ? 0xE5C67B : 0x34484B;
        pixel(image, 10, 12, eye);
        pixel(image, 13, 12, eye);
        rect(image, 11, 13, 2, 1, shade(skin, 0.75));
        rect(image, 10, 14, 4, 1, shade(skin, 0.61));
        if (role == 2 || role == 3 || role == 4) {
            int beard = role == 2 ? 0xABA99B : role == 3 ? 0xE8E9DB : 0x9A9A8C;
            rect(image, 9, 15, 6, 1, beard);
            pixel(image, 9, 14, beard);
            pixel(image, 14, 14, beard);
            if (role == 3) {
                rect(image, 11, 15, 2, 1, 0xF4F1DE);
                rect(image, 16, 0, 8, 8, beard);
            }
        }
    }

    static void robe(BufferedImage image, int trim, int shadow) {
        rect(image, 20, 20, 1, 9, trim);
        rect(image, 27, 20, 1, 9, trim);
        rect(image, 32, 20, 1, 9, trim);
        rect(image, 39, 20, 1, 9, trim);
        for (int[] leg : new int[][]{{0, 16}, {16, 48}}) {
            stripe(image, leg[0], leg[1], 4, 4, 8, 1, trim);
            rect(image, leg[0] + 4, leg[1] + 4, 1, 8, shadow);
        }
        stripe(image, 16, 16, 8, 4, 11, 1, trim);
    }

    static void cap(BufferedImage image, int crown, int band, boolean badge) {
        panel(image, 40, 0, 8, 8, crown);
        for (int x : new int[]{32, 40, 48, 56}) {
            rect(image, x, 8, 8, 2, crown);
            rect(image, x, 10, 8, 1, band);
        }
        if (badge) {
            rect(image, 43, 9, 2, 2, 0xD5B86F);
            pixel(image, 44, 10, 0xF3DFA0);
            rect(image, 41, 11, 6, 1, 0x16293C);
        } else {
            for (int x = 40; x < 48; x += 2) pixel(image, x, 3, shade(crown, 1.2));
        }
    }

    static void outerCuffs(BufferedImage image, int color) {
        stripe(image, 40, 32, 4, 4, 7, 1, color);
        stripe(image, 48, 48, 4, 4, 7, 1, color);
    }
    static void headBand(BufferedImage image, int color, int y) {
        rect(image, 0, y, 32, 1, color);
        pixel(image, 11, y, shade(color, 0.72));
    }
    static void rune(BufferedImage image, int x, int y, int color) {
        rect(image, x, y, 1, 5, color);
        pixel(image, x - 1, y + 1, color);
        pixel(image, x + 1, y + 3, color);
    }
    static void patch(BufferedImage image, int x, int y, int w, int h, int color) {
        rect(image, x, y, w, h, color);
        for (int i = 0; i < w; i += 2) pixel(image, x + i, y, shade(color, 1.3));
        for (int i = 1; i < h; i += 2) pixel(image, x, y + i, shade(color, 0.7));
    }

    // All cuboid faces are filled, including undersides; modest face shading keeps seams intentional.
    static void cube(BufferedImage image, int u, int v, int w, int h, int d, int color) {
        panel(image, u + d, v, w, d, shade(color, 1.1));
        panel(image, u + d + w, v, w, d, shade(color, 0.7));
        panel(image, u, v + d, d, h, shade(color, 0.8));
        panel(image, u + d, v + d, w, h, color);
        panel(image, u + d + w, v + d, d, h, shade(color, 0.87));
        panel(image, u + d + w + d, v + d, w, h, shade(color, 0.92));
    }
    static void stripe(BufferedImage image, int u, int v, int w, int d, int row, int height, int color) {
        rect(image, u, v + d + row, 2 * (w + d), height, color);
    }
    static void panel(BufferedImage image, int x, int y, int w, int h, int color) {
        rect(image, x, y, w, h, color);
        // Pixel clusters, not smooth filters/noise: sparse folds down one edge and at the lower hem.
        if (w > 2 && h > 3) {
            rect(image, x, y + 1, 1, h - 2, shade(color, 0.87));
            rect(image, x + w - 2, y + 1, 1, Math.max(1, h / 3), shade(color, 1.08));
            rect(image, x + 1, y + h - 1, w - 2, 1, shade(color, 0.93));
        }
    }
    static void pixel(BufferedImage image, int x, int y, int rgb) {
        if (x >= 0 && y >= 0 && x < image.getWidth() && y < image.getHeight()) image.setRGB(x, y, 0xFF000000 | rgb);
    }
    static void rect(BufferedImage image, int x, int y, int w, int h, int rgb) {
        for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) pixel(image, i, j, rgb);
    }
    static void clear(BufferedImage image, int x, int y, int w, int h) {
        for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) image.setRGB(i, j, 0);
    }
    static int shade(int color, double amount) {
        int r = Math.min(255, (int) (((color >> 16) & 255) * amount));
        int g = Math.min(255, (int) (((color >> 8) & 255) * amount));
        int b = Math.min(255, (int) ((color & 255) * amount));
        return r << 16 | g << 8 | b;
    }
    static BufferedImage eyes(int color) {
        BufferedImage image = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        rect(image, 9, 12, 2, 1, color);
        rect(image, 13, 12, 2, 1, color);
        return image;
    }
    static BufferedImage palmTexture() {
        BufferedImage image = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        rect(image, 0, 0, 64, 64, 0xE8DFCB);
        for (int i = 0; i < 64; i += 8) {
            rect(image, 0, i, 64, 1, 0xBBAF96);
            rect(image, i, 0, 1, 64, 0xFFF7E3);
        }
        // Three crisp palm creases, still visible after role tint and translucent blending.
        rect(image, 6, 10, 12, 1, 0xB5A68B);
        rect(image, 9, 14, 13, 1, 0xC4B69A);
        rect(image, 12, 17, 1, 7, 0xC4B69A);
        return image;
    }
    static BufferedImage broomItem() {
        BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int i = 0; i < 12; i++) {
            pixel(image, 3 + i, 12 - i, 0xB98E55);
            pixel(image, 3 + i, 13 - i, 0x785537);
        }
        for (int y = 8; y <= 14; y++) for (int x = 1; x <= 7; x++) {
            if (x + 14 - y >= 6) pixel(image, x, y, (x + y) % 2 == 0 ? 0xC4A85D : 0xE2CA7F);
        }
        pixel(image, 6, 8, 0xD6B266);
        pixel(image, 7, 7, 0xD6B266);
        pixel(image, 7, 8, 0x896E3C);
        return image;
    }
    static BufferedImage copy(BufferedImage source) {
        BufferedImage image = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics(); g.drawImage(source, 0, 0, null); g.dispose(); return image;
    }
    static void save(BufferedImage image, String path) throws IOException {
        File file = new File(outRoot, path); file.getParentFile().mkdirs(); ImageIO.write(image, "png", file);
        System.out.println(" + " + path);
    }

    static BufferedImage contactSheet(BufferedImage[] skins) {
        int cellW = 384, cellH = 376;
        BufferedImage image = new BufferedImage(cellW * 4, cellH * 2 + 64, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(new Color(0x101923)); g.fillRect(0, 0, image.getWidth(), image.getHeight());
        g.setFont(new Font("SansSerif", Font.BOLD, 23)); g.setColor(new Color(0xE1E8E8));
        g.drawString("WU VILLAGE  |  PIXEL SKIN STUDY  |  FRONT + BACK", 24, 34);
        g.setFont(new Font("SansSerif", Font.PLAIN, 13));
        g.drawString("64 x 64 wide-player UVs / nearest-neighbor / clothing overlays included / not an in-game screenshot", 24, 54);
        for (int i = 0; i < 8; i++) {
            int x = i % 4 * cellW, y = i / 4 * cellH + 64;
            g.setColor(new Color(0x182430)); g.fillRoundRect(x + 10, y + 8, cellW - 20, cellH - 16, 14, 14);
            g.setColor(new Color(ACCENTS[i])); g.fillRect(x + 24, y + 24, 4, 18);
            g.setFont(new Font("SansSerif", Font.BOLD, 15)); g.drawString(LABELS[i], x + 38, y + 39);
            for (int back = 0; back < 2; back++) {
                BufferedImage figure = figure(skins[i], back != 0);
                g.drawImage(figure, x + 48 + back * 164, y + 65, 128, 256, null);
                g.setColor(new Color(0x93A4AE)); g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                g.drawString(back == 0 ? "FRONT" : "BACK", x + 91 + back * 164, y + 343);
            }
        }
        g.dispose(); return image;
    }
    static BufferedImage figure(BufferedImage skin, boolean back) {
        BufferedImage image = new BufferedImage(16, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        int headX = back ? 24 : 8, bodyX = back ? 32 : 20;
        part(g, skin, headX, 8, 8, 8, 4, 0);
        part(g, skin, headX + 32, 8, 8, 8, 4, 0);
        part(g, skin, bodyX, 20, 8, 12, 4, 8);
        part(g, skin, bodyX, 36, 8, 12, 4, 8);
        part(g, skin, back ? 52 : 44, 20, 4, 12, back ? 12 : 0, 8);
        part(g, skin, back ? 52 : 44, 36, 4, 12, back ? 12 : 0, 8);
        part(g, skin, back ? 44 : 36, 52, 4, 12, back ? 0 : 12, 8);
        part(g, skin, back ? 60 : 52, 52, 4, 12, back ? 0 : 12, 8);
        part(g, skin, back ? 12 : 4, 20, 4, 12, back ? 8 : 4, 20);
        part(g, skin, back ? 12 : 4, 36, 4, 12, back ? 8 : 4, 20);
        part(g, skin, back ? 28 : 20, 52, 4, 12, back ? 4 : 8, 20);
        part(g, skin, back ? 12 : 4, 52, 4, 12, back ? 4 : 8, 20);
        g.dispose(); return image;
    }
    static void part(Graphics2D g, BufferedImage skin, int x, int y, int w, int h, int dx, int dy) {
        g.drawImage(skin, dx, dy, dx + w, dy + h, x, y, x + w, y + h, null);
    }
    static BufferedImage atlasSheet(BufferedImage[] skins) {
        BufferedImage image = new BufferedImage(1024, 560, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        for (int y = 0; y < 560; y += 16) for (int x = 0; x < 1024; x += 16) {
            g.setColor(new Color(((x + y) / 16) % 2 == 0 ? 0x182430 : 0x243442)); g.fillRect(x, y, 16, 16);
        }
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        for (int i = 0; i < 8; i++) {
            int x = i % 4 * 256, y = i / 4 * 280;
            g.drawImage(skins[i], x, y + 24, 256, 256, null);
            g.setColor(new Color(ACCENTS[i])); g.drawString(NAMES[i].toUpperCase() + " / 64 x 64", x + 8, y + 17);
        }
        g.dispose(); return image;
    }
}
