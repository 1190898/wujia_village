import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Preview {
    public static void main(String[] a) throws Exception {
        String[] names = {"him_villager","dodge_villager","teleport_villager","chief_villager","ancestor_villager","sweeper_villager","guard_villager"};
        int s = 8, w = 64*s, cols = names.length;
        BufferedImage out = new BufferedImage(w*cols, w, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setColor(new Color(30,34,40));
        g.fillRect(0,0,out.getWidth(),out.getHeight());
        for (int i=0;i<cols;i++) {
            BufferedImage img = ImageIO.read(new File("src/main/resources/assets/wujia_village/textures/entity/"+names[i]+".png"));
            g.drawImage(img, i*w, 0, w, w, null);
        }
        g.dispose();
        ImageIO.write(out, "png", new File("tools/preview_skins.png"));
        System.out.println("ok");
    }
}
