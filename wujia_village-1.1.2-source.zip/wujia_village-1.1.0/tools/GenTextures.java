import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 吴家村纹理生成器：从原版纹理调色 + 程序化生成。
 * 用法: java GenTextures.java <client-extra.jar> <输出资源目录>
 */
public class GenTextures {

    static ZipFile jar;
    static File outRoot;

    public static void main(String[] args) throws Exception {
        jar = new ZipFile(args[0]);
        outRoot = new File(args[1]);

        // ---- 村民纹理（完整村民皮肤，不是群系覆盖层） ----
        BufferedImage villager = read("assets/minecraft/textures/entity/villager/villager.png");
        save(shift(villager, 140, 1.05, 1.0, 1.0), "textures/entity/dodge_villager.png");
        save(shift(villager, 200, 1.15, 1.05, 1.0), "textures/entity/teleport_villager.png");
        save(shift(villager, -42, 1.35, 1.12, 1.0), "textures/entity/chief_villager.png");
        save(shift(villager, -30, 0.22, 1.22, 1.0), "textures/entity/ancestor_villager.png");
        save(shift(villager, 0, 0.14, 1.05, 1.0), "textures/entity/sweeper_villager.png");
        save(shift(villager, 200, 1.15, 1.05, 0.45), "textures/entity/ghost_villager.png");
        save(whiteEyes(shift(villager, 0, 0.05, 1.35, 1.0)), "textures/entity/him_villager.png");

        // ---- 盔甲 ----
        BufferedImage layer1 = read("assets/minecraft/textures/models/armor/iron_layer_1.png");
        BufferedImage layer2 = read("assets/minecraft/textures/models/armor/iron_layer_2.png");
        save(shift(layer1, 145, 1.15, 1.12, 1.0), "textures/models/armor/wu_layer_1.png");
        save(shift(layer2, 145, 1.15, 1.12, 1.0), "textures/models/armor/wu_layer_2.png");

        BufferedImage ihelm = read("assets/minecraft/textures/item/iron_helmet.png");
        save(shift(ihelm, 145, 1.15, 1.12, 1.0), "textures/item/wu_helmet.png");
        BufferedImage iches = read("assets/minecraft/textures/item/iron_chestplate.png");
        save(shift(iches, 145, 1.15, 1.12, 1.0), "textures/item/wu_chestplate.png");
        BufferedImage ilegs = read("assets/minecraft/textures/item/iron_leggings.png");
        save(shift(ilegs, 145, 1.15, 1.12, 1.0), "textures/item/wu_leggings.png");
        BufferedImage iboots = read("assets/minecraft/textures/item/iron_boots.png");
        save(shift(iboots, 145, 1.15, 1.12, 1.0), "textures/item/wu_boots.png");

        // ---- 物品 ----
        BufferedImage sword = read("assets/minecraft/textures/item/iron_sword.png");
        save(shift(sword, 155, 1.25, 1.18, 1.0), "textures/item/wu_sword.png");

        BufferedImage slime = read("assets/minecraft/textures/item/slime_ball.png");
        save(shift(slime, 125, 1.3, 1.15, 1.0), "textures/item/wu_cell.png");

        BufferedImage apple = read("assets/minecraft/textures/item/apple.png");
        save(shift(apple, -45, 1.2, 1.1, 1.0), "textures/item/wu_elixir.png");

        BufferedImage milk = read("assets/minecraft/textures/item/milk_bucket.png");
        save(shift(milk, 18, 1.5, 1.0, 1.0), "textures/item/wild_dog_milk.png");

        save(genCloud(), "textures/block/cloud_block.png");
        save(genPortal(), "textures/block/wujia_portal.png");
        save(genStele(false), "textures/block/wujia_stele_bottom.png");
        save(genStele(true), "textures/block/wujia_stele_top.png");
        save(genStone(), "textures/block/wujia_stone.png");
        save(genCabbage(), "textures/block/wu_cabbage.png");
        save(genPlanet(), "textures/environment/cube_planet.png");
        File mcmeta = out("textures/block/wujia_portal.png.mcmeta");
        Files.write(mcmeta.toPath(), "{\"animation\":{\"frametime\":2}}".getBytes());

        System.out.println("OK: textures written to " + outRoot);
    }

    /** 脸部偏暗的像素改成白眼，给入门学徒 Him。 */
    static BufferedImage whiteEyes(BufferedImage src) {
        BufferedImage dst = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) dst.setRGB(x, y, src.getRGB(x, y));
        }
        for (int y = 8; y <= 15 && y < dst.getHeight(); y++) {
            for (int x = 8; x <= 15 && x < dst.getWidth(); x++) {
                int argb = dst.getRGB(x, y);
                int a = (argb >>> 24) & 0xFF;
                if (a == 0) continue;
                int r = (argb >>> 16) & 0xFF, g = (argb >>> 8) & 0xFF, b = argb & 0xFF;
                if (r + g + b < 180) dst.setRGB(x, y, (a << 24) | 0xF4F7FF);
            }
        }
        return dst;
    }

    static BufferedImage genStele(boolean top) {
        int s = 16;
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < s; y++) {
            for (int x = 0; x < s; x++) {
                boolean border = x < 2 || x > 13 || y < 2 || y > 13;
                int r = border ? 92 : 168;
                int g = border ? 90 : 164;
                int b = border ? 86 : 150;
                if (!top && y > 4 && y < 13 && x > 3 && x < 12 && y % 2 == 0) {
                    r = 70; g = 62; b = 52;
                }
                if (top && y < 4) { r = 120; g = 108; b = 90; }
                img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | b);
            }
        }
        return img;
    }

    static BufferedImage genStone() {
        int s = 16;
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Random rnd = new Random(11);
        for (int y = 0; y < s; y++) {
            for (int x = 0; x < s; x++) {
                int n = rnd.nextInt(18) - 9;
                int r = clamp255(128 + n);
                int g = clamp255(124 + n);
                int b = clamp255(118 + n);
                if ((x + y) % 7 == 0) { r = 150; g = 70; b = 58; }
                img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | b);
            }
        }
        return img;
    }

    static BufferedImage genCabbage() {
        int s = 16;
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < s; y++) {
            for (int x = 0; x < s; x++) {
                double d = Math.hypot(x - 8, y - 9);
                if (d > 6.2) continue;
                int g = d < 2.2 ? 210 : 120 + (int) ((6.2 - d) * 12);
                img.setRGB(x, y, (255 << 24) | (40 << 16) | (clamp255(g) << 8) | 36);
            }
        }
        return img;
    }

    /** 六面竖排：峡谷、陨坑、极冠、暗岩、青色干湖、沙垄。 */
    static BufferedImage genPlanet() {
        int s = 64;
        BufferedImage img = new BufferedImage(s, s * 6, BufferedImage.TYPE_INT_ARGB);
        for (int face = 0; face < 6; face++) {
            paintPlanetFace(img, face, s);
        }
        return img;
    }

    static void paintPlanetFace(BufferedImage img, int face, int s) {
        Random rnd = new Random(100 + face * 17);
        int[][] craters = new int[8][3];
        for (int i = 0; i < craters.length; i++) {
            craters[i][0] = 6 + rnd.nextInt(s - 12);
            craters[i][1] = 6 + rnd.nextInt(s - 12);
            craters[i][2] = 3 + rnd.nextInt(7);
        }
        for (int y = 0; y < s; y++) {
            for (int x = 0; x < s; x++) {
                double n = Math.sin(x * 0.35 + face) * 8 + Math.cos(y * 0.22) * 6;
                int r = clamp255(168 + n);
                int g = clamp255(78 + n * 0.35);
                int b = clamp255(48 + n * 0.2);
                for (int[] c : craters) {
                    double d = Math.hypot(x - c[0], y - c[1]);
                    if (d < c[2]) {
                        r = clamp255(r - 40);
                        g = clamp255(g - 24);
                        b = clamp255(b - 16);
                    } else if (d < c[2] + 1.6) {
                        r = clamp255(r + 28);
                        g = clamp255(g + 16);
                    }
                }
                if (face == 0 && Math.abs(y - (18 + Math.sin(x * 0.2) * 6)) < 2.2) {
                    r = 90; g = 42; b = 32;
                }
                if (face == 2 && y < 16) {
                    double t = (16 - y) / 16.0;
                    r = (int) (r * (1 - t) + 236 * t);
                    g = (int) (g * (1 - t) + 230 * t);
                    b = (int) (b * (1 - t) + 214 * t);
                }
                if (face == 3) { r = clamp255(r * 0.55); g = clamp255(g * 0.5); b = clamp255(b * 0.5); }
                if (face == 4) {
                    double basin = Math.hypot(x - 34, y - 30);
                    if (basin < 16) {
                        double t = 1 - basin / 16;
                        r = (int) (r * (1 - t) + 70 * t);
                        g = (int) (g * (1 - t) + 150 * t);
                        b = (int) (b * (1 - t) + 148 * t);
                    }
                }
                if (face == 5 && Math.sin(y * 0.45 + x * 0.05) > 0.45) {
                    r = clamp255(r + 24); g = clamp255(g + 14);
                }
                img.setRGB(x, face * s + y, (255 << 24) | (r << 16) | (g << 8) | b);
            }
        }
    }

    /** 色相偏移 + 饱和度/明度调整 + 透明度缩放（只动非透明像素） */
    static BufferedImage shift(BufferedImage src, double hueDeltaDeg, double satMul, double valMul, double alphaMul) {
        int w = src.getWidth(), h = src.getHeight();
        BufferedImage dst = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        double hd = hueDeltaDeg / 360.0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int argb = src.getRGB(x, y);
                int a = (argb >>> 24) & 0xFF;
                if (a == 0) {
                    dst.setRGB(x, y, 0);
                    continue;
                }
                int r = (argb >>> 16) & 0xFF, g = (argb >>> 8) & 0xFF, b = argb & 0xFF;
                float[] hsb = Color.RGBtoHSB(r, g, b, null);
                double hue = (hsb[0] + hd) % 1.0f;
                if (hue < 0) hue += 1.0;
                double sat = clamp01(hsb[1] * satMul);
                double val = clamp01(hsb[2] * valMul);
                int rgb = Color.HSBtoRGB((float) hue, (float) sat, (float) val);
                int na = (int) clamp255(a * alphaMul);
                dst.setRGB(x, y, (na << 24) | (rgb & 0xFFFFFF));
            }
        }
        return dst;
    }

    /** 云朵方块：蓬松白云 */
    static BufferedImage genCloud() {
        int s = 16;
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Random rnd = new Random(42);
        // 若干高亮/阴影团
        double[][] bright = new double[s][s];
        for (int i = 0; i < 10; i++) {
            int cx = rnd.nextInt(s), cy = rnd.nextInt(s);
            double radius = 3 + rnd.nextDouble() * 4;
            double amount = rnd.nextDouble() < 0.5 ? 0.5 : -0.25;
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++) {
                    double d = Math.hypot(x - cx, y - cy);
                    if (d < radius) bright[y][x] += amount * (1 - d / radius);
                }
        }
        for (int y = 0; y < s; y++)
            for (int x = 0; x < s; x++) {
                double b = bright[y][x];
                // 底部微蓝阴影，顶部更亮
                double shade = (y / (double) s) * 18;
                int r = clamp255(248 - shade + b * 30);
                int g = clamp255(252 - shade * 0.6 + b * 30);
                int bl = clamp255(255 - shade * 0.1 + b * 30);
                img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | bl);
            }
        return img;
    }

    /** 淡蓝色传送门动画条：16x512（32 帧 16x16），纵向流动的蓝色波纹 */
    static BufferedImage genPortal() {
        // 淡蓝半透明门面：多层柔波，不做下界紫
        BufferedImage img = new BufferedImage(16, 512, BufferedImage.TYPE_INT_ARGB); // 32 frames * 16
        for (int frame = 0; frame < 32; frame++) {
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 16; x++) {
                    double wave = Math.sin((x + frame * 0.7) * 0.55) + Math.cos((y - frame * 0.45) * 0.7);
                    double v = 0.55 + 0.25 * wave;
                    int r = clamp255((int) (90 + v * 70));
                    int g = clamp255((int) (160 + v * 60));
                    int b = clamp255((int) (230 + v * 25));
                    int a = clamp255((int) (140 + v * 70));
                    // 边缘更亮
                    if (x == 0 || x == 15 || y == 0 || y == 15) { r = clamp255(r + 30); g = clamp255(g + 20); a = clamp255(a + 20); }
                    img.setRGB(x, y + frame * 16, (a << 24) | (r << 16) | (g << 8) | b);
                }
            }
        }
        return img;
    }


    static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    static BufferedImage read(String path) throws IOException {
        ZipEntry e = jar.getEntry(path);
        if (e == null) throw new IOException("missing in jar: " + path);
        BufferedImage img = ImageIO.read(jar.getInputStream(e));
        if (img == null) throw new IOException("cannot decode: " + path);
        // 统一转 ARGB，避免调色板索引误伤
        BufferedImage conv = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = conv.createGraphics();
        g.drawImage(img, 0, 0, null);
        g.dispose();
        return conv;
    }

    static File out(String rel) {
        File f = new File(outRoot, rel);
        f.getParentFile().mkdirs();
        return f;
    }

    static void save(BufferedImage img, String rel) throws IOException {
        File f = out(rel);
        ImageIO.write(img, "png", f);
        System.out.println("  + " + rel);
    }

    static int clamp255(double v) {
        return (int) Math.max(0, Math.min(255, v));
    }

    static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
