import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Preview3 {
    public static void main(String[] a) throws Exception {
        String[] names = {"him_villager","him_villager_eyes","dodge_villager","teleport_villager","chief_villager","ancestor_villager","sweeper_villager","guard_villager"};
        int scale = 26, w = 8*scale, pad = 6;
        BufferedImage out = new BufferedImage((w+pad)*names.length, w, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setColor(new Color(18,20,24)); g.fillRect(0,0,out.getWidth(),out.getHeight());
        for (int i=0;i<names.length;i++) {
            BufferedImage img = ImageIO.read(new File("src/main/resources/assets/wujia_village/textures/entity/"+names[i]+".png"));
            for (int y=0;y<8;y++) for (int x=0;x<8;x++) {
                int c = img.getRGB(8+x, 8+y);
                if (((c>>>24)&0xFF)==0) { g.setColor(new Color(60,16,16)); }
                else g.setColor(new Color(c, true));
                g.fillRect(i*(w+pad)+x*scale, y*scale, scale, scale);
            }
        }
        g.dispose();
        ImageIO.write(out, "png", new File("tools/preview_faces.png"));
        System.out.println("ok");
    }
}
