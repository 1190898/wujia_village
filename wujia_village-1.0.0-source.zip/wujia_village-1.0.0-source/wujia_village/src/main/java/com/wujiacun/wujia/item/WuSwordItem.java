package com.wujiacun.wujia.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 吴家神剑：吴家回马枪的现代化身，一枪击穿 50 米钢板。
 * 大多数攻击无视护甲（见 WujiaEvents 的穿甲逻辑）。
 */
public class WuSwordItem extends SwordItem {
    public WuSwordItem() {
        super(Tiers.NETHERITE, 995, -2.0f, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public boolean canBeDepleted() {
        return false; // 无限耐久
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.wujia_village.wu_sword.tooltip").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("item.wujia_village.wu_sword.tooltip2").withStyle(ChatFormatting.GRAY));
    }
}
