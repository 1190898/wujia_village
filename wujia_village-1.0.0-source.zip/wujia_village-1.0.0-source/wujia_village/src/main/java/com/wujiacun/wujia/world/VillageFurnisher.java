package com.wujiacun.wujia.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 老存档补家具：只往空位补；同时清掉堵在门口通道上的旧家具（床/箱/桌等），
 * 保证开门能进屋。不碰玩家自己砌的墙。
 */
public final class VillageFurnisher {

    private VillageFurnisher() {}

    public static void tick(ServerLevel level) {
        if (level.getGameTime() % 100L != 0L) return;
        for (ServerPlayer player : level.players()) {
            furnishAround(level, player.blockPosition());
        }
    }

    private static void furnishAround(ServerLevel level, BlockPos center) {
        int cellX0 = Math.floorDiv(center.getX() - 40, WujiaVillageLayout.PLOT);
        int cellX1 = Math.floorDiv(center.getX() + 40, WujiaVillageLayout.PLOT);
        int cellZ0 = Math.floorDiv(center.getZ() - 40, WujiaVillageLayout.PLOT);
        int cellZ1 = Math.floorDiv(center.getZ() + 40, WujiaVillageLayout.PLOT);

        for (int cx = cellX0; cx <= cellX1; cx++) {
            for (int cz = cellZ0; cz <= cellZ1; cz++) {
                int kind = WujiaVillageLayout.style(cx, cz);
                if (kind == WujiaVillageLayout.FARM) continue;
                int[] b = WujiaVillageLayout.houseBounds(cx, cz, kind);
                int doorX = (b[0] + b[1]) / 2;
                int z1 = b[3];
                for (int x = b[0]; x <= b[1]; x++) {
                    for (int z = b[2]; z <= b[3]; z++) {
                        for (int y = WujiaVillageLayout.SURFACE + 1; y <= WujiaVillageLayout.SURFACE + 3; y++) {
                            BlockPos pos = new BlockPos(x, y, z);
                            if (!level.hasChunkAt(pos)) continue;
                            BlockState current = level.getBlockState(pos);

                            // 门口通道：拆掉会堵路的家具，保留门本身
                            if (Math.abs(x - doorX) <= 1 && z >= z1 - 2 && z <= z1) {
                                if (y <= WujiaVillageLayout.SURFACE + 2 && isClutter(current) && !current.is(Blocks.AIR)) {
                                    // 门列上的门不要拆
                                    if (!(x == doorX && z == z1 && current.getBlock() instanceof net.minecraft.world.level.block.DoorBlock)) {
                                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                                        current = level.getBlockState(pos);
                                    }
                                }
                            }

                            BlockState want = WujiaVillageLayout.furnitureAt(x, y, z);
                            if (want == null) continue;
                            if (!current.isAir()) continue;
                            level.setBlock(pos, want, 3);
                        }
                    }
                }
            }
        }
    }

    private static boolean isClutter(BlockState state) {
        return state.is(Blocks.OAK_FENCE) || state.is(Blocks.OAK_PRESSURE_PLATE)
                || state.is(Blocks.CHEST) || state.is(Blocks.CRAFTING_TABLE)
                || state.is(Blocks.BARREL) || state.is(Blocks.FURNACE)
                || state.is(Blocks.SMOKER) || state.is(Blocks.BLAST_FURNACE)
                || state.is(Blocks.ANVIL) || state.is(Blocks.CHIPPED_ANVIL) || state.is(Blocks.DAMAGED_ANVIL)
                || state.is(Blocks.BOOKSHELF) || state.is(Blocks.LECTERN)
                || state.is(Blocks.POTTED_DANDELION) || state.getBlock() instanceof net.minecraft.world.level.block.BedBlock
                || state.getBlock() instanceof net.minecraft.world.level.block.CarpetBlock;
    }
}
