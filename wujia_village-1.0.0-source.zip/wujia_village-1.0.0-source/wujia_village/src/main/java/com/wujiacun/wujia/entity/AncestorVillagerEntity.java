package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * 吴家老祖：曾硬扛盘古三斧，睡觉翻身震死盘古扬眉罗喉，叹气击杀洪荒所有圣人。
 * 悬浮于地面之上，威压笼罩一切——任何胆敢在附近现身的敌对存在都会被一眼瞪死。
 */
public class AncestorVillagerEntity extends WuVillagerBase {

    private static final double GLARE_RADIUS = 16.0;

    public AncestorVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.ancestor_villager");
        this.setNoGravity(true);
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.ancestor";
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        ServerLevel sl = (ServerLevel) this.level();

        // 老祖永远悬在半空，不受世俗引力影响
        if (this.onGround()) {
            this.setDeltaMovement(this.getDeltaMovement().x, 0.08, this.getDeltaMovement().z);
            this.hasImpulse = true;
        }

        // 威压粒子
        if (this.tickCount % 8 == 0) {
            sl.sendParticles(ParticleTypes.END_ROD,
                    this.getX() + (this.random.nextDouble() - 0.5) * 2,
                    this.getY() + this.random.nextDouble() * 2.5,
                    this.getZ() + (this.random.nextDouble() - 0.5) * 2,
                    1, 0, 0, 0, 0.02);
        }
        if (this.tickCount % 30 == 0) {
            sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING,
                    this.getX(), this.getY() + 1.2, this.getZ(),
                    4, 0.8, 0.6, 0.8, 0.2);
        }

        // 一眼瞪死任何胆敢出现的敌对生物
        if (this.tickCount % 40 == 0) {
            for (LivingEntity enemy : sl.getEntitiesOfClass(LivingEntity.class,
                    new AABB(this.blockPosition()).inflate(GLARE_RADIUS),
                    e -> isHostile(e) && e.isAlive())) {
                // 可视闪电：纯视觉，不点火、不伤及无辜
                LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, sl);
                bolt.moveTo(enemy.getX(), enemy.getY(), enemy.getZ());
                bolt.setVisualOnly(true);
                sl.addFreshEntity(bolt);
                enemy.hurt(this.damageSources().magic(), 9999.0f);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        // 谁敢打老祖，先尝尝普朗克时间内的反击威压
        if (src.getEntity() instanceof LivingEntity attacker && attacker != this) {
            attacker.hurt(this.damageSources().magic(), 2.0f);
            attacker.knockback(0.35, this.getX() - attacker.getX(), this.getZ() - attacker.getZ());
            attacker.hurtMarked = true;
        }
        return super.hurt(src, amount);
    }
}
