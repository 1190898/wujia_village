package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;

/**
 * 残影：瞬移村民每次瞬移时在原地留下的半透明影子。
 * 无碰撞、无AI、不受伤害，原地不动，20 tick 内一点点淡出（不缩小）。
 */
public class GhostVillagerEntity extends Mob {

    /** 残影寿命（tick）。渲染按这个时长分成若干淡出帧。 */
    public static final int LIFETIME = 20;

    public GhostVillagerEntity(EntityType<? extends Mob> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setInvulnerable(true);
        this.setNoGravity(true);
        this.noPhysics = true;
        this.setSilent(true);
    }

    /** 0 = 刚出现，1 = 已经完全消失 */
    public float fade(float partialTick) {
        return Math.min(1.0f, (this.tickCount + partialTick) / (float) LIFETIME);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level() instanceof ServerLevel sl) {
            if (this.tickCount % 3 == 0) {
                sl.sendParticles(ParticleTypes.PORTAL,
                        this.getX(), this.getY() + this.random.nextDouble() * this.getBbHeight(), this.getZ(),
                        3, 0.25, 0.3, 0.25, 0.02);
            }
            if (this.tickCount > LIFETIME) {
                this.discard();
            }
        }
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void pushEntities() {
        // 不推人，人不推我
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) {
        return distSqr < 4096.0;
    }
}
