package com.wujiacun.wujia.client;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.GhostVillagerEntity;
import com.wujiacun.wujia.registry.ModBlocks;
import com.wujiacun.wujia.registry.ModEntities;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ChickenRenderer;
import net.minecraft.client.renderer.entity.EnderDragonRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.WolfRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterDimensionSpecialEffectsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * 客户端渲染：吴家村的角色一律用玩家（史蒂夫）骨架，不再是原版村民模型。
 */
@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WujiaClientSetup {

    private static ResourceLocation tex(String path) {
        return new ResourceLocation(WujiaVillageMod.MODID, path);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WUJIA_PORTAL.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WU_CABBAGE_CROP.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.WUJIA_AIR.get(), RenderType.translucent());
        });
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.DODGE_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/dodge_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.TELEPORT_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/teleport_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.CHIEF_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/chief_villager.png"), 1.15f));
        event.registerEntityRenderer(ModEntities.ANCESTOR_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/ancestor_villager.png"), 1.3f,
                        tex("textures/entity/ancestor_villager_eyes.png")));
        event.registerEntityRenderer(ModEntities.SWEEPER_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/sweeper_villager.png"), 1.0f));
        event.registerEntityRenderer(ModEntities.GUARD_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/guard_villager.png"), 1.05f));
        event.registerEntityRenderer(ModEntities.FISHER_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/fisher_villager.png"), 1.0f));

        // Him：经典史蒂夫 + 一双发光的白眼
        event.registerEntityRenderer(ModEntities.HIM_VILLAGER.get(),
                ctx -> new WuHumanoidRenderer<>(ctx, tex("textures/entity/him_villager.png"), 1.0f,
                        tex("textures/entity/him_villager_eyes.png")));

        event.registerEntityRenderer(ModEntities.GHOST_VILLAGER.get(), GhostVillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.BROOM.get(), BroomRenderer::new);
        event.registerEntityRenderer(ModEntities.WU_CHICKEN.get(), ChickenRenderer::new);
        event.registerEntityRenderer(ModEntities.WU_DOG.get(), WolfRenderer::new);
        event.registerEntityRenderer(ModEntities.HIM_DRAGON.get(), EnderDragonRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BroomRenderer.LAYER, com.wujiacun.wujia.client.model.BroomModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onSkyEffects(RegisterDimensionSpecialEffectsEvent event) {
        event.register(new ResourceLocation(WujiaVillageMod.MODID, "wujia"), new WujiaSkyEffects());
    }

    /**
     * 以玩家为基准的人形渲染：史蒂夫骨架 + 各自皮肤，可选发光眼睛层。
     */
    public static class WuHumanoidRenderer<T extends Mob> extends MobRenderer<T, HumanoidModel<T>> {
        private final ResourceLocation texture;
        private final float scale;

        public WuHumanoidRenderer(EntityRendererProvider.Context ctx, ResourceLocation texture, float scale) {
            this(ctx, texture, scale, null);
        }

        public WuHumanoidRenderer(EntityRendererProvider.Context ctx, ResourceLocation texture, float scale,
                                  ResourceLocation glowEyes) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
            this.texture = texture;
            this.scale = scale;
            this.model.rightArmPose = HumanoidModel.ArmPose.EMPTY;
            this.model.leftArmPose = HumanoidModel.ArmPose.EMPTY;
            if (glowEyes != null) {
                this.addLayer(new EyesLayer<T, HumanoidModel<T>>(this) {
                    @Override
                    public RenderType renderType() {
                        return RenderType.eyes(glowEyes);
                    }
                });
            }
        }

        @Override
        public ResourceLocation getTextureLocation(T entity) {
            return texture;
        }

        @Override
        protected void scale(T entity, PoseStack pose, float partialTick) {
            pose.scale(scale, scale, scale);
        }
    }

    /**
     * 残影渲染器：不缩小，只按时间换成透明度越来越低的贴图，一层层淡出。
     */
    public static class GhostVillagerRenderer extends MobRenderer<GhostVillagerEntity, HumanoidModel<GhostVillagerEntity>> {
        private static final int FRAMES = 6;
        private static final ResourceLocation[] FADE = new ResourceLocation[FRAMES];

        static {
            for (int i = 0; i < FRAMES; i++) {
                FADE[i] = tex("textures/entity/ghost_villager_fade_" + i + ".png");
            }
        }

        public GhostVillagerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.0f);
        }

        @Override
        public ResourceLocation getTextureLocation(GhostVillagerEntity entity) {
            int frame = (int) (entity.fade(0.0f) * FRAMES);
            return FADE[Math.max(0, Math.min(FRAMES - 1, frame))];
        }

        @Override
        protected RenderType getRenderType(GhostVillagerEntity entity, boolean bodyVisible, boolean translucent, boolean glowing) {
            return RenderType.entityTranslucent(this.getTextureLocation(entity));
        }
    }
}
