package com.wujiacun.wujia.registry;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WujiaVillageMod.MODID);

    private static String id(String name) {
        return new ResourceLocation(WujiaVillageMod.MODID, name).toString();
    }

    /** 闪身步村民：源自古老非遗的神秘步法，连箭都追不上 */
    public static final RegistryObject<EntityType<DodgeVillagerEntity>> DODGE_VILLAGER =
            ENTITIES.register("dodge_villager", () -> EntityType.Builder
                    .of(DodgeVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).fireImmune().build(id("dodge_villager")));

    /** 瞬移村民：每次瞬移都会留下残影，真身早已在十维之外 */
    public static final RegistryObject<EntityType<TeleportVillagerEntity>> TELEPORT_VILLAGER =
            ENTITIES.register("teleport_villager", () -> EntityType.Builder
                    .of(TeleportVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).fireImmune().build(id("teleport_villager")));

    /** 村长：吴家村最强战力，一个意念捏爆黑洞 */
    public static final RegistryObject<EntityType<ChiefVillagerEntity>> CHIEF_VILLAGER =
            ENTITIES.register("chief_villager", () -> EntityType.Builder
                    .of(ChiefVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.8f, 2.4f).fireImmune().build(id("chief_villager")));

    /** 老祖：曾硬扛盘古三斧，睡觉翻身震死盘古扬眉罗喉 */
    public static final RegistryObject<EntityType<AncestorVillagerEntity>> ANCESTOR_VILLAGER =
            ENTITIES.register("ancestor_villager", () -> EntityType.Builder
                    .of(AncestorVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.9f, 2.6f).fireImmune().build(id("ancestor_villager")));

    /** 扫地村民：专门扫地3000年，曾回M78星云手撕贝利亚 */
    public static final RegistryObject<EntityType<SweeperVillagerEntity>> SWEEPER_VILLAGER =
            ENTITIES.register("sweeper_villager", () -> EntityType.Builder
                    .of(SweeperVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).fireImmune().build(id("sweeper_villager")));

    /** 残影：瞬移村民瞬移时留下的半透明影子 */
    public static final RegistryObject<EntityType<GhostVillagerEntity>> GHOST_VILLAGER =
            ENTITIES.register("ghost_villager", () -> EntityType.Builder
                    .of(GhostVillagerEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f).fireImmune().build(id("ghost_villager")));

    /** 保安：村口那位什么都管的大爷 */
    public static final RegistryObject<EntityType<GuardVillagerEntity>> GUARD_VILLAGER =
            ENTITIES.register("guard_villager", () -> EntityType.Builder
                    .of(GuardVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.9f).fireImmune().build(id("guard_villager")));

    /** 吴家飞帚：能骑的扫把 */
    public static final RegistryObject<EntityType<BroomEntity>> BROOM =
            ENTITIES.register("broom", () -> EntityType.Builder
                    .of(BroomEntity::new, MobCategory.MISC)
                    .sized(1.4f, 1.0f).fireImmune().clientTrackingRange(10).build(id("broom")));

    public static final RegistryObject<EntityType<WuChickenEntity>> WU_CHICKEN =
            ENTITIES.register("wu_chicken", () -> EntityType.Builder
                    .of(WuChickenEntity::new, MobCategory.CREATURE)
                    .sized(0.4f, 0.7f).build(id("wu_chicken")));

    public static final RegistryObject<EntityType<WuDogEntity>> WU_DOG =
            ENTITIES.register("wu_dog", () -> EntityType.Builder
                    .of(WuDogEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 0.85f).build(id("wu_dog")));

    /** 钓鱼村民：水战与甩竿 */
    public static final RegistryObject<EntityType<FisherVillagerEntity>> FISHER_VILLAGER =
            ENTITIES.register("fisher_villager", () -> EntityType.Builder
                    .of(FisherVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).fireImmune().build(id("fisher_villager")));

    /** 入门学徒 Him，白眼史蒂夫 */
    public static final RegistryObject<EntityType<HimVillagerEntity>> HIM_VILLAGER =
            ENTITIES.register("him_villager", () -> EntityType.Builder
                    .of(HimVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.95f).fireImmune().build(id("him_villager")));

    /** Him 的宠物龙：末影龙的血量和攻击，但不是末地战的那条 */
    public static final RegistryObject<EntityType<HimDragonEntity>> HIM_DRAGON =
            ENTITIES.register("him_dragon", () -> EntityType.Builder
                    .of(HimDragonEntity::new, MobCategory.MONSTER)
                    .sized(16.0f, 8.0f).fireImmune().clientTrackingRange(10).build(id("him_dragon")));

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
    }
}
