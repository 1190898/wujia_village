package com.wujiacun.wujia.entity;

import com.wujiacun.wujia.registry.ModEntities;
import com.wujiacun.wujia.world.WujiaVillageLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * 瞬移村民：每次瞬移都会在原地留下半透明残影，真身早已在十维之外。
 * 残影不会缩小，只会慢慢淡出。
 */
public class TeleportVillagerEntity extends WuVillagerBase {

    public TeleportVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.teleport_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.teleport";
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new WuTeleportGoal(this));
    }

    /** 瞬移 + 原地残影 */
    public void wuTeleport() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        for (int attempt = 0; attempt < 8; attempt++) {
            double dx = (this.random.nextDouble() - 0.5) * 16;
            double dz = (this.random.nextDouble() - 0.5) * 16;
            if (dx * dx + dz * dz < 9) continue;
            int tx = (int) Math.floor(this.getX() + dx);
            int tz = (int) Math.floor(this.getZ() + dz);
            if (!sl.hasChunkAt(new BlockPos(tx, 0, tz))) continue;
            int ty = sl.dimension().equals(com.wujiacun.wujia.WujiaVillageMod.WUJIA_DIM)
                    ? WujiaVillageLayout.SURFACE + 1
                    : sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            BlockPos feet = new BlockPos(tx, ty, tz);
            if (!sl.getBlockState(feet).isAir() || !sl.getBlockState(feet.above()).isAir()) continue;

            // 原地留下残影（半透明，慢慢淡出）
            GhostVillagerEntity ghost = ModEntities.GHOST_VILLAGER.get().create(sl);
            if (ghost != null) {
                ghost.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), this.getXRot());
                ghost.setYHeadRot(this.getYHeadRot());
                ghost.setYBodyRot(this.yBodyRot);
                sl.addFreshEntity(ghost);
            }

            if (this.randomTeleport(tx + 0.5, ty, tz + 0.5, false)) {
                sl.sendParticles(ParticleTypes.REVERSE_PORTAL,
                        this.getX(), this.getY() + 1, this.getZ(), 40, 0.4, 0.8, 0.4, 0.05);
                sl.playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.ENDERMAN_TELEPORT, SoundSource.NEUTRAL, 1.0f, 0.8f);
                return;
            }
        }
    }

    static class WuTeleportGoal extends Goal {
        private final TeleportVillagerEntity villager;
        private int cooldown = 60;

        WuTeleportGoal(TeleportVillagerEntity villager) {
            this.villager = villager;
        }

        @Override
        public boolean canUse() {
            return --this.cooldown <= 0;
        }

        @Override
        public void start() {
            this.villager.wuTeleport();
            this.cooldown = 60 + this.villager.random.nextInt(70);
        }
    }
}
