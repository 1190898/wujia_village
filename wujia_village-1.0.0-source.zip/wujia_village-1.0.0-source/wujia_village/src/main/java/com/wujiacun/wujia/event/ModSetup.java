package com.wujiacun.wujia.event;

import com.wujiacun.wujia.WujiaVillageMod;
import com.wujiacun.wujia.entity.*;
import com.wujiacun.wujia.registry.ModEntities;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WujiaVillageMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModSetup {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        // 闪身步村民：身法了得
        event.put(ModEntities.DODGE_VILLAGER.get(), WuVillagerBase.wuAttributes(600, 80).build());
        // 瞬移村民：你打得到残影算我输
        event.put(ModEntities.TELEPORT_VILLAGER.get(), WuVillagerBase.wuAttributes(600, 80).build());
        // 扫地村民：别惹扫地僧
        event.put(ModEntities.SWEEPER_VILLAGER.get(), WuVillagerBase.wuAttributes(800, 150).build());
        // 村长：吴家村最强战力
        event.put(ModEntities.CHIEF_VILLAGER.get(), WuVillagerBase.wuAttributes(2000, 500).build());
        // 老祖：叹气击杀洪荒所有圣人
        event.put(ModEntities.ANCESTOR_VILLAGER.get(), WuVillagerBase.wuAttributes(5000, 999).build());
        // 残影：本来就是影子
        event.put(ModEntities.GHOST_VILLAGER.get(),
                net.minecraft.world.entity.Mob.createMobAttributes()
                        .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 2.0).build());
        // 保安：拦得住、也打得动
        event.put(ModEntities.GUARD_VILLAGER.get(), WuVillagerBase.wuAttributes(1200, 120).build());
        event.put(ModEntities.FISHER_VILLAGER.get(), WuVillagerBase.wuAttributes(900, 90).build());
        event.put(ModEntities.WU_CHICKEN.get(),
                net.minecraft.world.entity.animal.Chicken.createAttributes()
                        .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 80.0).build());
        event.put(ModEntities.WU_DOG.get(),
                net.minecraft.world.entity.animal.Wolf.createAttributes()
                        .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 200.0).build());
        // 入门学徒：本人不强，宠物龙才是作业
        // Him：加厚血与攻击（护甲已由 wuAttributes 统一给出）
        // generic.max_health 原版硬顶 1024；再靠护甲/韧性拉抗性
        event.put(ModEntities.HIM_VILLAGER.get(), WuVillagerBase.wuAttributes(1024, 80).build());
        // 龙：注册表仍用原版龙属性模板；实体构造里再把血量抬到 800
        event.put(ModEntities.HIM_DRAGON.get(),
                net.minecraft.world.entity.boss.enderdragon.EnderDragon.createAttributes().build());
    }
}
