package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 扫地村民：吴家村7891岁老弟，专门扫地3000年，受吴家高人指点后回M78星云手撕贝利亚。
 * 平时安静扫地。有不开眼的东西闯进村子？一扫把拍飞（不伤性命，只伤尊严）。
 */
public class SweeperVillagerEntity extends WuVillagerBase {

    private static final double SWEEP_RADIUS = 6.0;

    public SweeperVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.sweeper_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.sweeper";
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(3, new SweepGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        ServerLevel sl = (ServerLevel) this.level();

        // 手持用了三千年的扫把
        if (this.tickCount == 1 && this.getMainHandItem().isEmpty()) {
            giveBroom();
        }

        // 平时安静扫地（灰尘）
        if (this.tickCount % 30 == 0) {
            sl.sendParticles(ParticleTypes.CLOUD,
                    this.getX() + (this.random.nextDouble() - 0.5) * 1.5,
                    this.getY() + 0.1,
                    this.getZ() + (this.random.nextDouble() - 0.5) * 1.5,
                    2, 0.3, 0.02, 0.3, 0.01);
        }
    }

    private void giveBroom() {
        ItemStack broom = new ItemStack(Items.STICK);
        broom.setHoverName(Component.translatable("item.wujia_village.broom"));
        this.setItemSlot(EquipmentSlot.MAINHAND, broom);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    private void sweep(ServerLevel sl) {
        boolean swept = false;
        for (LivingEntity le : sl.getEntitiesOfClass(LivingEntity.class,
                new AABB(this.blockPosition()).inflate(SWEEP_RADIUS),
                e -> e != this && e.isAlive() && e instanceof Enemy && !(e instanceof HimDragonEntity))) {
            Vec3 pushDir = le.position().subtract(this.position());
            if (pushDir.lengthSqr() < 1.0E-4) pushDir = new Vec3(1, 0, 0);
            pushDir = pushDir.normalize();
            le.push(pushDir.x * 3.0, 1.2, pushDir.z * 3.0);
            le.hurtMarked = true;
            le.hurt(this.damageSources().mobAttack(this), 6.0f);
            swept = true;
        }
        // 扫掉一切飞过来的弹射物（贝利亚的必杀技也得吃扫把）
        for (AbstractHurtingProjectile proj : sl.getEntitiesOfClass(AbstractHurtingProjectile.class,
                new AABB(this.blockPosition()).inflate(SWEEP_RADIUS))) {
            proj.discard();
            swept = true;
        }

        if (swept) {
            sl.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.NEUTRAL, 1.0f, 0.6f);
            sl.sendParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 0.5, this.getZ(),
                    30, 2.5, 0.3, 2.5, 0.08);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        // 记住手里的扫把
        if (!this.getMainHandItem().isEmpty()) {
            tag.put("WujiaBroom", this.getMainHandItem().save(new CompoundTag()));
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("WujiaBroom")) {
            ItemStack broom = ItemStack.of(tag.getCompound("WujiaBroom"));
            if (!broom.isEmpty()) {
                this.setItemSlot(EquipmentSlot.MAINHAND, broom);
                this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
            }
        }
    }

    /** 周期性大扫除 */
    static class SweepGoal extends Goal {
        private final SweeperVillagerEntity sweeper;
        private int cooldown = 40;

        SweepGoal(SweeperVillagerEntity sweeper) {
            this.sweeper = sweeper;
        }

        @Override
        public boolean canUse() {
            return --this.cooldown <= 0;
        }

        @Override
        public void start() {
            if (this.sweeper.level() instanceof ServerLevel sl) {
                this.sweeper.sweep(sl);
            }
            this.cooldown = 120 + this.sweeper.random.nextInt(80);
        }
    }
}
