package com.wujiacun.wujia.entity;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 闪身步村民：源自国家级非遗的神秘步法——闪出去、刹得住，利落又带点诙谐。
 * 连箭都追不上，近战攻击一半概率直接闪掉；闪完反手就是一巴掌。
 */
public class DodgeVillagerEntity extends WuVillagerBase {

    public DodgeVillagerEntity(EntityType<? extends WuVillagerBase> type, Level level) {
        super(type, level, "entity.wujia_village.dodge_villager");
    }

    @Override
    protected String greetKey() {
        return "message.wujia_village.greet.dodge";
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new DodgeStepGoal(this));
    }

    /** 周期性闪身：重心瞬间偏移，人仿佛原地"闪现" */
    public void dodgeStep() {
        Player near = this.level().getNearestPlayer(this, 12.0);
        if (near == null) {
            // 没人看也要练：随机方向闪
            double a = this.random.nextDouble() * Math.PI * 2;
            dash(new Vec3(Math.cos(a), 0, Math.sin(a)), 1.0, 0.3);
        } else {
            // 面朝观众闪：横移为主，稍带远离
            Vec3 toMe = this.position().subtract(near.position());
            if (toMe.lengthSqr() < 1.0E-4) toMe = new Vec3(1, 0, 0);
            Vec3 lateral = new Vec3(-toMe.z, 0, toMe.x).normalize();
            Vec3 dir = lateral.scale(this.random.nextBoolean() ? 1.0 : -1.0)
                    .add(toMe.normalize().scale(0.25));
            dash(dir, 1.1, 0.35);
        }
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.ENDER_DRAGON_FLAP, SoundSource.NEUTRAL, 0.6f, 1.6f);
    }

    /** 被攻击时的闪避判定 */
    public boolean tryDodgeAttack() {
        if (this.random.nextInt(2) == 0) {
            dodgeStep();
            return true;
        }
        return false;
    }

    static class DodgeStepGoal extends Goal {
        private final DodgeVillagerEntity villager;
        private int cooldown = 40;

        DodgeStepGoal(DodgeVillagerEntity villager) {
            this.villager = villager;
        }

        @Override
        public boolean canUse() {
            if (--this.cooldown > 0) return false;
            // 打架的时候不跳舞
            if (this.villager.getTarget() != null) return false;
            return this.villager.level().getNearestPlayer(this.villager, 12.0) != null;
        }

        @Override
        public void start() {
            this.villager.dodgeStep();
            this.cooldown = 40 + this.villager.random.nextInt(50);
        }
    }
}
