package com.wujiacun.wujia.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 吴家村村民的底子：以玩家为基准的人形战力，不是原版那种只会逃跑的村民。
 *
 * <p>模型用玩家（史蒂夫）骨架，AI 用真正的战斗 AI：会主动迎战敌对生物，
 * 谁打他他就打回去。血厚、甲厚、恢复快，雷劈不动，永不消失。</p>
 */
public abstract class WuVillagerBase extends PathfinderMob {

    protected WuVillagerBase(EntityType<? extends WuVillagerBase> type, Level level, String nameKey) {
        super(type, level);
        this.setPersistenceRequired();
        this.setCanPickUpLoot(false);
        this.setCustomName(Component.translatable(nameKey));
        this.setCustomNameVisible(true);
    }

    /** 玩家基准属性：血厚、甲厚、抗击退、带攻击力。 */
    public static AttributeSupplier.Builder wuAttributes(double health, double attack) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.MOVEMENT_SPEED, 0.42)
                .add(Attributes.FOLLOW_RANGE, 48)
                .add(Attributes.ARMOR, 24)
                .add(Attributes.ARMOR_TOUGHNESS, 12)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ATTACK_DAMAGE, attack)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, true));
        this.goalSelector.addGoal(5, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.85));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false,
                e -> e instanceof Enemy && !(e instanceof HimDragonEntity)));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            // 恢复力：每秒回复 5% 最大生命
            if (this.tickCount % 20 == 0 && this.getHealth() < this.getMaxHealth()) {
                this.heal(this.getMaxHealth() * 0.05f);
            }
            if (this.level() instanceof ServerLevel sl && this.tickCount % 40 == 0) {
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                        this.getX(), this.getY() + this.getBbHeight() + 0.3, this.getZ(),
                        2, 0.3, 0.2, 0.3, 0.0);
            }
        }
    }

    /** 与玩家对话：每个角色一句自己的台词（由子类给出语言键）。 */
    protected String greetKey() {
        return null;
    }

    @Override
    public net.minecraft.world.InteractionResult mobInteract(Player player, net.minecraft.world.InteractionHand hand) {
        String key = this.greetKey();
        if (key != null && !this.level().isClientSide()) {
            player.sendSystemMessage(Component.translatable(key));
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(this.level().isClientSide());
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource src) {
        if (src.is(DamageTypes.IN_WALL)) return true; // 卡墙不掉血
        if (src.is(DamageTypes.DRAGON_BREATH)) return true;
        return super.isInvulnerableTo(src);
    }

    @Override
    public void thunderHit(ServerLevel level, LightningBolt bolt) {
        // 老祖们被雷劈过太多次了，免疫闪电转化
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    /** 向某个方向猛冲（供闪身步等使用） */
    protected void dash(Vec3 dir, double strength, double up) {
        Vec3 n = dir.normalize();
        this.setDeltaMovement(n.x * strength, up, n.z * strength);
        this.hasImpulse = true;
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 0.2, this.getZ(), 8, 0.3, 0.1, 0.3, 0.02);
        }
    }

    /** 供 AI 目标筛选使用：这东西是不是"该打的"。 */
    public static boolean isHostile(LivingEntity e) {
        return e instanceof Enemy && !(e instanceof HimDragonEntity);
    }
}
