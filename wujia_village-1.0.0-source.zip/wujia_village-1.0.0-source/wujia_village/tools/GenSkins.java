import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 吴家村玩家皮肤生成器：以原版 Steve（64x64 玩家格式）为底，按角色换色、画脸、加装饰。
 * 用法: java GenSkins.java <client-extra.jar> <输出资源目录>
 */
public class GenSkins {

    static ZipFile jar;
    static File outRoot;

    // 玩家皮肤图集（64x64）各部位坐标
    static final int[] HEAD_TOP = {8, 0, 16, 8};
    static final int[] HEAD_BOTTOM = {16, 0, 24, 8};
    static final int[] HEAD_RIGHT = {0, 8, 8, 16};
    static final int[] HEAD_FACE = {8, 8, 16, 16};
    static final int[] HEAD_LEFT = {16, 8, 24, 16};
    static final int[] HEAD_BACK = {24, 8, 32, 16};

    static final int[] BODY_FRONT = {20, 20, 28, 32};
    static final int[] BODY_BACK = {32, 20, 40, 32};
    static final int[] BODY_SIDE_R = {16, 20, 20, 32};
    static final int[] BODY_SIDE_L = {28, 20, 32, 32};
    static final int[] BODY_TOP = {20, 16, 28, 20};
    static final int[] BODY_BOTTOM = {28, 16, 36, 20};

    static final int[] ARM_R_FRONT = {44, 20, 48, 32};
    static final int[] ARM_R_BACK = {52, 20, 56, 32};
    static final int[] ARM_R_RIGHT = {40, 20, 44, 32};
    static final int[] ARM_R_LEFT = {48, 20, 52, 32};
    static final int[] ARM_R_TOP = {44, 16, 48, 20};
    static final int[] ARM_R_BOTTOM = {48, 16, 52, 20};

    static final int[] ARM_L_FRONT = {36, 52, 40, 64};
    static final int[] ARM_L_BACK = {44, 52, 48, 64};
    static final int[] ARM_L_RIGHT = {32, 52, 36, 64};
    static final int[] ARM_L_LEFT = {40, 52, 44, 64};
    static final int[] ARM_L_TOP = {36, 48, 40, 52};
    static final int[] ARM_L_BOTTOM = {40, 48, 44, 52};

    static final int[] LEG_R_FRONT = {4, 20, 8, 32};
    static final int[] LEG_R_BACK = {12, 20, 16, 32};
    static final int[] LEG_R_RIGHT = {0, 20, 4, 32};
    static final int[] LEG_R_LEFT = {8, 20, 12, 32};
    static final int[] LEG_R_TOP = {4, 16, 8, 20};

    static final int[] LEG_L_FRONT = {20, 52, 24, 64};
    static final int[] LEG_L_BACK = {28, 52, 32, 64};
    static final int[] LEG_L_RIGHT = {16, 52, 20, 64};
    static final int[] LEG_L_LEFT = {24, 52, 28, 64};
    static final int[] LEG_L_TOP = {20, 48, 24, 52};

    public static void main(String[] args) throws Exception {
        jar = new ZipFile(args[0]);
        outRoot = new File(args[1]);

        BufferedImage steve = read("assets/minecraft/textures/entity/player/wide/steve.png");

        // ---- Him：原版史蒂夫 + 一双白眼（眼睛另做发光层） ----
        save(copy(steve), "textures/entity/him_villager.png");
        save(eyeLayer(0xFFFFFF, 0), "textures/entity/him_villager_eyes.png");

        // ---- 闪身步：青色道服 + 白抹额 ----
        BufferedImage dodge = copy(steve);
        dress(dodge, 0x2FA48C, 0x1E5F53, 0x2A2A30, 0x1B3A34, 0x14141A);
        hair(dodge, 0x1B1B22, false);
        face(dodge, 0xF0C8A0, 0x1B2B4A, 0xFFFFFF, false);
        band(dodge, 0xF2F2F2);
        save(dodge, "textures/entity/dodge_villager.png");

        // ---- 瞬移：深蓝长袍 + 兜帽 + 青色眼睛 ----
        BufferedImage teleport = copy(steve);
        dress(teleport, 0x3E37A8, 0x241C5C, 0x2A2A38, 0x1A1440, 0x121026);
        hair(teleport, 0x2A2470, true);
        hood(teleport, 0x35307F);
        face(teleport, 0xE6C6A8, 0x35E0D0, 0x0E2A3A, false);
        save(teleport, "textures/entity/teleport_villager.png");

        // ---- 村长：金红长袍 + 灰白胡子 ----
        BufferedImage chief = copy(steve);
        dress(chief, 0xD9A62E, 0x6E2320, 0x2B2B30, 0x7A2A22, 0x201712);
        hair(chief, 0x33333C, false);
        face(chief, 0xE8C39C, 0x241A14, 0x2B2B30, true);
        trim(chief, 0xF6E6A8);
        save(chief, "textures/entity/chief_villager.png");

        // ---- 老祖：素白长袍 + 白发白须 + 金眼 ----
        BufferedImage ancestor = copy(steve);
        dress(ancestor, 0xEDE6D2, 0xD8CEB2, 0x2B2B30, 0xD9D0B8, 0xB9AE92);
        hair(ancestor, 0xF4F4F0, true);
        longHair(ancestor, 0xF4F4F0);
        face(ancestor, 0xEBD9C4, 0xE8C24A, 0xF4F4F0, true);
        trim(ancestor, 0xC9A542);
        save(ancestor, "textures/entity/ancestor_villager.png");
        save(eyeLayer(0xFFE07A, 0), "textures/entity/ancestor_villager_eyes.png");

        // ---- 扫地：灰布工装 + 深灰帽子 ----
        BufferedImage sweeper = copy(steve);
        dress(sweeper, 0x8A8A90, 0x4F4F55, 0x2B2B30, 0x3C3C44, 0x22222A);
        hair(sweeper, 0x9A9A9A, false);
        face(sweeper, 0xE0C0A0, 0x2A1F18, 0x9A9A9A, true);
        hat(sweeper, 0x3A3A44, 0x5A5A66);
        save(sweeper, "textures/entity/sweeper_villager.png");

        // ---- 保安：深蓝制服 + 大檐帽 + 金徽 ----
        BufferedImage guard = copy(steve);
        dress(guard, 0x27364C, 0x1A2536, 0x232F42, 0x141C28, 0x0E131C);
        hair(guard, 0x1E1E24, false);
        face(guard, 0xE4BE96, 0x1C2436, 0x1E1E24, false);
        hat(guard, 0x1B2637, 0xD8C070);
        badge(guard);
        save(guard, "textures/entity/guard_villager.png");


        // ---- 钓鱼：海蓝衬衫 + 米黄背带裤 + 草帽 ----
        BufferedImage fisher = copy(steve);
        dress(fisher, 0x3A7CA5, 0xC8B87A, 0x5A4630, 0x2E5E7A, 0x24506A);
        hair(fisher, 0x3A2A18, false);
        face(fisher, 0xE8C39C, 0x1E3A55, 0xFFFFFF, false);
        hat(fisher, 0xD2C080, 0x8A7040);
        save(fisher, "textures/entity/fisher_villager.png");

        // ---- 残影：瞬移村民的贴图，逐帧降低透明度 ----
        double[] alphas = {1.0, 0.82, 0.64, 0.46, 0.28, 0.12};
        for (int i = 0; i < alphas.length; i++) {
            save(fade(teleport, alphas[i]), "textures/entity/ghost_villager_fade_" + i + ".png");
        }

        // ---- 其它贴图 ----
        save(broom(), "textures/entity/broom.png");
        save(broomItem(), "textures/item/wu_broom.png");
        save(wujiaAir(), "textures/block/wujia_air.png");

        System.out.println("OK: skins written to " + outRoot);
    }

    // ------------------------------------------------------------------
    // 换装
    // ------------------------------------------------------------------

    /** 上衣 / 裤子 / 鞋 / 腰带 / 袖口 */
    static void dress(BufferedImage img, int shirt, int pants, int shoes, int belt, int cuff) {
        int[][] body = {BODY_FRONT, BODY_BACK, BODY_SIDE_R, BODY_SIDE_L, BODY_TOP, BODY_BOTTOM};
        for (int[] r : body) tint(img, r, shirt, 0.75);
        // 腰带：身体最下面两行
        for (int[] r : new int[][]{BODY_FRONT, BODY_BACK, BODY_SIDE_R, BODY_SIDE_L}) {
            tintRect(img, r[0], r[3] - 2, r[2], r[3], belt, 0.6);
        }

        int[][] arms = {ARM_R_FRONT, ARM_R_BACK, ARM_R_RIGHT, ARM_R_LEFT, ARM_R_TOP, ARM_R_BOTTOM,
                ARM_L_FRONT, ARM_L_BACK, ARM_L_RIGHT, ARM_L_LEFT, ARM_L_TOP, ARM_L_BOTTOM};
        for (int[] r : arms) tint(img, r, shirt, 0.72);
        // 手：手臂最下面三行留皮肤色
        for (int[] r : new int[][]{ARM_R_FRONT, ARM_R_BACK, ARM_R_RIGHT, ARM_R_LEFT,
                ARM_L_FRONT, ARM_L_BACK, ARM_L_RIGHT, ARM_L_LEFT}) {
            tintRect(img, r[0], r[3] - 3, r[2], r[3], 0xE8BE96, 0.9);
        }
        // 袖口
        for (int[] r : new int[][]{ARM_R_FRONT, ARM_R_BACK, ARM_R_RIGHT, ARM_R_LEFT,
                ARM_L_FRONT, ARM_L_BACK, ARM_L_RIGHT, ARM_L_LEFT}) {
            tintRect(img, r[0], r[3] - 4, r[2], r[3] - 3, cuff, 0.8);
        }

        int[][] legs = {LEG_R_FRONT, LEG_R_BACK, LEG_R_RIGHT, LEG_R_LEFT, LEG_R_TOP,
                LEG_L_FRONT, LEG_L_BACK, LEG_L_RIGHT, LEG_L_LEFT, LEG_L_TOP};
        for (int[] r : legs) tint(img, r, pants, 0.75);
        for (int[] r : new int[][]{LEG_R_FRONT, LEG_R_BACK, LEG_R_RIGHT, LEG_R_LEFT,
                LEG_L_FRONT, LEG_L_BACK, LEG_L_RIGHT, LEG_L_LEFT}) {
            tintRect(img, r[0], r[3] - 2, r[2], r[3], shoes, 0.8);
        }
    }

    static void hair(BufferedImage img, int color, boolean longBack) {
        tint(img, HEAD_TOP, color, 0.7);
        tint(img, HEAD_BACK, color, 0.7);
        tint(img, HEAD_RIGHT, color, 0.7);
        tint(img, HEAD_LEFT, color, 0.7);
        tint(img, HEAD_BOTTOM, color, 0.7);
        // 脸：额前两行 + 两鬓
        tintRect(img, 8, 8, 16, 10, color, 0.8);
        tintRect(img, 8, 10, 9, 13, color, 0.8);
        tintRect(img, 15, 10, 16, 13, color, 0.8);
    }

    /** 长袍式长发：后背一节也盖住 */
    static void longHair(BufferedImage img, int color) {
        tintRect(img, BODY_BACK[0], BODY_BACK[1], BODY_BACK[2], BODY_BACK[1] + 6, color, 0.55);
    }

    static void hood(BufferedImage img, int color) {
        tint(img, HEAD_TOP, color, 0.75);
        tint(img, HEAD_BACK, color, 0.75);
        tint(img, HEAD_RIGHT, color, 0.75);
        tint(img, HEAD_LEFT, color, 0.75);
        tintRect(img, 8, 8, 16, 10, color, 0.85);
        tintRect(img, 8, 10, 9, 14, color, 0.85);
        tintRect(img, 15, 10, 16, 14, color, 0.85);
    }

    /** 抹额/头带：脸上第 4 行 */
    static void band(BufferedImage img, int color) {
        tintRect(img, 8, 11, 16, 12, color, 0.95);
        tintRect(img, 0, 11, 8, 12, color, 0.9);
        tintRect(img, 16, 11, 24, 12, color, 0.9);
        tintRect(img, 24, 11, 32, 12, color, 0.9);
    }

    static void hat(BufferedImage img, int color, int bandColor) {
        tint(img, HEAD_TOP, color, 0.8);
        tintRect(img, 8, 8, 16, 10, color, 0.9);
        tintRect(img, 0, 8, 8, 10, color, 0.85);
        tintRect(img, 16, 8, 24, 10, color, 0.85);
        tintRect(img, 24, 8, 32, 10, color, 0.85);
        tintRect(img, 8, 10, 16, 11, bandColor, 0.9);
        tintRect(img, 0, 10, 8, 11, bandColor, 0.85);
        tintRect(img, 16, 10, 24, 11, bandColor, 0.85);
        tintRect(img, 24, 10, 32, 11, bandColor, 0.85);
    }

    /** 衣服上的金色滚边 */
    static void trim(BufferedImage img, int color) {
        tintRect(img, 20, 20, 28, 21, color, 0.85);
        tintRect(img, 20, 30, 28, 32, color, 0.8);
        tintRect(img, 32, 20, 40, 21, color, 0.85);
        // 前襟一条竖线
        tintRect(img, 23, 21, 24, 30, color, 0.8);
    }

    static void badge(BufferedImage img) {
        fill(img, 22, 23, 24, 25, 0xD8C070, 255);
        fill(img, 23, 24, 24, 25, 0x8A6A20, 255);
    }

    /** 画脸：清晰五官（眉+大眼白+瞳孔高光+鼻+嘴）；beard=true 加胡子 */
    static void face(BufferedImage img, int skin, int pupil, int eyeWhite, boolean beard) {
        tintRect(img, 9, 10, 15, 15, skin, 0.97);
        // 眉
        fill(img, 9, 11, 11, 12, shade(skin, 0.55), 255);
        fill(img, 13, 11, 15, 12, shade(skin, 0.55), 255);
        // 眼白 2x2
        fill(img, 9, 12, 11, 14, eyeWhite, 255);
        fill(img, 13, 12, 15, 14, eyeWhite, 255);
        // 瞳孔 + 高光
        fill(img, 10, 12, 11, 14, pupil, 255);
        fill(img, 13, 12, 14, 14, pupil, 255);
        fill(img, 10, 12, 11, 13, 0xFFFFFF, 220);
        fill(img, 13, 12, 14, 13, 0xFFFFFF, 220);
        // 鼻子
        fill(img, 11, 13, 13, 14, shade(skin, 0.82), 255);
        // 嘴
        fill(img, 10, 14, 14, 15, shade(skin, 0.52), 255);
        fill(img, 11, 15, 13, 16, shade(skin, 0.62), 255);
        if (beard) {
            fill(img, 9, 15, 15, 16, eyeWhite, 255);
            fill(img, 8, 13, 9, 16, eyeWhite, 255);
            fill(img, 15, 13, 16, 16, eyeWhite, 255);
        }
    }

    /** 眼睛发光层：整张 64x64 只有眼睛位置有颜色 */
    static BufferedImage eyeLayer(int rgb, int unused) {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        fill(img, 9, 12, 11, 13, rgb, 255);
        fill(img, 13, 12, 15, 13, rgb, 255);
        return img;
    }

    // ------------------------------------------------------------------
    // 贴图小工具
    // ------------------------------------------------------------------

    static BufferedImage copy(BufferedImage src) {
        BufferedImage dst = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = dst.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return dst;
    }

    /** 按区域把像素往目标颜色靠，保留明暗关系 */
    static void tint(BufferedImage img, int[] rect, int color, double keep) {
        tintRect(img, rect[0], rect[1], rect[2], rect[3], color, keep);
    }

    static void tintRect(BufferedImage img, int x0, int y0, int x1, int y1, int color, double keep) {
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                if (x < 0 || y < 0 || x >= img.getWidth() || y >= img.getHeight()) continue;
                int argb = img.getRGB(x, y);
                int a = (argb >>> 24) & 0xFF;
                if (a == 0) continue;
                int r = (argb >>> 16) & 0xFF, g = (argb >>> 8) & 0xFF, b = argb & 0xFF;
                double lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
                double scale = 0.55 + lum * 0.9;   // 保留了原来的明暗
                int tr = clamp((int) (((color >>> 16) & 0xFF) * scale));
                int tg = clamp((int) (((color >>> 8) & 0xFF) * scale));
                int tb = clamp((int) ((color & 0xFF) * scale));
                int nr = (int) (tr * keep + r * (1 - keep));
                int ng = (int) (tg * keep + g * (1 - keep));
                int nb = (int) (tb * keep + b * (1 - keep));
                img.setRGB(x, y, (a << 24) | (nr << 16) | (ng << 8) | nb);
            }
        }
    }

    static void fill(BufferedImage img, int x0, int y0, int x1, int y1, int rgb, int alpha) {
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                if (x < 0 || y < 0 || x >= img.getWidth() || y >= img.getHeight()) continue;
                img.setRGB(x, y, (alpha << 24) | (rgb & 0xFFFFFF));
            }
        }
    }

    static BufferedImage fade(BufferedImage src, double alpha) {
        BufferedImage dst = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < src.getWidth(); x++) {
                int argb = src.getRGB(x, y);
                int a = (argb >>> 24) & 0xFF;
                if (a == 0) continue;
                int na = clamp((int) (a * alpha));
                dst.setRGB(x, y, (na << 24) | (argb & 0xFFFFFF));
            }
        }
        return dst;
    }

    static int shade(int rgb, double mul) {
        int r = clamp((int) (((rgb >>> 16) & 0xFF) * mul));
        int g = clamp((int) (((rgb >>> 8) & 0xFF) * mul));
        int b = clamp((int) ((rgb & 0xFF) * mul));
        return (r << 16) | (g << 8) | b;
    }

    static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    // ------------------------------------------------------------------
    // 扫帚 / 吴家空气
    // ------------------------------------------------------------------

    /** 64x32 的扫帚：木杆 + 铜箍 + 扫帚毛（UV 对齐模型） */
    static BufferedImage broom() {
        BufferedImage img = new BufferedImage(64, 32, BufferedImage.TYPE_INT_ARGB);
        // 木杆：更深的纹理木纹
        for (int y = 0; y < 20; y++) {
            for (int x = 0; x < 42; x++) {
                int n = (int) (Math.sin(x * 0.55 + y * 0.35) * 10 + Math.sin(x * 2.1) * 4);
                int r = clamp(138 + n), g = clamp(96 + n), b = clamp(52 + n / 2);
                if ((x + y * 3) % 7 == 0) { r -= 18; g -= 14; b -= 8; }
                img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | b);
            }
        }
        // 铜箍
        for (int y = 21; y < 26; y++) {
            for (int x = 22; x < 34; x++) {
                int edge = (x == 22 || x == 33 || y == 21 || y == 25) ? -30 : 0;
                img.setRGB(x, y, (255 << 24) | (clamp(210 + edge) << 16) | (clamp(168 + edge) << 8) | clamp(72 + edge));
            }
        }
        // 扫帚毛：金黄稻草，纤维感
        for (int y = 21; y < 31; y++) {
            for (int x = 0; x < 22; x++) {
                int n = (int) (Math.sin(x * 3.1 + y * 1.7) * 18);
                int r = clamp(220 + n), g = clamp(190 + n), b = clamp(90 + n / 2);
                if (x % 2 == 0) { r -= 20; g -= 18; b -= 10; }
                if (y > 28) { r = clamp(r - 25); g = clamp(g - 20); }
                img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | b);
            }
        }
        return img;
    }

    /** 16x16 物品图标：斜着的扫帚，毛在左下、柄向右上 */
    static BufferedImage broomItem() {
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int i = 0; i < 11; i++) {
            int x = 4 + i, y = 11 - i;
            put(img, x, y, 140, 98, 55);
            put(img, x, y + 1, 110, 76, 42);
        }
        for (int y = 8; y <= 14; y++) {
            for (int x = 1; x <= 7; x++) {
                if (x + (14 - y) < 6) continue;
                if ((x * 3 + y) % 2 == 0) put(img, x, y, 220, 190, 95);
                else put(img, x, y, 185, 155, 70);
            }
        }
        put(img, 6, 8, 210, 170, 75);
        put(img, 7, 7, 210, 170, 75);
        put(img, 7, 8, 170, 130, 55);
        return img;
    }

    static void put(BufferedImage img, int x, int y, int r, int g, int b) {
        if (x < 0 || y < 0 || x >= img.getWidth() || y >= img.getHeight()) return;
        img.setRGB(x, y, (255 << 24) | (r << 16) | (g << 8) | b);
    }

    /** 吴家空气：几乎全透明，只有一点点云丝 */
    static BufferedImage wujiaAir() {
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                double v = Math.sin(x * 0.9 + y * 0.4) + Math.sin(y * 1.1 - x * 0.3);
                if (v > 0.9) {
                    int a = (int) (30 + (v - 0.9) * 60);
                    img.setRGB(x, y, (clamp(a) << 24) | (0xEAF6FF));
                } else if (v > 0.4) {
                    img.setRGB(x, y, (22 << 24) | (0xEAF6FF));
                }
            }
        }
        return img;
    }

    // ------------------------------------------------------------------

    static BufferedImage read(String path) throws IOException {
        ZipEntry e = jar.getEntry(path);
        if (e == null) throw new IOException("missing in jar: " + path);
        BufferedImage img = ImageIO.read(jar.getInputStream(e));
        if (img == null) throw new IOException("cannot decode: " + path);
        BufferedImage conv = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = conv.createGraphics();
        g.drawImage(img, 0, 0, null);
        g.dispose();
        return conv;
    }

    static void save(BufferedImage img, String rel) throws IOException {
        File f = new File(outRoot, rel);
        f.getParentFile().mkdirs();
        ImageIO.write(img, "png", f);
        System.out.println("  + " + rel);
    }
}
